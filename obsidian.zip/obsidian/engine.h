#pragma once
#include <stdint.h>
// Engine 2D (C++): WebGPU instanced quads (1 draw call/frame), multitouch, loop. Dipakai lewat game.cpp.
#define IMPORT(n) __attribute__((import_module("env"), import_name(n)))
IMPORT("gpu_pipeline") unsigned gpu_pipeline(const char*, unsigned);
IMPORT("gpu_buffer") unsigned gpu_buffer(unsigned size, unsigned storage);
IMPORT("gpu_bind") unsigned gpu_bind(unsigned pipe, unsigned a, unsigned b);
IMPORT("gpu_write") void gpu_write(unsigned buf, const void*, unsigned bytes);
IMPORT("gpu_draw") void gpu_draw(unsigned pipe, unsigned bind, unsigned n, float r, float g, float b);
IMPORT("gpu_canvas") void gpu_canvas(unsigned w, unsigned h);

void game();  // didefinisikan di game.cpp, dipanggil tiap frame

namespace eng {
constexpr int MAX_INST = 1 << 16, MAX_PTR = 8;
constexpr float SHORT_SIDE = 720.f;  // sisi pendek dunia (unit) di semua layar

struct Inst { float x, y, w, h, a; uint32_t c; float s, pad; };
static_assert(sizeof(Inst) == 32);

struct State {
  float W = SHORT_SIDE, H = SHORT_SIDE, k = 1, dt = 0;  // ukuran dunia, css->dunia, delta detik
  int n = 0;                                            // jumlah pointer aktif
  float px[MAX_PTR], py[MAX_PTR];                       // posisi pointer (koordinat dunia)
};
inline State E;
inline Inst cpu[MAX_INST];
inline int cnt, ids[MAX_PTR];
inline unsigned pipe, ubuf, ibuf, bind;
inline uint32_t seed = 2463534242u;

constexpr uint32_t rgba(uint32_t h, uint32_t a = 255) { return (h >> 16 & 255) | (h >> 8 & 255) << 8 | (h & 255) << 16 | a << 24; }
inline float rnd() { seed ^= seed << 13; seed ^= seed >> 17; seed ^= seed << 5; return (seed >> 8) * (1.f / 16777216.f); }
inline float sn(float x) {  // sin cepat (error ~0.001)
  x -= 6.2831853f * __builtin_floorf(x * .15915494f + .5f);
  float y = x * (1.2732395f - .4052847f * __builtin_fabsf(x));
  return y * (.225f * (__builtin_fabsf(y) - 1.f) + 1.f);
}
inline float cs(float x) { return sn(x + 1.5707963f); }
inline void rect(float x, float y, float w, float h, float a, uint32_t c) { cpu[cnt++] = {x, y, w, h, a, c, 0.f, 0.f}; }
inline void circle(float x, float y, float r, uint32_t c) { cpu[cnt++] = {x, y, r * 2, r * 2, 0.f, c, 1.f, 0.f}; }

static const char SHADER[] = R"(
struct I{x:f32,y:f32,w:f32,h:f32,a:f32,c:u32,s:f32,z:f32}
struct O{@builtin(position)b:vec4f,@location(0)p:vec2f,@location(1)@interpolate(flat)m:f32,@location(2)@interpolate(flat)k:vec4f}
@group(0)@binding(0)var<uniform>u:vec2f;
@group(0)@binding(1)var<storage,read>D:array<I>;
@vertex fn vs(@builtin(vertex_index)v:u32,@builtin(instance_index)n:u32)->O{
  let i=D[n];
  let p=vec2f(f32(v&1),f32(v>>1))*2-1;
  let q=p*vec2f(i.w,i.h)*.5;
  let c=cos(i.a);let s=sin(i.a);
  let w=vec2f(c*q.x-s*q.y,s*q.x+c*q.y)+vec2f(i.x,i.y);
  return O(vec4f(w.x*u.x-1,1-w.y*u.y,0,1),p,i.s,unpack4x8unorm(i.c));
}
@fragment fn fs(o:O)->@location(0)vec4f{
  let d=mix(max(abs(o.p.x),abs(o.p.y)),length(o.p),o.m);
  return vec4f(o.k.rgb,1)*o.k.a*(1-smoothstep(1-fwidth(d),1,d));
})";
}  // namespace eng

using namespace eng;
extern "C" {
void init() {
  pipe = gpu_pipeline(SHADER, sizeof SHADER - 1);
  ubuf = gpu_buffer(16, 0); ibuf = gpu_buffer(sizeof cpu, 1);
  bind = gpu_bind(pipe, ubuf, ibuf);
}
void resize(float w, float h, float dpr) {
  float d = dpr < 2.f ? dpr : 2.f;  // batas fill-rate di HP
  gpu_canvas((unsigned)(w * d), (unsigned)(h * d));
  E.k = SHORT_SIDE / (w < h ? w : h);
  E.W = w * E.k; E.H = h * E.k;
  float u[2] = {2.f / E.W, 2.f / E.H};
  gpu_write(ubuf, u, 8);
}
void ptr(int id, float x, float y, int kind) {  // kind: 0 lepas, 1 tekan, 2 geser
  int i = 0;
  while (i < E.n && ids[i] != id) i++;
  if (kind == 0) {
    if (i < E.n) { E.n--; ids[i] = ids[E.n]; E.px[i] = E.px[E.n]; E.py[i] = E.py[E.n]; }
    return;
  }
  if (i == E.n) { if (kind != 1 || i == MAX_PTR) return; ids[i] = id; E.n++; }
  E.px[i] = x * E.k; E.py[i] = y * E.k;
}
void frame(double t) {
  static double last;
  float dt = (float)(t - last) * .001f;
  E.dt = dt < 1.f / 30.f ? dt : 1.f / 30.f; last = t;  // dt dibatasi
  cnt = 0;
  game();
  gpu_write(ibuf, cpu, cnt * sizeof(Inst));
  gpu_draw(pipe, bind, cnt, .039f, .043f, .055f);      // obsidian #0a0b0e
}
}
