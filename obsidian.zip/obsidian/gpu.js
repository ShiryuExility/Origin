// Jembatan WebGPU/DOM tetap (tidak perlu diubah). Semua logika engine + game ada di C++.
(async () => {
  if (!navigator.gpu) throw "WebGPU tidak didukung browser ini";
  const c = document.getElementById("c"), cx = c.getContext("webgpu"), fmt = navigator.gpu.getPreferredCanvasFormat();
  const dev = await (await navigator.gpu.requestAdapter({ powerPreference: "high-performance" })).requestDevice();
  cx.configure({ device: dev, format: fmt, alphaMode: "opaque" });
  const H = [], one = { srcFactor: "one", dstFactor: "one-minus-src-alpha" };
  let X;
  ({ instance: { exports: X } } = await WebAssembly.instantiate(Uint8Array.from(atob(WASM), s => s.charCodeAt(0)), { env: {
    gpu_pipeline: (p, n) => {
      const m = dev.createShaderModule({ code: new TextDecoder().decode(new Uint8Array(X.memory.buffer, p, n)) });
      return H.push(dev.createRenderPipeline({ layout: "auto", vertex: { module: m },
        fragment: { module: m, targets: [{ format: fmt, blend: { color: one, alpha: one } }] },
        primitive: { topology: "triangle-strip" } })) - 1;
    },
    gpu_buffer: (n, s) => H.push(dev.createBuffer({ size: n, usage: (s ? GPUBufferUsage.STORAGE : GPUBufferUsage.UNIFORM) | GPUBufferUsage.COPY_DST })) - 1,
    gpu_bind: (p, a, b) => H.push(dev.createBindGroup({ layout: H[p].getBindGroupLayout(0),
      entries: [{ binding: 0, resource: { buffer: H[a] } }, { binding: 1, resource: { buffer: H[b] } }] })) - 1,
    gpu_write: (b, p, n) => dev.queue.writeBuffer(H[b], 0, X.memory.buffer, p, n),
    gpu_canvas: (w, h) => { c.width = w; c.height = h; },
    gpu_draw: (p, b, n, r, g, bl) => {
      const e = dev.createCommandEncoder(), q = e.beginRenderPass({ colorAttachments: [{
        view: cx.getCurrentTexture().createView(), clearValue: { r, g, b: bl, a: 1 }, loadOp: "clear", storeOp: "store" }] });
      q.setPipeline(H[p]); q.setBindGroup(0, H[b]); q.draw(4, n); q.end();
      dev.queue.submit([e.finish()]);
    },
  } }));
  X.init();
  const rs = () => X.resize(innerWidth, innerHeight, devicePixelRatio);
  addEventListener("resize", rs); rs();
  c.onpointerdown = e => { c.setPointerCapture(e.pointerId); X.ptr(e.pointerId, e.clientX, e.clientY, 1); };
  c.onpointermove = e => X.ptr(e.pointerId, e.clientX, e.clientY, 2);
  c.onpointerup = c.onpointercancel = e => X.ptr(e.pointerId, 0, 0, 0);
  const f = t => { requestAnimationFrame(f); X.frame(t); };
  requestAnimationFrame(f);
})().catch(e => document.body.append(String(e)));
