#!/bin/sh
# Butuh: clang + lld (apt install clang lld). Hasil: index.html (1 file: wasm + jembatan JS tertanam, jalan via file://)
set -e
cd "$(dirname "$0")"
clang++ --target=wasm32 -O3 -std=c++17 -ffast-math -msimd128 -mbulk-memory -fno-exceptions -fno-rtti -nostdlib \
  -Wl,--no-entry -Wl,--export-dynamic -Wl,--initial-memory=8388608 -Wl,--max-memory=8388608 -Wl,-z,stack-size=65536 \
  game.cpp -o core.wasm
{ cat shell.html; printf '<script>var WASM="%s"</script>\n<script>' "$(base64 -w0 core.wasm)"; cat gpu.js; echo '</script>'; } > index.html
rm core.wasm
