#include "engine.h"

// Demo: hujan partikel perak. Sentuh/geser untuk memancarkan; ada emitter orbit otomatis.
// Batas: partikel + objek lain < MAX_INST.
constexpr int N = 40000;
constexpr uint32_t SILVER = 0xdfe3ea, STEEL = 0x7d8693, EDGE = 0x2a2f37;

alignas(16) static float x[N], y[N], vx[N], vy[N], life[N];
static int n;

static void emit(float ex, float ey, int k) {
  for (; k-- && n < N; n++) {
    float a = rnd() * 6.2832f, v = 80.f + rnd() * 420.f;
    x[n] = ex; y[n] = ey; vx[n] = cs(a) * v; vy[n] = sn(a) * v - 200.f;
    life[n] = 1.f + rnd() * 1.5f;
  }
}

void game() {
  static float t;
  const float dt = E.dt, floor_y = E.H - 2.f;
  t += dt;
  for (int i = 0; i < E.n; i++) emit(E.px[i], E.py[i], 120);
  emit(E.W * .5f + cs(t) * E.W * .3f, E.H * .5f + sn(t * 1.3f) * E.H * .2f, 40);

  int w = 0;  // integrasi + gambar + kompaksi dalam satu pass
  for (int i = 0; i < n; i++) {
    float l = life[i] - dt;
    if (l <= 0.f) continue;
    float v = vy[i] + 900.f * dt, py = y[i] + v * dt, px = x[i] + vx[i] * dt;
    if (py > floor_y) { py = floor_y; v *= -.5f; }
    x[w] = px; y[w] = py; vx[w] = vx[i]; vy[w] = v; life[w++] = l;
    circle(px, py, 3.f, rgba(l > .6f ? SILVER : STEEL, (uint32_t)(__builtin_fminf(l, 1.f) * 255.f)));
  }
  n = w;
  rect(E.W * .5f, E.H - 1.f, E.W, 2.f, 0.f, rgba(EDGE));
}
