#include "sandbox/ui.hpp"

#include <SDL3/SDL.h>

#include <algorithm>
#include <cmath>
#include <cstdio>

#include "render/atlas.hpp"
#include "sandbox/theme.hpp"

namespace nv::ui {
namespace {

Color lerp(Color a, Color b, f32 t) {
  const auto m = [t](u8 x, u8 y) { return static_cast<u8>(static_cast<f32>(x) + (static_cast<f32>(y) - x) * t + 0.5f); };
  return Color{m(a.r, b.r), m(a.g, b.g), m(a.b, b.b), m(a.a, b.a)};
}
Rect inset(Rect r, f32 d) { return {r.x + d, r.y + d, r.w - 2 * d, r.h - 2 * d}; }

constexpr Color kTextDim{122, 128, 141, 255};
constexpr Color kTextOff{82, 86, 97, 255};
constexpr Color kTextHi{240, 243, 248, 255};
constexpr Color kInk{14, 15, 19, 255};

bool contains(Rect r, f32 x, f32 y) { return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h; }

}  // namespace

// ---- frame ------------------------------------------------------------------------

void Ui::begin(const Input& in, f32 width, f32 height, f32 dt, f32 user_scale) {
  in_ = in;
  w_ = width;
  h_ = height;
  dt_ = dt;
  const f32 lw = width / density_, lh = height / density_;
  if (height > width) {
    // Portrait: the width is the scarce axis. 396 logical units is the widest piece of chrome (the 360-wide
    // dock plus margins), so the scale never exceeds what lets it fit, even at UI scale 125%.
    const f32 base = std::clamp(std::min(lw / 400.f, lh / 640.f), 0.5f, 1.3f);
    k_ = std::min(base * user_scale, std::fmax(0.5f, lw / 396.f));
  } else {
    k_ = std::clamp(std::min(lw / 760.f, lh / 500.f), 0.5f, 1.3f) * user_scale;
  }

  if (in.moved || in.pressed) kbd_ = false;
  if (in.nav_y || in.nav_x || in.activate) {
    kbd_ = true;
    if (in.nav_y && !order_prev_.empty()) {
      const auto n = static_cast<int>(order_prev_.size());
      int idx = -1;
      for (int i = 0; i < n; ++i) if (order_prev_[static_cast<std::size_t>(i)] == focus_) idx = i;
      if (idx < 0) idx = in.nav_y > 0 ? -1 : n;
      focus_ = order_prev_[static_cast<std::size_t>((idx + in.nav_y + n) % n)];
    } else if (focus_ == 0 && !order_prev_.empty()) {
      focus_ = order_prev_.front();
    }
  }
}

void Ui::end() {
  std::stable_sort(texts_.begin(), texts_.end(), [](const PendingText& a, const PendingText& b) { return a.font < b.font; });
  for (const PendingText& t : texts_) {
    TextStyle st;
    st.scale = k_;
    st.tracking = t.tracking;
    st.color = t.color;
    draw_text(b_, t.font->tex, t.font->font, std::string_view(text_buf_).substr(t.off, t.len), {t.x, t.y}, st);
  }
  texts_.clear();
  text_buf_.clear();
  order_prev_.swap(order_);
  order_.clear();
  if (!in_.down) active_ = 0;
}

bool Ui::interact(u32 id, Rect r, bool enabled, bool& hot) {
  if (enabled) order_.push_back(id);
  const bool ptr_valid = !in_.touch || in_.down || in_.pressed || in_.released;  // no hover after a touch ends
  const bool over = enabled && ptr_valid && contains(r, in_.x, in_.y);
  if (over && (in_.moved || in_.pressed)) focus_ = id;
  if (over && in_.pressed) active_ = id;
  hot = enabled && ((kbd_ && focus_ == id) || (!kbd_ && over) || (active_ == id && in_.down));
  bool clicked = false;
  if (in_.released && active_ == id && over) clicked = true;
  if (kbd_ && in_.activate && focus_ == id && enabled) clicked = true;
  return clicked;
}

// ---- primitives -------------------------------------------------------------------

void Ui::fill(Rect r, Color c) { b_.draw_quad(a_.atlas, {r.x + r.w * 0.5f, r.y + r.h * 0.5f}, {r.w, r.h}, a_.white_q, c); }

void Ui::rule(f32 x, f32 y, f32 w, Color c) {
  fill({std::round(x), std::round(y), w, std::fmax(1.f, std::round(density_))}, c);
}

void Ui::text(const FontTex& f, std::string_view s, f32 x, f32 y, Align al, f32 tracking_logical, Color c) {
  if (!a_.fonts_ok) return;
  TextStyle st;
  st.scale = k_;
  st.tracking = tracking_logical * density_ * k_;
  const f32 w = measure_text(f.font, s, st);
  if (al == Align::Center) x -= w * 0.5f;
  else if (al == Align::Right) x -= w;
  texts_.push_back({&f, std::round(x), std::round(y), st.tracking, c, static_cast<u32>(text_buf_.size()), static_cast<u32>(s.size())});
  text_buf_.append(s);
}

void Ui::shape(theme::Shape s, Vec2 center, f32 size, Color c, f32 rotation) {
  SpriteDesc d;
  d.texture = a_.atlas;
  d.uv = a_.uv[s];
  d.position = center;
  d.size = {size, size};
  d.rotation = rotation;
  d.color = c;
  b_.draw(d);
}

void Ui::bar(Vec2 center, f32 length, f32 thickness, f32 rotation, Color c) {
  SpriteDesc d;
  d.texture = a_.atlas;
  d.uv = a_.white;
  d.position = center;
  d.size = {length, thickness};
  d.rotation = rotation;
  d.color = c;
  b_.draw(d);
}

void Ui::panel(const Skin& s, f32 x, f32 y, Color fill_c, Color edge_c) {
  SpriteDesc d;
  d.pivot = {0.f, 0.f};
  d.position = {x, y};
  d.size = {u(s.w), u(s.h)};
  d.texture = a_.atlas;
  d.uv = s.fill; d.color = fill_c; b_.draw(d);
  d.uv = s.edge; d.color = edge_c; b_.draw(d);
}

void Ui::panel_turned(const Skin& s, f32 x, f32 y, Color fill_c, Color edge_c) {
  SpriteDesc d;
  d.position = {x + u(s.h) * 0.5f, y + u(s.w) * 0.5f};  // center of the turned footprint
  d.size = {u(s.w), u(s.h)};
  d.rotation = 1.5707964f;
  d.texture = a_.atlas;
  d.uv = s.fill; d.color = fill_c; b_.draw(d);
  d.uv = s.edge; d.color = edge_c; b_.draw(d);
}

// ---- widgets ----------------------------------------------------------------------

bool Ui::button(u32 id, Rect r, std::string_view label, bool enabled, bool primary, std::string_view tag) {
  bool hot = false;
  const bool clicked = interact(id, r, enabled, hot);
  Anim& an = anim(id);
  approach(an.hover, hot ? 1.f : 0.f);
  approach(an.press, (active_ == id && in_.down) ? 1.f : 0.f);
  const f32 h = an.hover;
  const Rect rr = inset(r, an.press * u(1.5f));

  Color fc, ec, txt;
  if (!enabled) {
    fc = Color{17, 18, 23, 150};
    ec = Color{150, 156, 170, 30};
    txt = kTextOff;
  } else if (primary) {
    fc = lerp(Color{176, 182, 196, 255}, Color{226, 230, 240, 255}, h);
    ec = Color{255, 255, 255, 150};
    txt = kInk;
  } else {
    fc = lerp(Color{20, 22, 28, 210}, Color{40, 43, 52, 230}, h);
    ec = lerp(Color{150, 156, 170, 56}, Color{232, 236, 245, 170}, h);
    txt = lerp(Color{170, 175, 187, 255}, kTextHi, h);
  }
  SpriteDesc d;
  d.pivot = {0.f, 0.f};
  d.position = {rr.x, rr.y};
  d.size = {rr.w, rr.h};
  d.texture = a_.atlas;
  d.uv = a_.wide.fill; d.color = fc; b_.draw(d);
  d.uv = a_.wide.edge; d.color = ec; b_.draw(d);

  if (enabled && !primary && h > 0.02f)  // silver accent bar slides in on hover / focus
    fill({rr.x + u(1.f), rr.y + rr.h * (0.5f - 0.2f * h), std::fmax(2.f, u(2.f)), rr.h * 0.4f * h},
         Color{214, 220, 232, static_cast<u8>(230 * h)});

  const f32 cy = rr.y + rr.h * 0.5f + a_.button.font.pixel_height * 0.36f * k_;
  text(a_.button, label, rr.x + rr.w * 0.5f, cy, Align::Center, 4.2f, txt);
  if (!tag.empty())
    text(a_.label, tag, rr.x + rr.w - u(18.f), rr.y + rr.h * 0.5f + a_.label.font.pixel_height * 0.36f * k_,
         Align::Right, 2.6f, kTextOff);
  return clicked;
}

namespace {
// Shared look of the small rounded buttons (back, undo, redo, lobby).
void small_skin_button(SpriteBatch& b, TextureId atlas, const Skin& skin, Rect rr, f32 h) {
  SpriteDesc d;
  d.pivot = {0.f, 0.f};
  d.position = {rr.x, rr.y};
  d.size = {rr.w, rr.h};
  d.texture = atlas;
  d.uv = skin.fill;
  d.color = lerp(Color{20, 22, 28, 214}, Color{40, 43, 52, 232}, h);
  b.draw(d);
  d.uv = skin.edge;
  d.color = lerp(Color{150, 156, 170, 56}, Color{232, 236, 245, 170}, h);
  b.draw(d);
}
}  // namespace

bool Ui::small_button(u32 id, Rect r, std::string_view label) {
  bool hot = false;
  const bool clicked = interact(id, r, true, hot);
  Anim& an = anim(id);
  approach(an.hover, hot ? 1.f : 0.f);
  approach(an.press, (active_ == id && in_.down) ? 1.f : 0.f);
  const Rect rr = inset(r, an.press * u(1.f));
  small_skin_button(b_, a_.atlas, a_.small, rr, an.hover);
  const Color txt = lerp(Color{170, 175, 187, 255}, kTextHi, an.hover);
  text(a_.button, label, rr.x + rr.w * 0.5f, rr.y + rr.h * 0.5f + a_.button.font.pixel_height * 0.36f * k_,
       Align::Center, 3.4f, txt);
  return clicked;
}

bool Ui::mini_button(u32 id, Rect r, std::string_view label, bool enabled) {
  bool hot = false;
  const bool clicked = interact(id, r, enabled, hot);
  Anim& an = anim(id);
  approach(an.hover, hot ? 1.f : 0.f);
  approach(an.press, (active_ == id && in_.down) ? 1.f : 0.f);
  const Rect rr = inset(r, an.press * u(1.f));
  small_skin_button(b_, a_.atlas, a_.mini, rr, an.hover);
  const Color txt = enabled ? lerp(Color{170, 175, 187, 255}, kTextHi, an.hover) : kTextOff;
  text(a_.label, label, rr.x + rr.w * 0.5f, rr.y + rr.h * 0.5f + a_.label.font.pixel_height * 0.36f * k_,
       Align::Center, 2.6f, txt);
  return clicked && enabled;
}

bool Ui::tool_button(u32 id, Rect r, bool selected, Color& icon) {
  bool hot = false;
  const bool clicked = interact(id, r, true, hot);
  Anim& an = anim(id);
  approach(an.hover, hot ? 1.f : 0.f);
  approach(an.aux, selected ? 1.f : 0.f);
  approach(an.press, (active_ == id && in_.down) ? 1.f : 0.f);
  const f32 e = std::fmax(an.hover * 0.55f, an.aux);
  const Rect rr = inset(r, an.press * u(1.5f));
  SpriteDesc d;
  d.pivot = {0.f, 0.f};
  d.position = {rr.x, rr.y};
  d.size = {rr.w, rr.h};
  d.texture = a_.atlas;
  d.uv = a_.tool.fill;
  d.color = lerp(Color{255, 255, 255, 0}, Color{214, 220, 234, 232}, an.aux);
  if (an.hover > 0.01f && an.aux < 0.99f) d.color = lerp(Color{255, 255, 255, static_cast<u8>(26 * an.hover)}, d.color, an.aux);
  b_.draw(d);
  // selected = silver chip with dark ink; otherwise silver ink brightens on hover
  icon = lerp(lerp(Color{150, 156, 170, 255}, Color{236, 240, 248, 255}, e), kInk, an.aux);
  return clicked;
}

bool Ui::swatch(u32 id, Vec2 c, f32 diameter, Color col, bool selected) {
  const f32 hit = diameter + u(8.f);
  bool hot = false;
  const bool clicked = interact(id, {c.x - hit * 0.5f, c.y - hit * 0.5f, hit, hit}, true, hot);
  Anim& an = anim(id);
  approach(an.hover, hot ? 1.f : 0.f);
  approach(an.aux, selected ? 1.f : 0.f);
  const f32 grow = 1.f + 0.12f * an.hover;
  shape(theme::kDisc, c, diameter * grow, col);
  if (an.aux > 0.02f)
    shape(theme::kRing, c, (diameter + u(9.f)) * grow, Color{236, 240, 248, static_cast<u8>(255 * an.aux)});
  return clicked;
}

bool Ui::size_dot(u32 id, Rect hit, f32 dot, bool selected) {
  bool hot = false;
  const bool clicked = interact(id, hit, true, hot);
  Anim& an = anim(id);
  approach(an.hover, hot ? 1.f : 0.f);
  approach(an.aux, selected ? 1.f : 0.f);
  const f32 e = std::fmax(an.hover * 0.6f, an.aux);
  shape(theme::kDisc, {hit.x + hit.w * 0.5f, hit.y + hit.h * 0.5f}, dot, lerp(Color{104, 110, 124, 255}, Color{236, 240, 248, 255}, e));
  return clicked;
}

bool Ui::glyph_button(u32 id, Rect r, std::string_view glyph) {
  bool hot = false;
  const bool clicked = interact(id, r, true, hot);
  Anim& an = anim(id);
  approach(an.hover, hot ? 1.f : 0.f);
  approach(an.press, (active_ == id && in_.down) ? 1.f : 0.f);
  if (an.hover > 0.01f) shape(theme::kDisc, {r.x + r.w * 0.5f, r.y + r.h * 0.5f}, std::fmin(r.w, r.h), Color{255, 255, 255, static_cast<u8>(22 * an.hover)});
  text(a_.value, glyph, r.x + r.w * 0.5f, r.y + r.h * 0.5f + a_.value.font.pixel_height * 0.34f * k_, Align::Center, 0.f,
       lerp(Color{150, 156, 170, 255}, kTextHi, an.hover));
  return clicked;
}

bool Ui::strip(u32 id, Rect r, f32& t, const Color* segs, int n, Color knob) {
  bool hot = false;
  interact(id, r, true, hot);
  Anim& an = anim(id);
  approach(an.hover, hot ? 1.f : 0.f);
  const f32 before = t;
  if (active_ == id && in_.down && r.w > 0.f) t = std::clamp((in_.x - r.x) / r.w, 0.f, 1.f);
  if (kbd_ && focus_ == id && in_.nav_x != 0) t = std::clamp(t + static_cast<f32>(in_.nav_x) * 0.05f, 0.f, 1.f);

  const f32 th = std::fmax(4.f, u(10.f)), y = std::round(r.y + (r.h - th) * 0.5f);
  for (int i = 0; i < n; ++i) {  // whole-pixel edges: no hairline seams between segments
    const f32 x0 = std::round(r.x + r.w * static_cast<f32>(i) / static_cast<f32>(n));
    const f32 x1 = std::round(r.x + r.w * static_cast<f32>(i + 1) / static_cast<f32>(n));
    fill({x0, y, x1 - x0, std::round(th)}, segs[i]);
  }
  const Vec2 kp{r.x + r.w * t, r.y + r.h * 0.5f};
  shape(theme::kDisc, kp, u(18.f + 3.f * an.hover), Color{244, 247, 252, 255});
  shape(theme::kDisc, kp, u(11.f), knob);
  return t != before;
}

bool Ui::toggle(u32 id, Rect row, std::string_view label, bool& value) {
  bool hot = false;
  const bool clicked = interact(id, row, true, hot);
  Anim& an = anim(id);
  approach(an.hover, hot ? 1.f : 0.f);
  approach(an.aux, value ? 1.f : 0.f);
  if (an.hover > 0.01f) fill(row, Color{255, 255, 255, static_cast<u8>(7 * an.hover)});

  const f32 cy = row.y + row.h * 0.5f;
  const Color lc = lerp(Color{170, 175, 187, 255}, kTextHi, an.hover);
  text(a_.button, label, row.x + u(16.f), cy + a_.button.font.pixel_height * 0.36f * k_, Align::Left, 3.4f, lc);

  const f32 pw = u(46.f), ph = u(24.f);
  const Rect pill{row.x + row.w - u(16.f) - pw, cy - ph * 0.5f, pw, ph};
  SpriteDesc d;
  d.pivot = {0.f, 0.f};
  d.position = {pill.x, pill.y};
  d.size = {pill.w, pill.h};
  d.texture = a_.atlas;
  d.uv = a_.pill.fill;
  d.color = lerp(Color{24, 26, 32, 235}, Color{190, 196, 210, 255}, an.aux);
  b_.draw(d);
  d.uv = a_.pill.edge;
  d.color = lerp(Color{150, 156, 170, 70}, Color{255, 255, 255, 170}, an.aux);
  b_.draw(d);
  const f32 kd = u(16.f);
  const f32 kx = pill.x + ph * 0.5f + (pill.w - ph) * an.aux;
  shape(theme::kDisc, {kx, cy}, kd, lerp(Color{170, 176, 190, 255}, Color{20, 22, 28, 255}, an.aux));

  rule(row.x + u(16.f), row.y + row.h, row.w - u(32.f), Color{190, 196, 208, 22});
  if (clicked) value = !value;
  return clicked;
}

bool Ui::slider(u32 id, Rect row, std::string_view label, f32& value, f32 lo, f32 hi, f32 step,
                const std::string& shown) {
  bool hot = false;
  interact(id, row, true, hot);
  Anim& an = anim(id);
  approach(an.hover, hot ? 1.f : 0.f);
  if (an.hover > 0.01f) fill(row, Color{255, 255, 255, static_cast<u8>(7 * an.hover)});

  // Wide rows: label left, track in the middle, value right. Narrow rows (portrait phones): label and
  // value share the top line, the track runs the full width underneath.
  const bool stacked = narrow_row(row.w);
  const f32 cy = stacked ? row.y + row.h * 0.74f : row.y + row.h * 0.5f;
  const f32 ty = stacked ? row.y + row.h * 0.30f : cy;
  const Color lc = lerp(Color{170, 175, 187, 255}, kTextHi, an.hover);
  text(a_.button, label, row.x + u(16.f), ty + a_.button.font.pixel_height * 0.36f * k_, Align::Left, 3.4f, lc);
  text(a_.value, shown, row.x + row.w - u(16.f), ty + a_.value.font.pixel_height * 0.36f * k_, Align::Right, 0.f, kTextHi);

  const f32 x0 = row.x + (stacked ? u(16.f) : u(200.f)), x1 = row.x + row.w - (stacked ? u(16.f) : u(100.f));
  bool changed = false;
  const f32 before = value;
  if (active_ == id && in_.down && x1 > x0) {
    const f32 t = std::clamp((in_.x - x0) / (x1 - x0), 0.f, 1.f);
    value = std::clamp(std::round((lo + t * (hi - lo)) / step) * step, lo, hi);
  }
  if (kbd_ && focus_ == id && in_.nav_x != 0) value = std::clamp(value + static_cast<f32>(in_.nav_x) * step, lo, hi);
  changed = value != before;

  const f32 t = hi > lo ? (value - lo) / (hi - lo) : 0.f;
  const f32 th = std::fmax(2.f, u(2.f));
  fill({x0, cy - th * 0.5f, x1 - x0, th}, Color{86, 91, 103, 150});
  fill({x0, cy - th * 0.5f, (x1 - x0) * t, th}, Color{214, 220, 232, 255});
  const f32 kd = u(14.f + 4.f * an.hover);
  const Vec2 kp{x0 + (x1 - x0) * t, cy};
  shape(theme::kGlow, kp, u(46.f), Color{170, 180, 204, static_cast<u8>(30 + 80 * an.hover)});
  shape(theme::kDisc, kp, kd, Color{244, 247, 252, 255});

  rule(row.x + u(16.f), row.y + row.h, row.w - u(32.f), Color{190, 196, 208, 22});
  return changed;
}

}  // namespace nv::ui
