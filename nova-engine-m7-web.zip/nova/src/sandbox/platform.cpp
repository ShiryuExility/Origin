#include "sandbox/platform.hpp"

#include <SDL3/SDL.h>

#if defined(__EMSCRIPTEN__)
#include <emscripten/emscripten.h>
#endif

namespace nv::platform {

std::string pref_dir() {
#if defined(__EMSCRIPTEN__)
  return "/persist/";
#else
  char* dir = SDL_GetPrefPath("Nova", "Sandbox");
  if (!dir) return {};
  std::string p = dir;
  SDL_free(dir);
  return p;
#endif
}

void flush_storage() {
#if defined(__EMSCRIPTEN__)
  // One sync at a time: a save that lands while a sync is running just asks for one more when it ends.
  EM_ASM({
    var run = function () {
      Module.nvSyncing = true;
      FS.syncfs(false, function (err) {
        if (err) console.warn('Nova: IndexedDB sync failed', err);
        Module.nvSyncing = false;
        if (Module.nvAgain) { Module.nvAgain = false; run(); }
      });
    };
    if (Module.nvSyncing) Module.nvAgain = true; else run();
  });
#endif
}

bool fit_window_to_page(SDL_Window* window) {
#if defined(__EMSCRIPTEN__)
  const int w = EM_ASM_INT({ return Math.floor(window.innerWidth); });
  const int h = EM_ASM_INT({ return Math.floor(window.innerHeight); });
  static int last_w = 0, last_h = 0;
  if (w <= 0 || h <= 0 || (w == last_w && h == last_h)) return false;
  last_w = w;
  last_h = h;
  SDL_SetWindowSize(window, w, h);
  return true;
#else
  (void)window;
  return false;
#endif
}

std::string clipboard_get() {
  char* t = SDL_GetClipboardText();
  if (!t) return {};
  std::string s = t;
  SDL_free(t);
  return s;
}

void clipboard_set(std::string_view text) {
  const std::string z(text);
  SDL_SetClipboardText(z.c_str());
}

void text_input(SDL_Window* window, bool on) {
#if defined(SDL_PLATFORM_ANDROID) || defined(SDL_PLATFORM_IOS)
  (void)window;
  (void)on;
#else
  if (on) SDL_StartTextInput(window);
  else SDL_StopTextInput(window);
#endif
}

}  // namespace nv::platform
