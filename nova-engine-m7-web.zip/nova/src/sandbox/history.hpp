#pragma once
// Delta-based undo / redo. Each step stores only what changed (insert / erase / replace / move of one slot),
// never a copy of the whole document: committing a stroke is O(1) in the number of objects and the history
// costs memory proportional to the edits, not to (document size x depth).
#include <algorithm>
#include <deque>
#include <memory>
#include <utility>
#include <vector>

#include "sandbox/shape.hpp"

namespace nv {

using Obj = std::shared_ptr<const Shape2D>;
using Doc = std::vector<Obj>;

struct Change {
  enum Kind : u8 { Insert, Erase, Replace, Move } kind = Insert;
  u32 index = 0;  // Insert / Erase / Replace: the slot. Move: where the object was
  u32 to = 0;     // Move: where it ends up (index in the resulting vector)
  Obj before;     // Erase / Replace: the old object
  Obj after;      // Insert / Replace: the new object
};

class History {
 public:
  static constexpr std::size_t kMaxSteps = 100;

  // Opens a new undo step (drops redo). The edit calls below append to the newest step.
  void begin() {
    redo_.clear();
    undo_.emplace_back();
    while (undo_.size() > kMaxSteps) undo_.pop_front();
  }

  void insert(Doc& d, std::size_t i, Obj o) {
    i = std::min(i, d.size());
    d.insert(d.begin() + static_cast<std::ptrdiff_t>(i), o);
    record({Change::Insert, static_cast<u32>(i), 0, nullptr, std::move(o)});
  }
  void erase(Doc& d, std::size_t i) {
    if (i >= d.size()) return;
    Obj old = std::move(d[i]);
    d.erase(d.begin() + static_cast<std::ptrdiff_t>(i));
    record({Change::Erase, static_cast<u32>(i), 0, std::move(old), nullptr});
  }
  void replace(Doc& d, std::size_t i, Obj o) {
    if (i >= d.size()) return;
    Obj old = std::exchange(d[i], o);
    record({Change::Replace, static_cast<u32>(i), 0, std::move(old), std::move(o)});
  }
  void move(Doc& d, std::size_t from, std::size_t to) {
    if (from >= d.size() || to >= d.size() || from == to) return;
    relocate(d, from, to);
    record({Change::Move, static_cast<u32>(from), static_cast<u32>(to), nullptr, nullptr});
  }

  bool undo(Doc& d) {
    if (undo_.empty()) return false;
    Step s = std::move(undo_.back());
    undo_.pop_back();
    for (auto it = s.rbegin(); it != s.rend(); ++it) apply(d, *it, false);
    redo_.push_back(std::move(s));
    return true;
  }
  bool redo(Doc& d) {
    if (redo_.empty()) return false;
    Step s = std::move(redo_.back());
    redo_.pop_back();
    for (const Change& c : s) apply(d, c, true);
    undo_.push_back(std::move(s));
    return true;
  }

  void clear() { undo_.clear(); redo_.clear(); }
  [[nodiscard]] std::size_t undo_steps() const noexcept { return undo_.size(); }
  [[nodiscard]] std::size_t redo_steps() const noexcept { return redo_.size(); }

 private:
  using Step = std::vector<Change>;

  void record(Change c) {
    if (undo_.empty()) undo_.emplace_back();  // an edit without begin(): still undoable
    undo_.back().push_back(std::move(c));
  }
  // Takes the element at `from` out and puts it at index `to` of the resulting vector.
  static void relocate(Doc& d, std::size_t from, std::size_t to) {
    const auto b = d.begin();
    if (from < to) std::rotate(b + static_cast<std::ptrdiff_t>(from), b + static_cast<std::ptrdiff_t>(from) + 1,
                               b + static_cast<std::ptrdiff_t>(to) + 1);
    else std::rotate(b + static_cast<std::ptrdiff_t>(to), b + static_cast<std::ptrdiff_t>(from),
                     b + static_cast<std::ptrdiff_t>(from) + 1);
  }
  static void apply(Doc& d, const Change& c, bool forward) {
    const auto at = static_cast<std::ptrdiff_t>(c.index);
    switch (c.kind) {
      case Change::Insert:
        if (forward) d.insert(d.begin() + at, c.after);
        else d.erase(d.begin() + at);
        break;
      case Change::Erase:
        if (forward) d.erase(d.begin() + at);
        else d.insert(d.begin() + at, c.before);
        break;
      case Change::Replace: d[c.index] = forward ? c.after : c.before; break;
      case Change::Move:
        if (forward) relocate(d, c.index, c.to);
        else relocate(d, c.to, c.index);
        break;
    }
  }

  std::deque<Step> undo_, redo_;
};

}  // namespace nv
