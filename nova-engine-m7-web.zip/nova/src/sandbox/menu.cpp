#include "sandbox/menu.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>

#include "sandbox/platform.hpp"

namespace nv::menu {
namespace {
constexpr Color kDim{122, 128, 141, 255};
constexpr Color kHi{236, 239, 244, 255};
constexpr Color kFaint{104, 109, 120, 190};
constexpr ui::Align C = ui::Align::Center;

void hud(ui::Ui& gui, const ui::Assets& a, const Stats& s) {
  char line[64];  // stack buffer: Ui::text copies it immediately
  const int n = std::snprintf(line, sizeof line, "FPS %u   /   DRAWS %u   /   SPRITES %u", s.fps, s.draw_calls, s.sprites);
  gui.text(a.label, std::string_view(line, static_cast<std::size_t>(std::max(n, 0))), gui.u(16.f), gui.u(26.f),
           ui::Align::Left, 2.6f, kFaint);
}
}  // namespace

void draw_backdrop(SpriteBatch& b, const ui::Assets& a, f32 W, f32 H, f32 density) {
  // One wide, faint light behind the title block: depth without gradients in the shaders.
  b.draw_quad(a.atlas, {W * 0.5f, H * 0.42f}, {W * 1.3f, H * 1.5f}, SpriteBatch::quantize(a.uv[theme::kGlow]),
              Color{120, 128, 146, 30});
  // Grain: the 128 px tile repeated at whole-pixel positions (no wrap mode needed, no seams).
  const f32 tile = static_cast<f32>(ui::kGrainPx) * std::fmax(1.f, std::floor(density));
  const int nx = static_cast<int>(std::ceil(W / tile)), ny = static_cast<int>(std::ceil(H / tile));
  for (int y = 0; y < ny; ++y)
    for (int x = 0; x < nx; ++x)
      if (!b.draw_quad(a.atlas, {(static_cast<f32>(x) + 0.5f) * tile, (static_cast<f32>(y) + 0.5f) * tile}, {tile, tile},
                       a.grain_q, Color{208, 214, 230, 30}))
        return;
}

Action lobby(ui::Ui& gui, const ui::Assets& a, bool show_hud, const Stats& stats) {
  const f32 W = gui.width(), H = gui.height(), cx = W * 0.5f, cy = H * 0.5f;
  const auto u = [&](f32 l) { return gui.u(l); };
  const bool portrait = gui.portrait();
  Action act = Action::None;

  const f32 bw = std::fmin(u(280.f), W - u(48.f)), bh = u(48.f), step = u(60.f);
  const f32 head = u(158.f);
  // A browser tab cannot "quit", so the web build has one button less.
  const f32 extra_rows = platform::kIsWeb ? 1.f : 2.f;
  f32 y = cy - (head + step * extra_rows + bh) * 0.5f - u(8.f);

  const f32 track = portrait ? 14.f : 22.f;  // portrait is narrower: tighter letter spacing
  gui.text(a.hero, "NOVA", cx + u(track * 0.5f), y + u(60.f), C, track, kHi);
  gui.text(a.label, "2D ENGINE", cx, y + u(92.f), C, portrait ? 3.4f : 5.f, kDim);
  gui.rule(cx - u(14.f), y + u(118.f), u(28.f), Color{190, 196, 208, 80});
  y += head;

  if (gui.button(kBtnCreate, {cx - bw * 0.5f, y, bw, bh}, "CREATE", true, true)) act = Action::Create;
  y += step;
  if (gui.button(kBtnSettings, {cx - bw * 0.5f, y, bw, bh}, "SETTINGS")) act = Action::Settings;
  if (!platform::kIsWeb) {
    y += step;
    if (gui.button(kBtnQuit, {cx - bw * 0.5f, y, bw, bh}, "QUIT")) act = Action::Quit;
  }

  gui.text(a.label, platform::kIsWeb ? "NOVA 0.4  /  WEBGL 2" : "NOVA 0.4  /  OPENGL ES 3.0", cx, H - u(26.f), C, 3.f, kFaint);
  if (show_hud) hud(gui, a, stats);
  return act;
}

Action settings_screen(ui::Ui& gui, const ui::Assets& a, bool back, Settings& st, bool& dirty, const Stats& stats) {
  const f32 W = gui.width(), H = gui.height(), cx = W * 0.5f, cy = H * 0.5f;
  const auto u = [&](f32 l) { return gui.u(l); };
  const bool portrait = gui.portrait();
  Action act = Action::None;

  const f32 rw = std::fmin(u(480.f), W - u(32.f)), rh = u(56.f);
  const f32 rs = gui.narrow_row(rw) ? u(84.f) : rh;  // sliders are two lines tall on narrow screens
  const f32 total = u(78.f) + rh + rs;
  f32 y = cy - total * 0.5f;
  const f32 x = cx - rw * 0.5f;

  gui.text(a.title, "SETTINGS", cx + u(7.f), y + u(30.f), C, 14.f, kHi);
  gui.text(a.label, "SAVED AUTOMATICALLY", cx, y + u(56.f), C, portrait ? 3.f : 4.4f, kDim);
  y += u(78.f);
  gui.rule(x + u(16.f), y, rw - u(32.f), Color{190, 196, 208, 22});
  if (gui.toggle(kSetHud, {x, y, rw, rh}, "SHOW STATS", st.show_hud)) dirty = true;
  y += rh;
  char pct[16];
  std::snprintf(pct, sizeof pct, "%d%%", static_cast<int>(std::lround(st.ui_scale * 100.f)));
  if (gui.slider(kSetScale, {x, y, rw, rs}, "UI SCALE", st.ui_scale, 0.8f, 1.25f, 0.05f, pct)) dirty = true;

  if (gui.small_button(kBtnBack, {u(28.f), H - u(28.f) - u(36.f), u(112.f), u(36.f)}, "BACK") || back) act = Action::Back;
  if (st.show_hud) hud(gui, a, stats);
  return act;
}

}  // namespace nv::menu
