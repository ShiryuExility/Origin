#include <SDL3/SDL.h>

#include <algorithm>
#include <cmath>

#include "render/atlas.hpp"
#include "sandbox/theme.hpp"
#include "sandbox/ui.hpp"

// Everything the widgets draw with: one shared atlas (white pixel, shapes, skins, grain) plus the baked fonts.
namespace nv::ui {

// ---- assets -----------------------------------------------------------------------

std::vector<u8> load_asset(const char* rel) {
  std::string path = rel;
#if defined(__EMSCRIPTEN__)
  path = std::string("/") + rel;  // --preload-file puts assets/ at the root of the virtual filesystem
#elif !defined(SDL_PLATFORM_ANDROID)
  if (const char* base = SDL_GetBasePath()) path = std::string(base) + rel;  // next to the executable
#endif
  size_t size = 0;
  void* data = SDL_LoadFile(path.c_str(), &size);
  if (!data) {
    SDL_Log("cannot load asset %s: %s", path.c_str(), SDL_GetError());
    return {};
  }
  std::vector<u8> out(static_cast<const u8*>(data), static_cast<const u8*>(data) + size);
  SDL_free(data);
  return out;
}

namespace {
bool load_font(IRenderer& r, const char* rel, f32 px, FontTex& out) {
  auto baked = bake_font(load_asset(rel), px);
  if (!baked) return false;
  out.font = std::move(*baked);
  out.tex = r.create_texture(out.font.page.width, out.font.page.height, out.font.page.rgba.data(), true);
  return true;
}
}  // namespace

Assets make_assets(IRenderer& r, f32 d) {
  Assets a;

  // ---- one atlas: white pixel block, theme shapes, then fill+edge for every skin ----
  struct SkinSpec { Skin* skin; f32 w, h, radius; };
  const SkinSpec specs[] = {{&a.wide, 320, 52, 12}, {&a.small, 112, 36, 10}, {&a.mini, 72, 32, 10}, {&a.pill, 46, 24, 12},
                            {&a.tool, 44, 44, 11},  {&a.rail, kRailW, kRailH, 14}, {&a.dock, kDockW, kDockH, 14},
                            {&a.zoom, kZoomW, kZoomH, 12}, {&a.picker, kPickerW, kPickerH, 14}, {&a.menu, kMenuW, kMenuH, 14}};
  std::vector<theme::Image> imgs;
  theme::Image white;
  white.w = white.h = 8;
  white.rgba.assign(8 * 8 * 4, 255);
  imgs.push_back(std::move(white));
  imgs.push_back(theme::soft_disc(64));
  imgs.push_back(theme::ring(64));
  imgs.push_back(theme::glow(256));
  imgs.push_back(theme::triangle(64));
  imgs.push_back(theme::crisp_disc(64));
  imgs.push_back(theme::bar(8, 64));  // keep in theme::Shape order
  const f32 line = std::fmax(1.f, d);  // 1 physical pixel border
  for (const SkinSpec& sp : specs) {
    const u32 pw = static_cast<u32>(sp.w * d), ph = static_cast<u32>(sp.h * d);
    imgs.push_back(theme::round_rect(pw, ph, sp.radius * d, 0.f));
    imgs.push_back(theme::round_rect(pw, ph, sp.radius * d, line));
  }
  imgs.push_back(theme::grain(kGrainPx, 0x51ED270Bu));  // last: index = 1 + shapes + 2 * skins
  std::vector<AtlasImage> src;
  for (const auto& im : imgs) src.push_back({im.w, im.h, im.rgba.data()});
  const Atlas atlas = build_atlas(src, AtlasConfig{.max_page_size = 2048, .padding = 2, .pow2_pages = true});
  if (!atlas.all_placed() || atlas.pages.size() != 1) {
    SDL_Log("ui atlas failed to pack into one page");
    return a;
  }
  a.atlas = r.create_texture(atlas.pages[0].width, atlas.pages[0].height, atlas.pages[0].rgba.data(), true);
  a.white = atlas.uv(0);
  a.white_q = SpriteBatch::quantize(a.white);
  for (u32 i = 0; i < theme::kShapeCount; ++i) a.uv[i] = atlas.uv(1 + i);
  u32 idx = 1 + theme::kShapeCount;
  for (const SkinSpec& sp : specs) {
    sp.skin->w = sp.w;
    sp.skin->h = sp.h;
    sp.skin->fill = atlas.uv(idx++);
    sp.skin->edge = atlas.uv(idx++);
  }
  a.grain_q = SpriteBatch::quantize(atlas.uv(idx++));
  {
    const auto disc = theme::crisp_disc(512);
    a.ellipse = r.create_texture(disc.w, disc.h, disc.rgba.data(), true);
  }
  a.fonts_ok = load_font(r, "assets/fonts/InterDisplay-Light.otf", 64.f * d, a.hero) &&
               load_font(r, "assets/fonts/InterDisplay-Light.otf", 28.f * d, a.title) &&
               load_font(r, "assets/fonts/InterDisplay-Light.otf", 19.f * d, a.value) &&
               load_font(r, "assets/fonts/Inter-Medium.otf", 10.5f * d, a.label) &&
               load_font(r, "assets/fonts/Inter-Medium.otf", 12.5f * d, a.button);
  if (!a.fonts_ok) SDL_Log("fonts missing: text disabled");
  return a;
}

void destroy_assets(IRenderer& r, Assets& a) {
  for (TextureId t : {a.atlas, a.ellipse, a.hero.tex, a.title.tex, a.value.tex, a.label.tex, a.button.tex}) r.destroy_texture(t);
  a = {};
}

}  // namespace nv::ui
