#pragma once
// Small helpers shared by editor.cpp (tools, canvas) and editor_chrome.cpp (floating UI).
#include <algorithm>
#include <cmath>

#include "core/types.hpp"

namespace nv::ed {

inline constexpr Color kPalette[7] = {{226, 230, 238, 255}, {122, 128, 141, 255}, {236, 112, 104, 255}, {240, 180, 88, 255},
                               {112, 210, 164, 255}, {106, 172, 240, 255}, {168, 138, 240, 255}};

inline bool same_rgb(Color a, Color b) { return a.r == b.r && a.g == b.g && a.b == b.b; }

inline bool contains(const Rect& r, f32 x, f32 y) { return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h; }

inline Color hsv_to_rgb(f32 h, f32 s, f32 v) {
  h -= std::floor(h);
  const f32 x = h * 6.f;
  const int i = static_cast<int>(x);
  const f32 f = x - static_cast<f32>(i);
  const f32 p = v * (1.f - s), q = v * (1.f - s * f), t = v * (1.f - s * (1.f - f));
  f32 r = v, g = t, b = p;
  switch (i % 6) {
    case 1: r = q; g = v; b = p; break;
    case 2: r = p; g = v; b = t; break;
    case 3: r = p; g = q; b = v; break;
    case 4: r = t; g = p; b = v; break;
    case 5: r = v; g = p; b = q; break;
    default: break;
  }
  const auto c8 = [](f32 x8) { return static_cast<u8>(std::clamp(x8, 0.f, 1.f) * 255.f + 0.5f); };
  return Color{c8(r), c8(g), c8(b), 255};
}

inline void rgb_to_hsv(Color c, f32 out[3]) {
  const f32 r = static_cast<f32>(c.r) / 255.f, g = static_cast<f32>(c.g) / 255.f, b = static_cast<f32>(c.b) / 255.f;
  const f32 mx = std::max({r, g, b}), mn = std::min({r, g, b}), d = mx - mn;
  f32 h = 0.f;
  if (d > 1e-6f) {
    if (mx == r) h = std::fmod((g - b) / d, 6.f);
    else if (mx == g) h = (b - r) / d + 2.f;
    else h = (r - g) / d + 4.f;
    h /= 6.f;
    if (h < 0.f) h += 1.f;
  }
  out[0] = h;
  out[1] = mx > 1e-6f ? d / mx : 0.f;
  out[2] = mx;
}

}  // namespace nv::ed
