#include "sandbox/editor.hpp"
#include "sandbox/editor_internal.hpp"
#include "sandbox/stroke.hpp"
#include "sandbox/transform.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace nv {
using namespace ed;
namespace {

constexpr f32 kBrush[3] = {3.f, 7.f, 16.f};  // world units
constexpr QuantUv kFull{0, 0, 65535, 65535};  // a texture of its own (the big ellipse)

f32 dist2(Vec2 a, Vec2 b) { const f32 dx = a.x - b.x, dy = a.y - b.y; return dx * dx + dy * dy; }

f32 seg_dist2(Vec2 p, Vec2 a, Vec2 b) {
  const f32 dx = b.x - a.x, dy = b.y - a.y;
  const f32 len2 = dx * dx + dy * dy;
  f32 t = len2 > 0.f ? ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2 : 0.f;
  t = std::clamp(t, 0.f, 1.f);
  return dist2(p, {a.x + dx * t, a.y + dy * t});
}

bool overlaps(const Rect& a, const Rect& b) {
  return a.x <= b.x + b.w && a.x + a.w >= b.x && a.y <= b.y + b.h && a.y + a.h >= b.y;
}

}  // namespace

void Editor::reset() {
  code_.close();
  doc_.clear();
  hist_.clear();
  selected_.reset();
  gesture_ = Gesture::None;
  gxf_ = {};
  cam_ = {0.f, 0.f};
  zoom_ = 1.f;
  grid_ = true;
  tool_ = Tool::Pen;
  color_ = kPalette[0];
  size_idx_ = 1;
  picker_ = custom_dirty_ = false;  // recent colors survive a new project
  menu_ = false;
  request_ = Request::None;
  status_ = nullptr;
}

void Editor::close_picker() {
  if (!picker_) return;
  picker_ = false;
  if (!custom_dirty_) return;
  custom_dirty_ = false;
  int at = recent_n_ < 5 ? recent_n_ : 4;  // drop an equal entry, else the oldest
  for (int i = 0; i < recent_n_; ++i)
    if (same_rgb(recent_[i], custom_)) { at = i; break; }
  for (int i = at; i > 0; --i) recent_[i] = recent_[i - 1];
  recent_[0] = custom_;
  if (at == recent_n_ && recent_n_ < 5) ++recent_n_;
}

// ---- commands -----------------------------------------------------------------------

void Editor::set_tool(Tool t) {
  if (locked()) return;
  tool_ = t;
  status_ = nullptr;
  // The tools that act on the current selection keep it; the drawing tools drop it.
  if (t != Tool::Select && t != Tool::Move && t != Tool::Scale && t != Tool::Rotate) selected_.reset();
}

std::size_t Editor::index_of(const Obj& o) const {
  return static_cast<std::size_t>(std::find(doc_.begin(), doc_.end(), o) - doc_.begin());
}

void Editor::undo() {
  if (locked()) return;
  if (hist_.undo(doc_)) selected_.reset();
}

void Editor::redo() {
  if (locked()) return;
  if (hist_.redo(doc_)) selected_.reset();
}

void Editor::delete_selection() {
  if (locked() || !selected_) return;
  const std::size_t i = index_of(selected_);
  if (i < doc_.size()) {
    hist_.begin();
    hist_.erase(doc_, i);
  }
  selected_.reset();
}

void Editor::duplicate_selection() {
  if (locked() || !selected_) return;
  Shape2D c = *selected_;
  const f32 d = 16.f * density_ / scale();  // a visible nudge: 16 logical px at the current zoom
  for (Vec2& q : c.pts) { q.x += d; q.y += d; }
  c.a.x += d; c.a.y += d; c.b.x += d; c.b.y += d;
  c.bounds.x += d; c.bounds.y += d;
  Obj copy = std::make_shared<const Shape2D>(std::move(c));
  hist_.begin();
  hist_.insert(doc_, doc_.size(), copy);
  selected_ = std::move(copy);
}

void Editor::bring_to_front() {
  if (locked() || !selected_) return;
  const std::size_t i = index_of(selected_);
  if (i >= doc_.size() || i + 1 == doc_.size()) return;
  hist_.begin();
  hist_.move(doc_, i, doc_.size() - 1);
}

void Editor::send_to_back() {
  if (locked() || !selected_) return;
  const std::size_t i = index_of(selected_);
  if (i >= doc_.size() || i == 0) return;
  hist_.begin();
  hist_.move(doc_, i, 0);
}

void Editor::open_code() {
  if (locked() || !selected_) return;
  menu_ = false;
  close_picker();
  const char* kind = "OBJECT";
  switch (selected_->kind) {
    case Shape2D::Stroke: kind = "STROKE"; break;
    case Shape2D::Line: kind = "LINE"; break;
    case Shape2D::Box: kind = "BOX"; break;
    case Shape2D::Oval: kind = "OVAL"; break;
  }
  code_.open(selected_->script, kind);
}

void Editor::close_code(bool apply) {
  if (!code_.is_open()) return;
  if (apply && selected_ && code_.dirty()) {
    const std::size_t at = index_of(selected_);
    if (at < doc_.size()) {
      Shape2D n = *selected_;
      n.script = code_.text();
      Obj next = std::make_shared<const Shape2D>(std::move(n));
      hist_.begin();
      hist_.replace(doc_, at, next);
      selected_ = next;
    }
  }
  code_.close();
}

void Editor::zoom_to_fit() {
  if (locked() || W_ <= 0.f || H_ <= 0.f) return;
  if (doc_.empty()) { reset_view(); return; }
  Rect u = doc_.front()->bounds;
  f32 x1 = u.x + u.w, y1 = u.y + u.h;
  for (const Obj& o : doc_) {
    const Rect& r = o->bounds;
    u.x = std::min(u.x, r.x); u.y = std::min(u.y, r.y);
    x1 = std::max(x1, r.x + r.w); y1 = std::max(y1, r.y + r.h);
  }
  const f32 bw = std::max(x1 - u.x, 1.f), bh = std::max(y1 - u.y, 1.f);
  const f32 fit = std::min(W_ * 0.84f / bw, H_ * 0.84f / bh);  // physical px per world unit that fits with a margin
  zoom_ = std::clamp(fit / density_, 0.05f, 8.f);              // never blow a single dot up past 800%
  cam_ = {u.x + bw * 0.5f, u.y + bh * 0.5f};
}

bool Editor::load_project(std::span<const u8> bytes) {
  if (locked()) return false;
  std::optional<Project> p = parse_project(bytes);
  if (!p) return false;
  doc_ = std::move(p->shapes);
  hist_.clear();
  selected_.reset();
  cam_ = p->cam;
  zoom_ = p->zoom;
  return true;
}

void Editor::zoom_by(f32 factor, f32 sx, f32 sy, f32 W, f32 H) {
  const Vec2 before = to_world(sx, sy, W, H);
  zoom_ = std::clamp(zoom_ * factor, 0.05f, 32.f);
  cam_.x = before.x - (sx - W * 0.5f) / scale();
  cam_.y = before.y - (sy - H * 0.5f) / scale();
}

void Editor::pinch(f32 cx, f32 cy, f32 factor, f32 dx, f32 dy, f32 W, f32 H) {
  pan_pixels(-dx, -dy);  // content follows the fingers...
  zoom_by(factor, cx, cy, W, H);  // ...then scales about where they are now
}

void Editor::cancel_gesture() {
  if (gesture_ == Gesture::Draw) draft_ = {};  // unfinished stroke / shape: discarded, nothing committed
  drag_delta_ = {};                              // an unfinished move / scale / rotate: the object stays as it was
  gxf_ = {};
  gesture_ = Gesture::None;
}

// ---- hit testing --------------------------------------------------------------------

bool Editor::hit(const Shape2D& s, Vec2 p, f32 tol) const {
  const Rect& r = s.bounds;
  if (p.x < r.x - tol || p.x > r.x + r.w + tol || p.y < r.y - tol || p.y > r.y + r.h + tol) return false;
  const f32 reach = s.width * 0.5f + tol;
  switch (s.kind) {
    case Shape2D::Stroke:
      if (s.pts.size() == 1) return dist2(p, s.pts[0]) <= reach * reach;
      for (std::size_t i = 1; i < s.pts.size(); ++i)
        if (seg_dist2(p, s.pts[i - 1], s.pts[i]) <= reach * reach) return true;
      return false;
    case Shape2D::Line: return seg_dist2(p, s.a, s.b) <= reach * reach;
    case Shape2D::Box: {
      const Frame f = frame_of(s, 0.f);
      const Vec2 l = frame_to_local(f, p);  // rotated boxes: test in their own axes
      return std::fabs(l.x) <= f.hx + tol && std::fabs(l.y) <= f.hy + tol;
    }
    case Shape2D::Oval: {
      const Frame f = frame_of(s, 0.f);
      const Vec2 l = frame_to_local(f, p);
      const f32 dx = l.x / (f.hx + tol), dy = l.y / (f.hy + tol);
      return dx * dx + dy * dy <= 1.f;
    }
  }
  return false;
}

int Editor::pick(Vec2 p, f32 tol) const {
  for (int i = static_cast<int>(doc_.size()) - 1; i >= 0; --i)
    if (hit(*doc_[static_cast<std::size_t>(i)], p, tol)) return i;
  return -1;
}

// ---- per-frame input ----------------------------------------------------------------

void Editor::finish_draft() {
  const f32 sc = scale();
  Shape2D s = draft_;
  bool keep = true;
  if (s.kind == Shape2D::Stroke) {
    if (s.pts.size() == 1) s.pts.push_back(s.pts[0]);  // a click makes a dot
    // Drop points that sit within ~0.4 screen px (and at most 15% of the brush) of the line between their
    // neighbours: far fewer sprites per stroke, no visible change at the zoom it was drawn at.
    else simplify_stroke(s.pts, std::min(0.4f / sc, s.width * 0.15f));
  } else if (s.kind == Shape2D::Line) {
    keep = dist2(s.a, s.b) * sc * sc >= 9.f;
  } else {
    keep = (s.b.x - s.a.x) * sc >= 3.f && (s.b.y - s.a.y) * sc >= 3.f;
  }
  if (!keep) return;
  compute_bounds(s);
  hist_.begin();  // a delta, not a copy of the document
  hist_.insert(doc_, doc_.size(), std::make_shared<const Shape2D>(std::move(s)));
}

void Editor::update(const Pointer& p, f32 W, f32 H, bool over_chrome) {
  W_ = W;
  H_ = H;
  if (code_.is_open()) return;  // the code screen owns the input
  if (p.pressed && !over_chrome) {  // touching the canvas dismisses the action menu and the last status message
    menu_ = false;
    status_ = nullptr;
  }
  const Vec2 w = to_world(p.x, p.y, W, H);
  ptr_world_ = w;
  ptr_on_canvas_ = !over_chrome;
  const f32 sc = scale();
  const f32 tol = 7.f * density_ / sc;  // forgiving touch target, in world units

  if (p.wheel != 0.f && !over_chrome) zoom_by(std::pow(1.12f, p.wheel), p.x, p.y, W, H);

  // ---- start a gesture ----
  bool started_now = false;  // a gesture that begins this frame starts at the latest position: the trail is older
  if (gesture_ == Gesture::None && !over_chrome) {
    started_now = p.pressed || p.pan_down;
    if (p.pan_down || (p.pressed && tool_ == Tool::Hand)) {
      gesture_ = Gesture::Pan;
      prev_screen_ = {p.x, p.y};
    } else if (p.pressed) {
      switch (tool_) {
        case Tool::Pen:
          draft_ = {};
          draft_.kind = Shape2D::Stroke;
          draft_.color = color_;
          draft_.width = kBrush[size_idx_];
          draft_.pts = {w};
          last_world_ = w;
          gesture_ = Gesture::Draw;
          break;
        case Tool::Line:
        case Tool::Rect:
        case Tool::Ellipse:
          draft_ = {};
          draft_.kind = tool_ == Tool::Line ? Shape2D::Line : (tool_ == Tool::Rect ? Shape2D::Box : Shape2D::Oval);
          draft_.color = color_;
          draft_.width = kBrush[size_idx_];
          draft_.a = draft_.b = anchor_ = w;
          compute_bounds(draft_);
          gesture_ = Gesture::Draw;
          break;
        case Tool::Select: {  // picking only: a drag here never changes anything
          const int i = pick(w, tol);
          if (i >= 0) selected_ = doc_[static_cast<std::size_t>(i)];
          else if (selected_ && !in_selection_box(w, tol)) selected_ = nullptr;
          break;
        }
        case Tool::Move: {  // grab an object (or the inside of the selection box: thin strokes) and drag it
          const int i = pick(w, tol);
          bool grab = i >= 0;
          if (grab) selected_ = doc_[static_cast<std::size_t>(i)];
          else if (selected_) grab = in_selection_box(w, tol);
          if (grab) {
            gesture_ = Gesture::Move;
            anchor_ = w;
            drag_delta_ = {};
          }
          break;
        }
        case Tool::Scale: {  // drag a handle of the selection; a tap elsewhere only picks
          const Handle h = handle_at(w);
          if (h != Handle::None) {
            gframe_ = frame_of(*selected_, min_half());
            ghandle_ = h;
            gstart_ = frame_to_local(gframe_, w);
            gxf_ = {};
            preview_ = *selected_;
            gesture_ = Gesture::Scale;
            break;
          }
          const int i = pick(w, tol);
          if (i >= 0) selected_ = doc_[static_cast<std::size_t>(i)];
          break;
        }
        case Tool::Rotate: {  // tap picks an object, a drag anywhere turns the selection about its center
          const int i = pick(w, tol);
          rot_empty_ = i < 0;
          if (i >= 0) selected_ = doc_[static_cast<std::size_t>(i)];
          if (selected_) {
            gframe_ = frame_of(*selected_, min_half());
            ghandle_ = Handle::Rotate;
            gstart_angle_ = std::atan2(w.y - gframe_.c.y, w.x - gframe_.c.x);
            const f32 dead = 14.f * density_;
            rot_arm_ = dist2(w, gframe_.c) * sc * sc < dead * dead;  // pressed on the pivot: angle is meaningless there
            gxf_ = {};
            preview_ = *selected_;
            gesture_ = Gesture::Rotate;
          }
          break;
        }
        case Tool::Eraser:
          gesture_ = Gesture::Erase;
          erase_pushed_ = false;
          break;
        default:
          break;
      }
    }
  }

  // ---- continue / finish ----
  switch (gesture_) {
    case Gesture::Pan:
      if (p.pan_down || (tool_ == Tool::Hand && p.down)) {
        cam_.x -= (p.x - prev_screen_.x) / sc;
        cam_.y -= (p.y - prev_screen_.y) / sc;
        prev_screen_ = {p.x, p.y};
      } else {
        gesture_ = Gesture::None;
      }
      break;
    case Gesture::Draw:
      if (draft_.kind == Shape2D::Stroke) {
        if (!started_now) {  // every position the device reported since the last frame, oldest first
          for (int i = 0; i < p.trail_n; ++i) {
            const Vec2 t = to_world(p.trail[i].x, p.trail[i].y, W, H);
            if (dist2(t, last_world_) * sc * sc >= 2.25f) {
              draft_.pts.push_back(t);
              last_world_ = t;
            }
          }
        }
        if (dist2(w, last_world_) * sc * sc >= 2.25f) {  // 1.5 px: keeps strokes light
          draft_.pts.push_back(w);
          last_world_ = w;
        }
      } else if (draft_.kind == Shape2D::Line) {
        draft_.b = w;
      } else {
        draft_.a = {std::min(anchor_.x, w.x), std::min(anchor_.y, w.y)};
        draft_.b = {std::max(anchor_.x, w.x), std::max(anchor_.y, w.y)};
      }
      if (draft_.kind != Shape2D::Stroke) compute_bounds(draft_);
      if (!p.down || p.released) {
        if (draft_.kind == Shape2D::Stroke && dist2(w, last_world_) > 0.f) draft_.pts.push_back(w);
        finish_draft();
        gesture_ = Gesture::None;
      }
      break;
    case Gesture::Move:
      drag_delta_ = {w.x - anchor_.x, w.y - anchor_.y};
      if (!p.down || p.released) {
        if (selected_ && dist2(drag_delta_, {}) * sc * sc >= 1.f) {
          Shape2D m = *selected_;
          for (Vec2& q : m.pts) { q.x += drag_delta_.x; q.y += drag_delta_.y; }
          m.a.x += drag_delta_.x; m.a.y += drag_delta_.y;
          m.b.x += drag_delta_.x; m.b.y += drag_delta_.y;
          m.bounds.x += drag_delta_.x; m.bounds.y += drag_delta_.y;
          Obj moved = std::make_shared<const Shape2D>(std::move(m));
          const std::size_t at = index_of(selected_);
          if (at < doc_.size()) {
            hist_.begin();
            hist_.replace(doc_, at, moved);
            selected_ = moved;
          }
        }
        drag_delta_ = {};
        gesture_ = Gesture::None;
      }
      break;
    case Gesture::Scale:
    case Gesture::Rotate: {
      if (gesture_ == Gesture::Scale) {
        const Vec2 l = frame_to_local(gframe_, w);
        gxf_ = scale_xf(gframe_, ghandle_, {l.x - gstart_.x, l.y - gstart_.y});
      } else {
        bool turn = true;
        if (tool_ == Tool::Rotate) {  // near the pivot the angle jitters: hold still until the pointer is clear of it
          const f32 dead = 14.f * density_;
          const bool near_pivot = dist2(w, gframe_.c) * sc * sc < dead * dead;
          if (rot_arm_ && !near_pivot) {
            rot_arm_ = false;
            gstart_angle_ = std::atan2(w.y - gframe_.c.y, w.x - gframe_.c.x);
          }
          turn = !rot_arm_ && !near_pivot;
        }
        if (turn) {
          const f32 d = std::remainder(std::atan2(w.y - gframe_.c.y, w.x - gframe_.c.x) - gstart_angle_,
                                       2.f * std::numbers::pi_v<f32>);
          gxf_ = {};
          gxf_.rotate = snap_angle(gframe_.rot + d) - gframe_.rot;
        }
      }
      if (selected_) preview_ = transformed(*selected_, gframe_, gxf_);
      if (!p.down || p.released) {
        const bool changed = gesture_ == Gesture::Scale
                                 ? std::fabs(gxf_.scale.x - 1.f) > 0.002f || std::fabs(gxf_.scale.y - 1.f) > 0.002f
                                 : std::fabs(gxf_.rotate) > 0.002f;
        if (selected_ && changed) {
          Obj next_obj = std::make_shared<const Shape2D>(preview_);
          const std::size_t at = index_of(selected_);
          if (at < doc_.size()) {
            hist_.begin();
            hist_.replace(doc_, at, next_obj);
            selected_ = next_obj;
          }
        }
        if (tool_ == Tool::Rotate && rot_empty_ && !changed) selected_.reset();  // tapped empty space: deselect
        gxf_ = {};
        rot_arm_ = false;
        gesture_ = Gesture::None;
      }
      break;
    }
    case Gesture::Erase: {
      const int i = pick(w, tol * 1.2f);
      if (i >= 0) {
        if (!erase_pushed_) {  // one undo step per drag
          hist_.begin();
          erase_pushed_ = true;
        }
        hist_.erase(doc_, static_cast<std::size_t>(i));
      }
      if (!p.down || p.released) gesture_ = Gesture::None;
      break;
    }
    case Gesture::None:
      break;
  }
}

// ---- drawing ------------------------------------------------------------------------

f32 Editor::sel_pad(const Shape2D& s) const noexcept {
  const f32 base = 4.f * density_ / scale();
  return s.kind == Shape2D::Stroke || s.kind == Shape2D::Line ? s.width * 0.5f + base : base;
}

// True when `w` lies inside the selection's box (plus the pick tolerance).
bool Editor::in_selection_box(Vec2 w, f32 tol) const {
  if (!selected_) return false;
  const Frame f = frame_of(*selected_, min_half());
  const Vec2 l = frame_to_local(f, w);
  const f32 pad = sel_pad(*selected_) + tol;
  return std::fabs(l.x) <= f.hx + pad && std::fabs(l.y) <= f.hy + pad;
}

// Side handles only appear when their edge is long enough on screen to grab them apart from the corners.
bool Editor::handle_enabled(const Frame& f, Handle h, f32 pad) const noexcept {
  if (h == Handle::Rotate || is_corner(h)) return true;
  const bool horizontal_edge = h == Handle::N || h == Handle::S;
  const f32 len = 2.f * (horizontal_edge ? f.hx + pad : f.hy + pad) * scale();
  return len >= 64.f * density_;
}

Handle Editor::handle_at(Vec2 w) const {
  if (!selected_) return Handle::None;
  const f32 px = 1.f / scale(), reach = 20.f * density_ * px;
  const Frame f = frame_of(*selected_, min_half());
  const f32 pad = sel_pad(*selected_), rot_off = 30.f * density_ * px;
  const Vec2 pl = frame_to_local(f, w);
  Handle best = Handle::None;
  f32 best_d2 = reach * reach;
  // No rotate handle here on purpose: turning is the Rotate tool's job, so a slip while moving or resizing
  // can never spin the object.
  for (const Handle h : {Handle::NW, Handle::NE, Handle::SE, Handle::SW, Handle::N, Handle::E, Handle::S, Handle::W}) {
    if (!handle_enabled(f, h, pad)) continue;
    const Vec2 hp = handle_local(f, h, pad, rot_off);
    const f32 d2 = dist2(pl, hp);
    if (d2 <= best_d2) { best_d2 = d2; best = h; }
  }
  return best;
}

void Editor::draw_shape(SpriteBatch& b, const ui::Assets& a, const Quv& q, const Shape2D& s, Vec2 off, f32 px,
                        const Rect* cull) const {
  // `px` = world units per physical pixel
  const auto cap = [&](Vec2 c) { b.draw_quad(a.atlas, {c.x + off.x, c.y + off.y}, {s.width, s.width}, q.disc, s.color); };
  const auto body = [&](Vec2 p, Vec2 e) {
    b.draw_segment(a.atlas, {p.x + off.x, p.y + off.y}, {e.x + off.x, e.y + off.y}, s.width, q.bar, s.color);
  };
  switch (s.kind) {
    case Shape2D::Stroke: {
      const bool joints = s.width / px >= 3.f;  // thin strokes: round ends only
      const f32 min_step2 = px * px;            // ~1 physical pixel: drop points the eye cannot resolve
      // Partly visible stroke: skip the segments that lie fully outside the view (a long scribble zoomed in
      // would otherwise submit every segment of it). `cull` is in world space, the points are not offset yet.
      f32 cx0 = 0.f, cy0 = 0.f, cx1 = 0.f, cy1 = 0.f;
      if (cull) {
        const f32 pad = s.width * 0.5f;
        cx0 = cull->x - off.x - pad; cy0 = cull->y - off.y - pad;
        cx1 = cull->x + cull->w - off.x + pad; cy1 = cull->y + cull->h - off.y + pad;
      }
      const auto outside = [&](Vec2 p, Vec2 e) {
        return cull && (std::max(p.x, e.x) < cx0 || std::min(p.x, e.x) > cx1 || std::max(p.y, e.y) < cy0 ||
                        std::min(p.y, e.y) > cy1);
      };
      Vec2 prev = s.pts.front();
      if (!outside(prev, prev)) cap(prev);
      for (std::size_t i = 1; i < s.pts.size(); ++i) {
        const Vec2 e = s.pts[i];
        const bool last = i + 1 == s.pts.size();
        if (!last && dist2(prev, e) < min_step2) continue;
        if (!outside(prev, e)) {
          body(prev, e);
          if (joints || last) cap(e);
        }
        prev = e;
      }
      break;
    }
    case Shape2D::Line:
      body(s.a, s.b);
      cap(s.a);
      cap(s.b);
      break;
    case Shape2D::Box: {
      const Vec2 c{(s.a.x + s.b.x) * 0.5f + off.x, (s.a.y + s.b.y) * 0.5f + off.y};
      if (s.rot == 0.f) {
        b.draw_quad(a.atlas, c, {s.b.x - s.a.x, s.b.y - s.a.y}, a.white_q, s.color);
      } else {
        SpriteDesc d;
        d.texture = a.atlas; d.position = c; d.size = {s.b.x - s.a.x, s.b.y - s.a.y};
        d.rotation = s.rot; d.uv = a.white; d.color = s.color;
        b.draw(d);
      }
      break;
    }
    case Shape2D::Oval: {
      const bool big = (s.b.x - s.a.x) / px > 96.f || (s.b.y - s.a.y) / px > 96.f;
      const Vec2 c{(s.a.x + s.b.x) * 0.5f + off.x, (s.a.y + s.b.y) * 0.5f + off.y};
      if (s.rot == 0.f) {
        b.draw_quad(big ? a.ellipse : a.atlas, c, {s.b.x - s.a.x, s.b.y - s.a.y}, big ? kFull : q.disc, s.color);
      } else {
        SpriteDesc d;
        d.texture = big ? a.ellipse : a.atlas; d.position = c; d.size = {s.b.x - s.a.x, s.b.y - s.a.y};
        d.rotation = s.rot; d.uv = big ? Rect{0.f, 0.f, 1.f, 1.f} : a.uv[theme::kCrisp]; d.color = s.color;
        b.draw(d);
      }
      break;
    }
  }
}

void Editor::draw_canvas(SpriteBatch& b, const ui::Assets& a, f32 W, f32 H, const Flush& flush) const {
  if (code_.is_open()) return;  // the code screen covers everything
  const f32 sc = scale(), px = 1.f / sc;
  const Quv quv{SpriteBatch::quantize(a.uv[theme::kCrisp]), SpriteBatch::quantize(a.uv[theme::kBar])};
  const Rect view{cam_.x - W * 0.5f * px, cam_.y - H * 0.5f * px, W * px, H * px};
  const f32 line = std::fmax(1.f, std::round(density_)) * px;  // exactly 1 physical pixel

  // ---- grid ----
  if (grid_) {
    f32 step = 64.f;
    while (step * sc < 22.f * density_) step *= 2.f;
    while (step * sc > 180.f * density_ && step > 8.f) step *= 0.5f;
    const auto lines = [&](bool vertical) {
      const f32 lo = vertical ? view.x : view.y, hi = lo + (vertical ? view.w : view.h);
      for (i32 i = static_cast<i32>(std::floor(lo / step)); static_cast<f32>(i) * step <= hi; ++i) {
        const f32 at = static_cast<f32>(i) * step;
        const bool axis = i == 0, major = i % 4 == 0;
        const Color c = axis ? Color{214, 220, 234, 74} : (major ? Color{200, 206, 220, 34} : Color{200, 206, 220, 15});
        if (vertical) b.draw_quad(a.atlas, {at, cam_.y}, {line, view.h}, a.white_q, c);
        else b.draw_quad(a.atlas, {cam_.x, at}, {view.w, line}, a.white_q, c);
      }
    };
    lines(true);
    lines(false);
  }

  // ---- drawing ----
  const Vec2 none{};
  for (const Obj& o : doc_) {
    const Shape2D& s = *o;
    const bool moving = gesture_ == Gesture::Move && o == selected_;
    const bool xf = (gesture_ == Gesture::Scale || gesture_ == Gesture::Rotate) && o == selected_;
    const Shape2D& shown = xf ? preview_ : s;  // while scaling / rotating, draw the transformed copy instead
    Rect bb = shown.bounds;
    if (moving) { bb.x += drag_delta_.x; bb.y += drag_delta_.y; }
    if (!overlaps(bb, view)) continue;  // off screen
    if (bb.w < 2.f * px && bb.h < 2.f * px) {
      // Smaller than 2 physical pixels in both directions (zoomed far out): one flat quad stands in for
      // the whole object. Thousands of tiny strokes cost one sprite each instead of dozens.
      if (b.sprite_count() + 32 > b.capacity()) flush();
      b.draw_quad(a.atlas, {bb.x + bb.w * 0.5f, bb.y + bb.h * 0.5f}, {std::max(bb.w, px), std::max(bb.h, px)},
                  a.white_q, shown.color);
      continue;
    }
    const bool inside = bb.x >= view.x && bb.y >= view.y && bb.x + bb.w <= view.x + view.w && bb.y + bb.h <= view.y + view.h;
    // Few segments: culling them one by one costs more than drawing them. Many and partly off screen: cull.
    const bool cull_segments = !inside && shown.kind == Shape2D::Stroke && shown.pts.size() > 64;
    // A culled stroke only submits its visible part, so budget for what can show, not for every point.
    const std::size_t cost = shown.kind == Shape2D::Stroke ? shown.pts.size() * 2 + 2 : 3;
    if (b.sprite_count() + cost + 28 > b.capacity()) flush();
    draw_shape(b, a, quv, shown, moving ? drag_delta_ : none, px, cull_segments ? &view : nullptr);
  }
  if (gesture_ == Gesture::Draw) draw_shape(b, a, quv, draft_, none, px);

  // ---- selection: oriented box, corner + side scale handles, rotate handle ----
  if (selected_) {
    const bool xf = gesture_ == Gesture::Scale || gesture_ == Gesture::Rotate;
    const Shape2D& ss = xf ? preview_ : *selected_;
    Frame f = frame_of(ss, min_half());
    if (gesture_ == Gesture::Move) { f.c.x += drag_delta_.x; f.c.y += drag_delta_.y; }
    const f32 pad = sel_pad(ss), t = std::fmax(1.f, density_) * px * 1.5f, rot_off = 30.f * density_ * px;
    const Color line_c{196, 208, 232, 235}, handle_c{236, 240, 248, 255};
    const f32 ex = f.hx + pad, ey = f.hy + pad;
    const Vec2 k[4] = {frame_to_world(f, {-ex, -ey}), frame_to_world(f, {ex, -ey}), frame_to_world(f, {ex, ey}),
                       frame_to_world(f, {-ex, ey})};
    for (int i = 0; i < 4; ++i) b.draw_segment(a.atlas, k[i], k[(i + 1) % 4], t, quv.bar, line_c);
    if (tool_ == Tool::Rotate) {  // no handles: a pivot dot, and while turning a line from it to the pointer
      const f32 d = 12.f * density_ * px;
      if (gesture_ == Gesture::Rotate && !rot_arm_)
        b.draw_segment(a.atlas, f.c, ptr_world_, t, quv.bar, Color{106, 172, 240, 210});
      b.draw_quad(a.atlas, f.c, {d, d}, quv.disc, handle_c);
    } else if (tool_ == Tool::Scale) {  // resize handles appear only with the Scale tool
      for (const Handle h : {Handle::NW, Handle::NE, Handle::SE, Handle::SW, Handle::N, Handle::E, Handle::S, Handle::W}) {
        if (!handle_enabled(f, h, pad)) continue;
        const f32 d = (is_corner(h) ? 10.f : 8.f) * density_ * px;
        b.draw_quad(a.atlas, frame_to_world(f, handle_local(f, h, pad, rot_off)), {d, d}, quv.disc, handle_c);
      }
    }
  }

  // ---- brush cursor ----
  if (ptr_on_canvas_ && gesture_ != Gesture::Pan && (tool_ == Tool::Pen || tool_ == Tool::Eraser)) {
    const f32 d = tool_ == Tool::Pen ? std::fmax(kBrush[size_idx_], 8.f * density_ * px) : 16.f * density_ * px;
    b.draw_quad(a.atlas, ptr_world_, {d, d}, SpriteBatch::quantize(a.uv[theme::kRing]), Color{226, 230, 238, 150});
  }
}

// ---- chrome -------------------------------------------------------------------------

}  // namespace nv
