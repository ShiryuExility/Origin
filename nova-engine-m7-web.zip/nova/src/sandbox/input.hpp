#pragma once
// SDL events -> per-frame UI input, pointer state and (in the editor) keyboard shortcuts.
#include "core/types.hpp"
#include "render/renderer.hpp"
#include "sandbox/edit_events.hpp"
#include "sandbox/editor.hpp"
#include "sandbox/ui.hpp"

struct SDL_Window;

namespace nv {

// Two-finger gesture, accumulated over one frame's events.
struct Pinch {
  bool active = false;  // two fingers moved this frame
  bool cancel = false;  // a second finger just landed: drop what the first one started
  f32 cx = 0.f, cy = 0.f;   // midpoint of the fingers (window pixels)
  f32 factor = 1.f;         // zoom change (>1 = fingers moved apart)
  f32 dx = 0.f, dy = 0.f;   // midpoint travel (window pixels)
};

struct InputFrame {
  ui::Input in;
  Pointer ptr;
  Pinch pinch;
  f32 width = 0.f, height = 0.f;  // window size in pixels, refreshed by poll_input
  bool quit = false;              // window close requested
  EditQueue edits;                // text typed this frame while the code editor is open (keys + OS text input)

  // Finger tracking that lives across frames (touched only by poll_input). While two fingers are down the
  // touch->mouse emulation is ignored until every finger lifts, so a pinch can never draw.
  struct Finger { u64 id = 0; f32 x = 0.f, y = 0.f; bool down = false; } fingers[2];
  bool latched = false;
  f32 prev_dist = 0.f, prev_cx = 0.f, prev_cy = 0.f;
};

// Resets the per-frame fields of `f`, then drains the SDL event queue into it. Returns true if any event
// arrived. `editor_active`: letters are tool shortcuts (editor screen) instead of menu navigation.
bool poll_input(InputFrame& f, SDL_Window* window, IRenderer& renderer, f32 density, bool editor_active,
                Editor& editor);

}  // namespace nv
