#include "sandbox/project_io.hpp"

#include <SDL3/SDL.h>

#include <string>

#include "sandbox/platform.hpp"

namespace nv {
namespace {
std::string project_path() {
  const std::string dir = platform::pref_dir();
  return dir.empty() ? std::string{} : dir + "project.nova";
}
}  // namespace

bool save_project_file(std::span<const u8> bytes) {
  const std::string path = project_path();
  if (path.empty() || bytes.empty()) return false;
  const std::string tmp = path + ".tmp";
  if (!SDL_SaveFile(tmp.c_str(), bytes.data(), bytes.size())) return false;
  if (!SDL_RenamePath(tmp.c_str(), path.c_str())) {  // replaces an existing file
    SDL_RemovePath(tmp.c_str());
    return false;
  }
  platform::flush_storage();  // browser: persist to IndexedDB (no-op elsewhere)
  return true;
}

std::vector<u8> load_project_file() {
  const std::string path = project_path();
  if (path.empty()) return {};
  std::size_t size = 0;
  void* data = SDL_LoadFile(path.c_str(), &size);
  if (!data) return {};
  const u8* p = static_cast<const u8*>(data);
  std::vector<u8> out(p, p + size);
  SDL_free(data);
  return out;
}

const char* project_save(const Editor& editor) {
  const std::vector<u8> bytes = editor.save_project();
  if (!save_project_file(bytes)) {
    SDL_Log("project save failed");
    return "SAVE FAILED";
  }
  SDL_Log("project saved (%u objects, %u bytes)", editor.object_count(), static_cast<u32>(bytes.size()));
  return "SAVED";
}

const char* project_open(Editor& editor) {
  const std::vector<u8> bytes = load_project_file();
  if (bytes.empty()) {
    SDL_Log("no saved project yet");
    return "NO SAVED PROJECT";
  }
  if (!editor.load_project(bytes)) {
    SDL_Log("project file is damaged or newer than this build: nothing changed");
    return "FILE UNREADABLE";
  }
  SDL_Log("project opened (%u objects)", editor.object_count());
  return "OPENED";
}

}  // namespace nv
