#include "sandbox/code_editor.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>

#include "sandbox/platform.hpp"

namespace nv {
namespace {

constexpr Color kBg{11, 12, 16, 255}, kAreaBg{16, 17, 22, 255}, kGutterBg{13, 14, 19, 255};
constexpr Color kEdge{190, 196, 208, 40}, kText{226, 230, 238, 255}, kDim{104, 109, 120, 210};
constexpr Color kGutterNum{88, 93, 105, 255}, kGutterHi{170, 176, 190, 255};
constexpr Color kSelFill{106, 172, 240, 78}, kCaret{236, 240, 248, 255}, kLineHi{255, 255, 255, 9};
constexpr Color kAccent{106, 172, 240, 255};

Color tok_color(Tok t) {
  switch (t) {
    case Tok::Keyword: return {168, 138, 240, 255};
    case Tok::String: return {112, 210, 164, 255};
    case Tok::Number: return {240, 180, 88, 255};
    case Tok::Comment: return {104, 109, 120, 255};
    case Tok::Punct: return {150, 156, 170, 255};
    default: return kText;
  }
}

bool inside(const Rect& r, f32 x, f32 y) { return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h; }

enum Id : u32 { kApply = 400, kCancel = 401, kToolBase = 410, kKeyBase = 500 };

// On-screen keyboard key. act: 0 types `ch`, 1 sends `ev`, 2 toggles shift, 3 toggles the symbols page.
struct Key {
  std::string_view label;
  char ch = 0;
  u8 act = 0;
  EditEvent::Kind ev = EditEvent::Char;
  f32 w = 1.f;  // in key units
};
constexpr u8 kActChar = 0, kActEvent = 1, kActShift = 2, kActSym = 3;
constexpr int kKeyRows = 5, kKeyCols = 12;

struct TbItem {
  const char* label;
  EditEvent::Kind ev;
  u8 special;  // 0 = event, 1 = SEL toggle, 2 = KEYS toggle
  f32 w;       // logical width
};
constexpr TbItem kToolbar[] = {{"UNDO", EditEvent::Undo, 0, 48},    {"REDO", EditEvent::Redo, 0, 48},
                               {"SEL", EditEvent::Char, 1, 40},     {"ALL", EditEvent::SelectAll, 0, 38},
                               {"COPY", EditEvent::Copy, 0, 48},    {"CUT", EditEvent::Cut, 0, 40},
                               {"PASTE", EditEvent::Paste, 0, 54},  {"<", EditEvent::Left, 0, 34},
                               {">", EditEvent::Right, 0, 34},      {"^", EditEvent::Up, 0, 34},
                               {"v", EditEvent::Down, 0, 34},       {"KEYS", EditEvent::Char, 2, 50}};
constexpr int kToolbarN = static_cast<int>(sizeof(kToolbar) / sizeof(kToolbar[0]));

constexpr const char* kLow = "qwertyuiopasdfghjklzxcvbnm";
constexpr const char* kUp = "QWERTYUIOPASDFGHJKLZXCVBNM";

}  // namespace

bool CodeEditor::run_event(const EditEvent& e, std::string_view system_paste) {
  if (apply_edit(buf_, e, clip_, system_paste)) platform::clipboard_set(clip_);
  follow_ = true;
  return true;
}

CodeResult CodeEditor::frame(ui::Ui& gui, const CodeFrame& f) {
  const ui::Assets& a = gui.assets();
  const auto u = [&](f32 v) { return gui.u(v); };
  const f32 W = f.width, H = f.height, k = gui.k();
  const BakedFont& font = a.button.font;
  CodeResult result = CodeResult::None;

  // ---- keys typed this frame (physical keyboard / OS text input) ----
  if (f.keys)
    for (int i = 0; i < f.keys->n; ++i) run_event(f.keys->ev[i], f.keys->paste);

  // ---- layout ----
  const f32 m = u(8.f), kgap = u(4.f), bar_h = u(44.f), tb_h = u(32.f);
  Rect tb_rect[kToolbarN];
  int tb_rows = 1;
  {
    f32 x = m, y = bar_h + kgap;
    for (int i = 0; i < kToolbarN; ++i) {
      const f32 w = u(kToolbar[i].w);
      if (x + w > W - m && x > m) {  // wrap
        x = m;
        y += tb_h + kgap;
        ++tb_rows;
      }
      tb_rect[i] = {x, y, w, tb_h};
      x += w + kgap;
    }
  }
  const f32 tb_bottom = bar_h + kgap + static_cast<f32>(tb_rows) * (tb_h + kgap);
  const f32 kh = std::clamp(H * 0.105f, u(30.f), u(44.f));
  const f32 osk_h = keys_open_ ? static_cast<f32>(kKeyRows) * kh + kgap : 0.f;
  const f32 osk_top = H - osk_h;
  const Rect area{0.f, tb_bottom, W, std::fmax(0.f, osk_top - tb_bottom)};

  // ---- text metrics ----
  const f32 lh = std::round(font.line_height() * k * 1.25f);
  const f32 base_off = std::round((lh - (font.ascent - font.descent) * k) * 0.5f + font.ascent * k);
  const auto adv = [&](char c) { return font.glyph(c).advance * k; };
  const std::string& text = buf_.str();
  const std::size_t lines = buf_.line_count();
  int digits = 2;
  for (std::size_t n = lines; n >= 100; n /= 10) ++digits;
  const f32 gw = static_cast<f32>(digits) * adv('0') + u(16.f);
  const f32 text_x0 = area.x + gw + u(8.f), clip_x0 = text_x0, clip_x1 = area.x + area.w - u(6.f);
  const f32 view_w = std::fmax(1.f, clip_x1 - clip_x0);
  const f32 vis_h = std::floor(area.h / lh) * lh;
  const auto width_of = [&](std::size_t from, std::size_t to) {
    f32 w = 0.f;
    for (std::size_t i = from; i < to; ++i) w += adv(text[i]);
    return w;
  };
  f32 maxw = 0.f;
  for (std::size_t l = 0; l < lines; ++l) maxw = std::fmax(maxw, width_of(buf_.line_start(l), buf_.line_end(l)));
  const f32 max_sx = std::fmax(0.f, maxw - view_w + u(40.f));
  const f32 max_sy = std::fmax(0.f, static_cast<f32>(lines - 1) * lh);
  const auto clamp_scroll = [&] {
    scroll_y_ = std::clamp(scroll_y_, 0.f, max_sy);
    scroll_x_ = std::clamp(scroll_x_, 0.f, max_sx);
  };
  clamp_scroll();
  f32 sy = std::round(scroll_y_ / lh) * lh;  // whole lines only: a half-hidden line could not be clipped

  const auto offset_at = [&](f32 px, f32 py) -> std::size_t {
    const long l = std::clamp(static_cast<long>(std::floor((py - area.y + sy) / lh)), 0L, static_cast<long>(lines) - 1);
    const f32 target = px - text_x0 + scroll_x_;
    const std::size_t ls = buf_.line_start(static_cast<std::size_t>(l)), le = buf_.line_end(static_cast<std::size_t>(l));
    f32 acc = 0.f;
    std::size_t off = ls;
    while (off < le) {
      const f32 w = adv(text[off]);
      if (target < acc + w * 0.5f) break;
      acc += w;
      ++off;
    }
    return off;
  };

  // ---- on-screen keyboard layout ----
  Key keys[kKeyRows][kKeyCols];
  int kn[kKeyRows] = {};
  Rect krect[kKeyRows][kKeyCols];
  if (keys_open_) {
    const auto add = [&](int r, const Key& key) { keys[r][kn[r]++] = key; };
    const auto chr = [&](int r, const char* s, int i, f32 w = 1.f) { add(r, Key{std::string_view(s + i, 1), s[i], kActChar, EditEvent::Char, w}); };
    const auto evk = [&](int r, std::string_view label, EditEvent::Kind ev, f32 w) { add(r, Key{label, 0, kActEvent, ev, w}); };
    add(0, Key{"TAB", 0, kActEvent, EditEvent::Tab, 1.5f});
    for (int i = 0; i < 9; ++i) chr(0, "(){}[];:\"", i);
    if (!symbols_) {
      const char* L = shift_ ? kUp : kLow;
      for (int i = 0; i < 10; ++i) chr(1, L, i);
      for (int i = 10; i < 19; ++i) chr(2, L, i);
      add(3, Key{"SHIFT", 0, kActShift, EditEvent::Char, 1.5f});
      for (int i = 19; i < 26; ++i) chr(3, L, i);
      evk(3, "DEL", EditEvent::Backspace, 1.5f);
      add(4, Key{"123", 0, kActSym, EditEvent::Char, 1.5f});
      chr(4, ",", 0);
      add(4, Key{"SPACE", ' ', kActChar, EditEvent::Char, 5.f});
      chr(4, ".", 0);
      evk(4, "ENTER", EditEvent::Enter, 2.f);
    } else {
      for (int i = 0; i < 10; ++i) chr(1, "1234567890", i);
      for (int i = 0; i < 10; ++i) chr(2, "+-*/%=!&|^", i);
      for (int i = 0; i < 10; ++i) chr(3, "<>_#$@~?\\'", i);
      add(4, Key{"ABC", 0, kActSym, EditEvent::Char, 1.5f});
      chr(4, ",", 0);
      chr(4, "`", 0);
      add(4, Key{"SPACE", ' ', kActChar, EditEvent::Char, 3.f});
      chr(4, ".", 0);
      evk(4, "DEL", EditEvent::Backspace, 1.5f);
      evk(4, "ENTER", EditEvent::Enter, 1.5f);
    }
    const f32 unit = std::min((W - 2.f * m) / 10.5f, u(56.f));
    for (int r = 0; r < kKeyRows; ++r) {
      f32 units = 0.f;
      for (int i = 0; i < kn[r]; ++i) units += keys[r][i].w;
      f32 x = (W - units * unit) * 0.5f;
      const f32 y = osk_top + kgap * 0.5f + static_cast<f32>(r) * kh;
      for (int i = 0; i < kn[r]; ++i) {
        krect[r][i] = {x + kgap * 0.5f, y + kgap * 0.5f, keys[r][i].w * unit - kgap, kh - kgap};
        x += keys[r][i].w * unit;
      }
    }
  }

  // ---- on-screen keyboard: keys act on press (not release), backspace repeats while held ----
  bool osk_press = false;
  if (keys_open_ && f.pressed && f.y >= osk_top) {
    for (int r = 0; r < kKeyRows && !osk_press; ++r) {
      for (int i = 0; i < kn[r]; ++i) {
        if (!inside(krect[r][i], f.x, f.y)) continue;
        osk_press = true;
        const Key& key = keys[r][i];
        switch (key.act) {
          case kActChar: {
            EditEvent e;
            e.kind = EditEvent::Char;
            e.ch = key.ch;
            run_event(e, {});
            shift_ = false;
            break;
          }
          case kActEvent: {
            EditEvent e;
            e.kind = key.ev;
            run_event(e, {});
            if (key.ev == EditEvent::Backspace) {
              held_ = r * kKeyCols + i;
              hold_t_ = hold_acc_ = 0.f;
            }
            break;
          }
          case kActShift: shift_ = !shift_; break;
          default: symbols_ = !symbols_; shift_ = false; break;
        }
        break;
      }
    }
  }
  if (held_ >= 0) {
    if (!f.down || !keys_open_) {
      held_ = -1;
    } else {
      hold_t_ += f.dt;
      if (hold_t_ > 0.4f) {
        hold_acc_ += f.dt;
        while (hold_acc_ >= 0.045f) {
          hold_acc_ -= 0.045f;
          EditEvent e;
          e.kind = EditEvent::Backspace;
          run_event(e, {});
        }
      }
    }
  }

  // ---- text area: mouse = click / drag selects, finger = tap places the cursor, drag scrolls ----
  if (f.wheel != 0.f && inside(area, f.x, f.y)) {
    scroll_y_ -= f.wheel * 3.f * lh;
    follow_ = false;
  }
  if (f.pressed && !osk_press && inside(area, f.x, f.y)) {
    if (f.touch && !keys_touched_) keys_open_ = true;  // a finger and no physical keyboard: bring the keys up
    press_x_ = f.x;
    press_y_ = f.y;
    press_sx_ = scroll_x_;
    press_sy_ = scroll_y_;
    if (f.touch) {
      drag_ = Drag::Pending;
    } else {
      buf_.move_to(offset_at(f.x, f.y), sel_mode_);
      drag_ = Drag::Select;
      follow_ = false;
    }
  }
  if (drag_ != Drag::None) {
    if (drag_ == Drag::Pending && f.down && std::hypot(f.x - press_x_, f.y - press_y_) > u(8.f)) drag_ = Drag::Scroll;
    if (drag_ == Drag::Scroll && f.down) {
      scroll_y_ = press_sy_ - (f.y - press_y_);
      scroll_x_ = press_sx_ - (f.x - press_x_);
      follow_ = false;
    }
    if (drag_ == Drag::Select && f.down) {
      buf_.move_to(offset_at(f.x, f.y), true);
      follow_ = false;
    }
    if (f.released || !f.down) {
      if (drag_ == Drag::Pending) {  // a tap
        buf_.move_to(offset_at(press_x_, press_y_), sel_mode_);
        follow_ = false;
      }
      drag_ = Drag::None;
    }
  }

  // ---- keep the cursor in view after typing / moving ----
  if (follow_) {
    const std::size_t cl = buf_.line_of(buf_.cursor());
    const f32 cy = static_cast<f32>(cl) * lh;
    if (cy < scroll_y_) scroll_y_ = cy;
    else if (cy + lh > scroll_y_ + vis_h) scroll_y_ = cy + lh - vis_h;
    const f32 cx = width_of(buf_.line_start(cl), buf_.cursor());
    if (cx < scroll_x_) scroll_x_ = std::fmax(0.f, cx - u(24.f));
    else if (cx > scroll_x_ + view_w - u(12.f)) scroll_x_ = cx - view_w + u(40.f);
    follow_ = false;
  }
  clamp_scroll();
  sy = std::round(scroll_y_ / lh) * lh;

  // ---- draw: backgrounds ----
  gui.fill({0.f, 0.f, W, H}, kBg);
  gui.fill(area, kAreaBg);
  gui.fill({area.x, area.y, gw, area.h}, kGutterBg);
  gui.fill({area.x + gw, area.y, std::fmax(1.f, std::round(u(1.f))), area.h}, kEdge);

  // ---- draw: lines (current-line tint, selection, caret, numbers, colored code) ----
  const std::size_t first = static_cast<std::size_t>(sy / lh + 0.5f);
  const std::size_t cur_line = buf_.line_of(buf_.cursor());
  const std::size_t sb = buf_.sel_begin(), se = buf_.sel_end();
  const bool has_sel = buf_.has_selection();
  bool block = false;
  for (std::size_t l = 0; l < first && l < lines; ++l) highlight_line(buf_.line(l), block, nullptr);
  const f32 space = adv(' ');
  const f32 caret_w = std::fmax(2.f, std::round(u(1.5f)));
  char num[16];
  for (std::size_t l = first; l < lines; ++l) {
    const f32 top = area.y + static_cast<f32>(l - first) * lh;
    if (top + lh > area.y + area.h + 0.5f) break;
    const std::size_t ls = buf_.line_start(l), le = buf_.line_end(l);
    if (l == cur_line && !has_sel) gui.fill({area.x + gw, top, area.w - gw, lh}, kLineHi);
    if (has_sel && se > ls && sb <= le) {
      const std::size_t a0 = std::max(sb, ls), a1 = std::min(se, le);
      f32 x0 = text_x0 - scroll_x_ + width_of(ls, a0);
      f32 x1 = text_x0 - scroll_x_ + width_of(ls, a1) + (se > le ? space : 0.f);
      x0 = std::max(x0, clip_x0);
      x1 = std::min(x1, clip_x1);
      if (x1 > x0) gui.fill({x0, top, x1 - x0, lh}, kSelFill);
    }
    if (l == cur_line) {
      const f32 cx = text_x0 - scroll_x_ + width_of(ls, buf_.cursor());
      if (cx >= clip_x0 - 1.f && cx <= clip_x1) gui.fill({cx, top + lh * 0.12f, caret_w, lh * 0.76f}, kCaret);
    }
    std::snprintf(num, sizeof num, "%zu", l + 1);
    gui.text(a.button, num, area.x + gw - u(8.f), top + base_off, ui::Align::Right, 0.f, l == cur_line ? kGutterHi : kGutterNum);

    const std::string_view line = buf_.line(l);
    if (toks_.size() < line.size()) toks_.resize(line.size());
    highlight_line(line, block, toks_.data());
    f32 x = text_x0 - scroll_x_, run_x = 0.f;
    std::size_t run_start = 0;
    Tok run_tok = Tok::Plain;
    bool in_run = false;
    const auto flush_run = [&](std::size_t end) {
      if (in_run && end > run_start)
        gui.text(a.button, line.substr(run_start, end - run_start), run_x, top + base_off, ui::Align::Left, 0.f, tok_color(run_tok));
      in_run = false;
    };
    for (std::size_t i = 0; i < line.size(); ++i) {  // only whole characters inside the text area are drawn
      const f32 w = adv(line[i]);
      if (!(x >= clip_x0 && x + w <= clip_x1)) flush_run(i);
      else if (!in_run || toks_[i] != run_tok) {
        flush_run(i);
        in_run = true;
        run_start = i;
        run_x = x;
        run_tok = toks_[i];
      }
      x += w;
    }
    flush_run(line.size());
  }

  // ---- draw: top bar ----
  const f32 bh = u(32.f), by = (bar_h - bh) * 0.5f;
  const Rect r_apply{W - m - u(68.f), by, u(68.f), bh};
  const Rect r_cancel{r_apply.x - kgap * 2.f - u(76.f), by, u(76.f), bh};
  if (gui.mini_button(kApply, r_apply, "APPLY")) result = CodeResult::Apply;
  if (gui.mini_button(kCancel, r_cancel, "CANCEL")) result = CodeResult::Cancel;
  char title[96];
  std::snprintf(title, sizeof title, "CODE  /  %s%s", title_.c_str(), dirty() ? "  *" : "");
  gui.text(a.label, title, m + u(4.f), by + bh * 0.5f + a.label.font.pixel_height * 0.36f * k, ui::Align::Left, 1.6f, kDim);
  gui.rule(0.f, bar_h, W, kEdge);

  // ---- draw: edit toolbar ----
  for (int i = 0; i < kToolbarN; ++i) {
    const TbItem& it = kToolbar[i];
    bool enabled = true;
    if (it.special == 0) {
      if (it.ev == EditEvent::Undo) enabled = buf_.can_undo();
      else if (it.ev == EditEvent::Redo) enabled = buf_.can_redo();
      else if (it.ev == EditEvent::Copy || it.ev == EditEvent::Cut) enabled = buf_.has_selection();
    }
    const Rect& r = tb_rect[i];
    if (gui.mini_button(kToolBase + static_cast<u32>(i), r, it.label, enabled)) {
      if (it.special == 1) {
        sel_mode_ = !sel_mode_;
      } else if (it.special == 2) {
        keys_open_ = !keys_open_;
        keys_touched_ = true;
      } else {
        EditEvent e;
        e.kind = it.ev;
        e.shift = sel_mode_ && (it.ev == EditEvent::Left || it.ev == EditEvent::Right || it.ev == EditEvent::Up || it.ev == EditEvent::Down);
        run_event(e, it.ev == EditEvent::Paste ? std::string_view(platform::clipboard_get()) : std::string_view{});
      }
    }
    if ((it.special == 1 && sel_mode_) || (it.special == 2 && keys_open_))
      gui.fill({r.x + r.w * 0.2f, r.y + r.h - u(4.f), r.w * 0.6f, u(2.5f)}, kAccent);
  }

  // ---- draw: on-screen keyboard ----
  if (keys_open_) {
    gui.rule(0.f, osk_top, W, kEdge);
    for (int r = 0; r < kKeyRows; ++r) {
      for (int i = 0; i < kn[r]; ++i) {
        const Key& key = keys[r][i];
        gui.mini_button(kKeyBase + static_cast<u32>(r * kKeyCols + i), krect[r][i], key.label);  // look + press feedback only
        if (key.act == kActShift && shift_)
          gui.fill({krect[r][i].x + krect[r][i].w * 0.2f, krect[r][i].y + krect[r][i].h - u(4.f), krect[r][i].w * 0.6f, u(2.5f)}, kAccent);
      }
    }
  }
  return result;
}

}  // namespace nv
