#pragma once
// One drawn thing. Immutable once committed (shared between undo snapshots).
#include <string>
#include <vector>

#include "core/types.hpp"

namespace nv {

struct Shape2D {
  enum Kind : u8 { Stroke, Line, Box, Oval } kind = Stroke;
  Color color{};
  f32 width = 4.f;        // brush width in world units (Stroke, Line)
  Vec2 a{}, b{};          // Line: endpoints. Box/Oval: opposite corners of the UNROTATED rect (a = min, b = max)
  f32 rot = 0.f;          // Box/Oval: radians about the rect's center, clockwise on screen (strokes bake rotation into pts)
  std::vector<Vec2> pts;  // Stroke
  Rect bounds{};          // world-space bounding box, includes brush width and rotation
  std::string script;     // code attached to this object (code editor); empty = none. ASCII, see TextBuffer
};

}  // namespace nv
