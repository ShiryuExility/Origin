#include "sandbox/settings.hpp"

#include <SDL3/SDL.h>

#include "sandbox/platform.hpp"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <string>

namespace nv {
namespace {
std::string settings_path() {
  const std::string dir = platform::pref_dir();
  return dir.empty() ? std::string{} : dir + "settings.ini";
}
}  // namespace

Settings load_settings() {
  Settings s;
  const std::string path = settings_path();
  if (path.empty()) return s;
  size_t size = 0;
  void* data = SDL_LoadFile(path.c_str(), &size);
  if (!data) return s;  // first run
  const std::string text(static_cast<const char*>(data), size);
  SDL_free(data);

  std::size_t pos = 0;
  while (pos < text.size()) {
    std::size_t end = text.find('\n', pos);
    if (end == std::string::npos) end = text.size();
    const std::string line = text.substr(pos, end - pos);
    pos = end + 1;
    const auto eq = line.find('=');
    if (eq == std::string::npos) continue;
    const std::string key = line.substr(0, eq), val = line.substr(eq + 1);
    const double num = std::atof(val.c_str());
    if (key == "ui_scale") s.ui_scale = static_cast<f32>(num);  // unknown keys (old particles=...) are ignored
    else if (key == "show_hud") s.show_hud = num != 0;
  }
  // A hand-edited file must never break the app.
  s.ui_scale = std::clamp(s.ui_scale, 0.8f, 1.25f);
  return s;
}

void save_settings(const Settings& s) {
  const std::string path = settings_path();
  if (path.empty()) return;
  char buf[256];
  std::snprintf(buf, sizeof buf, "ui_scale=%.2f\nshow_hud=%d\n", static_cast<double>(s.ui_scale), s.show_hud);
  if (SDL_SaveFile(path.c_str(), buf, std::char_traits<char>::length(buf))) platform::flush_storage();
}

}  // namespace nv
