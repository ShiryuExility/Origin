#pragma once
// User settings for the sandbox, saved as key=value text in the per-user pref folder.
#include "core/types.hpp"

namespace nv {

struct Settings {
  f32 ui_scale = 1.0f;  // 0.8 .. 1.25
  bool show_hud = true; // FPS / draw calls / sprites overlay
};

Settings load_settings();
void save_settings(const Settings& s);

}  // namespace nv
