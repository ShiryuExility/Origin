#pragma once
// Lobby + settings screens. Static (no per-frame animation besides widget easing), so the app can
// sleep between inputs. Backdrop = flat clear color + one soft light + a tiled grain texture.
#include "render/sprite_batch.hpp"
#include "sandbox/settings.hpp"
#include "sandbox/ui.hpp"

namespace nv::menu {

enum Id : u32 { kBtnCreate = 1, kBtnSettings, kBtnQuit, kBtnBack, kSetHud = 20, kSetScale };

enum class Action { None, Create, Settings, Quit, Back };

struct Stats {
  u32 fps = 0, draw_calls = 0, sprites = 0;
};

// Screen-space backdrop (1 unit = 1 physical pixel): soft light + grain. Costs ~50-150 sprites, all in the atlas run.
void draw_backdrop(SpriteBatch& batch, const ui::Assets& a, f32 width, f32 height, f32 density);

Action lobby(ui::Ui& gui, const ui::Assets& a, bool show_hud, const Stats& stats);
// `dirty` is set when a value changed (the caller saves when leaving the screen).
Action settings_screen(ui::Ui& gui, const ui::Assets& a, bool back, Settings& st, bool& dirty, const Stats& stats);

}  // namespace nv::menu
