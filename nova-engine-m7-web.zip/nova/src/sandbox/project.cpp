#include "sandbox/project.hpp"

#include <cmath>
#include <cstring>

#include "sandbox/text_buffer.hpp"
#include "sandbox/transform.hpp"

namespace nv {
namespace {

constexpr char kMagic[4] = {'N', 'V', 'P', 'R'};
constexpr u32 kMaxObjects = 4'000'000;
constexpr u32 kMaxPoints = 4'000'000;
constexpr f32 kMaxCoord = 1.0e7f;
constexpr std::size_t kHeaderBytes = 4 + 4 + 4 + 12;
constexpr std::size_t kObjectBytesV1 = 1 + 4 + 4 + 16 + 4 + 4;  // fixed part, before the points
constexpr std::size_t kObjectBytes = kObjectBytesV1 + 4;         // version 2: + script length

u32 fnv1a(const u8* p, std::size_t n) {
  u32 h = 2166136261u;
  for (std::size_t i = 0; i < n; ++i) { h ^= p[i]; h *= 16777619u; }
  return h;
}

struct Writer {
  std::vector<u8>& out;
  template <class T> void put(T v) {
    const std::size_t at = out.size();
    out.resize(at + sizeof(T));
    std::memcpy(out.data() + at, &v, sizeof(T));
  }
};

struct Reader {
  std::span<const u8> in;
  std::size_t pos = 0;
  [[nodiscard]] std::size_t left() const { return in.size() - pos; }
  template <class T> T get() {
    T v;
    std::memcpy(&v, in.data() + pos, sizeof(T));
    pos += sizeof(T);
    return v;
  }
};

bool sane(f32 v) { return std::isfinite(v) && std::fabs(v) <= kMaxCoord; }

}  // namespace

std::vector<u8> serialize_project(const Doc& shapes, Vec2 cam, f32 zoom) {
  std::size_t reserve = kHeaderBytes + 4;
  for (const Obj& o : shapes) reserve += kObjectBytes + o->pts.size() * 8 + o->script.size();
  std::vector<u8> out;
  out.reserve(reserve);
  Writer w{out};
  for (char c : kMagic) w.put<u8>(static_cast<u8>(c));
  w.put<u32>(kProjectVersion);
  w.put<u32>(static_cast<u32>(shapes.size()));
  w.put<f32>(cam.x); w.put<f32>(cam.y); w.put<f32>(zoom);
  for (const Obj& o : shapes) {
    const Shape2D& s = *o;
    w.put<u8>(static_cast<u8>(s.kind));
    w.put<u8>(s.color.r); w.put<u8>(s.color.g); w.put<u8>(s.color.b); w.put<u8>(s.color.a);
    w.put<f32>(s.width);
    w.put<f32>(s.a.x); w.put<f32>(s.a.y); w.put<f32>(s.b.x); w.put<f32>(s.b.y);
    w.put<f32>(s.rot);
    w.put<u32>(static_cast<u32>(s.pts.size()));
    for (const Vec2& p : s.pts) { w.put<f32>(p.x); w.put<f32>(p.y); }
    w.put<u32>(static_cast<u32>(s.script.size()));
    for (const char c : s.script) w.put<u8>(static_cast<u8>(c));
  }
  w.put<u32>(fnv1a(out.data(), out.size()));
  return out;
}

std::optional<Project> parse_project(std::span<const u8> bytes) {
  if (bytes.size() < kHeaderBytes + 4) return std::nullopt;
  if (std::memcmp(bytes.data(), kMagic, 4) != 0) return std::nullopt;
  u32 stored = 0;
  std::memcpy(&stored, bytes.data() + bytes.size() - 4, 4);
  if (fnv1a(bytes.data(), bytes.size() - 4) != stored) return std::nullopt;  // truncated or damaged

  Reader r{bytes.first(bytes.size() - 4)};
  r.pos = 4;
  const u32 version = r.get<u32>();
  if (version != 1 && version != kProjectVersion) return std::nullopt;
  const std::size_t object_min = version == 1 ? kObjectBytesV1 : kObjectBytes;
  const u32 count = r.get<u32>();
  Project p;
  p.cam.x = r.get<f32>(); p.cam.y = r.get<f32>(); p.zoom = r.get<f32>();
  if (!sane(p.cam.x) || !sane(p.cam.y) || !std::isfinite(p.zoom) || p.zoom < 0.05f || p.zoom > 32.f) return std::nullopt;
  if (count > kMaxObjects || r.left() / object_min < count) return std::nullopt;  // checked before allocating

  p.shapes.reserve(count);
  for (u32 i = 0; i < count; ++i) {
    if (r.left() < object_min) return std::nullopt;
    Shape2D s;
    const u8 kind = r.get<u8>();
    if (kind > Shape2D::Oval) return std::nullopt;
    s.kind = static_cast<Shape2D::Kind>(kind);
    s.color.r = r.get<u8>(); s.color.g = r.get<u8>(); s.color.b = r.get<u8>(); s.color.a = r.get<u8>();
    s.width = r.get<f32>();
    s.a.x = r.get<f32>(); s.a.y = r.get<f32>(); s.b.x = r.get<f32>(); s.b.y = r.get<f32>();
    s.rot = r.get<f32>();
    const u32 n = r.get<u32>();
    if (!sane(s.width) || s.width <= 0.f || s.width > 10000.f) return std::nullopt;
    if (!sane(s.a.x) || !sane(s.a.y) || !sane(s.b.x) || !sane(s.b.y) || !std::isfinite(s.rot)) return std::nullopt;
    if (n > kMaxPoints || r.left() / 8 < n) return std::nullopt;
    if ((s.kind == Shape2D::Stroke) != (n > 0)) return std::nullopt;  // strokes need points, other kinds have none
    s.pts.resize(n);
    for (Vec2& q : s.pts) {
      q.x = r.get<f32>(); q.y = r.get<f32>();
      if (!sane(q.x) || !sane(q.y)) return std::nullopt;
    }
    if (version >= 2) {
      if (r.left() < 4) return std::nullopt;
      const u32 len = r.get<u32>();
      if (len > TextBuffer::kMaxBytes || r.left() < len) return std::nullopt;
      s.script.resize(len);
      for (u32 j = 0; j < len; ++j) {
        const char c = static_cast<char>(r.get<u8>());
        if (!TextBuffer::allowed(c)) return std::nullopt;  // only what the editor can produce
        s.script[j] = c;
      }
    }
    compute_bounds(s);  // derived data is rebuilt, never stored
    p.shapes.push_back(std::make_shared<const Shape2D>(std::move(s)));
  }
  if (r.left() != 0) return std::nullopt;
  return p;
}

}  // namespace nv
