#pragma once
// Blank-canvas editor: a pannable, zoomable infinite canvas that fills the whole window, with a
// slim tool rail, a color/size dock and a zoom pill floating on top. The canvas is the product;
// the chrome stays small and out of the way (about 8% of a 16:9 window).
#include <functional>
#include <memory>
#include <span>
#include <string_view>
#include <utility>
#include <vector>

#include "render/renderer.hpp"
#include "render/sprite_batch.hpp"
#include "sandbox/code_editor.hpp"
#include "sandbox/history.hpp"
#include "sandbox/project.hpp"
#include "sandbox/shape.hpp"
#include "sandbox/transform.hpp"
#include "sandbox/ui.hpp"

namespace nv {

// Order = rail order, two lines of five: pick / transform / view, then draw. Select only picks; moving, resizing
// and turning an object each have their own tool, so a slip with one of them can never change another thing.
enum class Tool : u8 { Select, Move, Scale, Rotate, Hand, Pen, Line, Rect, Ellipse, Eraser, kCount };

struct Pointer {
  // Every position the pointer reported this frame while the button was held (physical pixels, oldest first).
  // Touch panels report faster than the frame rate: keeping them all makes fast strokes smooth, not angular.
  static constexpr int kTrailMax = 32;
  Vec2 trail[kTrailMax];
  u8 trail_n = 0;
  f32 x = 0.f, y = 0.f;   // physical pixels
  bool pressed = false;   // primary button went down this frame
  bool down = false;      // primary button held
  bool released = false;  // primary button went up this frame
  bool pan_down = false;  // middle / right button held: pans with any tool
  f32 wheel = 0.f;        // wheel notches this frame (+ = zoom in)
};

class Editor {
 public:
  using Flush = std::function<void()>;

  explicit Editor(f32 density) : density_(density) {}

  void reset();  // new blank project, default view

  // ---- commands (keyboard, chrome) ----
  void set_tool(Tool t);
  void undo();
  void redo();
  void delete_selection();
  void duplicate_selection();  // copy of the selection, offset a little, on top, and selected
  void bring_to_front();       // selection to the top of the draw order
  void send_to_back();
  void zoom_to_fit();          // frames the whole drawing (needs one update() so the window size is known)
  // Code editor: the script of the selected object. open_code() needs a selection; close_code(true) stores the
  // text in the object (one undo step), close_code(false) throws the changes away. While it is open the canvas
  // is locked and main.cpp drives the screen with code_ui() instead of update() / chrome().
  void open_code();
  void close_code(bool apply);
  [[nodiscard]] bool code_open() const noexcept { return code_.is_open(); }
  [[nodiscard]] CodeEditor& code() noexcept { return code_; }
  bool code_ui(ui::Ui& gui, const CodeFrame& f);  // true while the code screen stays open
  // Project file (see project.hpp). load_project() returns false and changes nothing on a bad file or mid-gesture.
  [[nodiscard]] std::vector<u8> save_project() const { return serialize_project(doc_, cam_, zoom_); }
  bool load_project(std::span<const u8> bytes);
  void zoom_by(f32 factor, f32 sx, f32 sy, f32 W, f32 H);  // zoom about a screen point
  // Two-finger gesture: the point under the fingers' midpoint follows them (pan by dx,dy px) while the view
  // zooms by `factor` about the new midpoint (cx,cy). cancel_gesture() drops what a single finger had started.
  void pinch(f32 cx, f32 cy, f32 factor, f32 dx, f32 dy, f32 W, f32 H);
  void cancel_gesture();
  void reset_view() { cam_ = {0.f, 0.f}; zoom_ = 1.f; }
  // The action menu asks the app for file work (Editor itself never touches the disk): main.cpp calls take_request()
  // after chrome(), does the save / open, and shows the outcome with set_status() (a string literal; it replaces the
  // tool name in the status line until the next tool change or canvas touch).
  enum class Request : u8 { None, Save, Open };
  [[nodiscard]] Request take_request() noexcept { return std::exchange(request_, Request::None); }
  void set_status(const char* literal) noexcept { status_ = literal; }
  void toggle_grid() { grid_ = !grid_; }
  void pan_pixels(f32 dx, f32 dy) { cam_.x += dx / scale(); cam_.y += dy / scale(); }

  // ---- per frame ----
  // Chrome rectangles (physical pixels) for this window size. Needs Ui::begin() to have run.
  // Landscape: rail down the left edge, dock bottom-center, zoom bottom-right. Portrait: the same pieces
  // stack at the bottom (dock, then the rail turned horizontal, then the zoom pill) so thumbs reach them.
  struct Layout { Rect rail, dock, zoom, undo, redo, lobby, picker, more, menu; bool portrait = false, picker_open = false, menu_open = false; };
  [[nodiscard]] Layout layout(const ui::Ui& gui, f32 W, f32 H) const;
  [[nodiscard]] static bool over_chrome(const Layout& l, f32 x, f32 y);

  void update(const Pointer& p, f32 W, f32 H, bool over_chrome);
  // Grid + drawing + selection, in world space. `flush` submits the batch when it fills up mid-frame.
  void draw_canvas(SpriteBatch& b, const ui::Assets& a, f32 W, f32 H, const Flush& flush) const;
  [[nodiscard]] Camera2D camera() const noexcept { return {cam_, scale()}; }
  // Draws the floating chrome. Returns true when the user asked to leave for the lobby.
  bool chrome(ui::Ui& gui, const Layout& l, std::string_view hud);

  [[nodiscard]] bool busy() const noexcept { return gesture_ != Gesture::None || code_.busy(); }  // a drag / held key is in progress
  [[nodiscard]] u32 object_count() const noexcept { return static_cast<u32>(doc_.size()); }
  [[nodiscard]] Tool tool() const noexcept { return tool_; }

 private:
  enum class Gesture : u8 { None, Draw, Pan, Move, Erase, Scale, Rotate };

  [[nodiscard]] f32 scale() const noexcept { return zoom_ * density_; }  // physical px per world unit
  [[nodiscard]] Vec2 to_world(f32 sx, f32 sy, f32 W, f32 H) const noexcept {
    return {cam_.x + (sx - W * 0.5f) / scale(), cam_.y + (sy - H * 0.5f) / scale()};
  }
  [[nodiscard]] std::size_t index_of(const Obj& o) const;  // slot in doc_, or doc_.size() when absent
  [[nodiscard]] bool hit(const Shape2D& s, Vec2 p, f32 tol) const;
  [[nodiscard]] int pick(Vec2 p, f32 tol) const;  // topmost object index or -1
  void finish_draft();
  struct Quv { QuantUv disc, bar; };   // atlas uvs converted once per frame, not once per shape
  // `cull`: when set, stroke segments entirely outside this world rect are skipped (partly visible long strokes).
  void draw_shape(SpriteBatch& b, const ui::Assets& a, const Quv& q, const Shape2D& s, Vec2 offset, f32 px_world,
                  const Rect* cull = nullptr) const;
  void draw_icon(ui::Ui& gui, Tool t, Vec2 c, f32 s, Color col) const;
  // Select tool: transform handles around the selection
  [[nodiscard]] f32 min_half() const noexcept { return 14.f * density_ / scale(); }  // smallest half extent of a frame
  [[nodiscard]] f32 sel_pad(const Shape2D& s) const noexcept;  // frame -> drawn box margin (world units)
  [[nodiscard]] bool handle_enabled(const Frame& f, Handle h, f32 pad) const noexcept;
  [[nodiscard]] Handle handle_at(Vec2 world) const;
  [[nodiscard]] bool in_selection_box(Vec2 world, f32 tol) const;
  void close_picker();  // closes the custom color panel; a color that was changed goes to the recent list
  bool selectable_action() const noexcept { return selected_ && !locked(); }
  [[nodiscard]] bool locked() const noexcept { return busy() || code_.is_open(); }  // edits to the document are refused

  f32 density_;
  Vec2 cam_{};          // world point at the window center
  f32 zoom_ = 1.f;      // 1 = 100%
  bool grid_ = true;
  Tool tool_ = Tool::Pen;
  Color color_{226, 230, 238, 255};
  int size_idx_ = 1;
  // custom color: HSV sliders in a panel above the dock; the last few colors stay as quick swatches
  bool menu_ = false;  // action menu open (it exists only while open, like the color panel)
  Request request_ = Request::None;
  const char* status_ = nullptr;
  bool picker_ = false, custom_dirty_ = false;
  f32 hsv_[3] = {0.58f, 0.55f, 1.f};
  Color custom_{115, 188, 255, 255};  // = hsv_ as RGB
  Color recent_[5]{};
  int recent_n_ = 0;

  Doc doc_;
  History hist_;
  Obj selected_;

  Gesture gesture_ = Gesture::None;
  Shape2D draft_;        // shape being drawn
  Vec2 anchor_{}, last_world_{}, drag_delta_{};
  Vec2 prev_screen_{};
  // scale / rotate gesture: the selection frame frozen at the press, and the shape as it would end up
  Frame gframe_{};
  Handle ghandle_ = Handle::None;
  Vec2 gstart_{};            // pointer at the press, in frame-local space
  f32 gstart_angle_ = 0.f;   // pointer angle around the frame center at the press
  Xf gxf_{};
  Shape2D preview_;
  bool erase_pushed_ = false;
  bool rot_arm_ = false;    // Rotate tool: the press landed on the pivot, the angle starts once the pointer leaves it
  bool rot_empty_ = false;  // Rotate tool: the press hit no object (a tap there deselects)
  CodeEditor code_;
  // pointer, for the brush cursor
  Vec2 ptr_world_{};
  bool ptr_on_canvas_ = false;
  f32 W_ = 0.f, H_ = 0.f;
};

}  // namespace nv
