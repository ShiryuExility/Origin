#pragma once
// Keyboard / on-screen-keyboard events for the code editor, and how they act on a TextBuffer (SDL-free, tested).
#include <string>
#include <string_view>

#include "core/types.hpp"
#include "sandbox/text_buffer.hpp"

namespace nv {

struct EditEvent {
  enum Kind : u8 { Char, Backspace, Delete, Enter, Tab, Left, Right, Up, Down, Home, End, PageUp, PageDown,
                   SelectAll, Copy, Cut, Paste, Undo, Redo };
  Kind kind = Char;
  char ch = 0;         // Char: printable ASCII
  bool shift = false;  // movement: extend the selection. Tab: outdent
  bool ctrl = false;   // Left / Right / Backspace / Delete: by word. Home / End: start / end of the text
};

// Everything typed during one frame (physical keyboard, OS text input). A fixed array: no allocation per frame.
struct EditQueue {
  static constexpr int kMax = 96;
  EditEvent ev[kMax];
  int n = 0;
  std::string paste;  // system clipboard text for a Paste event (empty: use the editor's own clipboard)
  void clear() { n = 0; paste.clear(); }
  bool push(const EditEvent& e) {
    if (n >= kMax) return false;
    ev[n++] = e;
    return true;
  }
};

inline constexpr int kPageLines = 12;

// Applies one event. Copy / Cut put the selection into `clip` and return true (the caller mirrors it to the
// system clipboard). Paste inserts `system_paste` when it is not empty, else `clip`.
inline bool apply_edit(TextBuffer& b, const EditEvent& e, std::string& clip, std::string_view system_paste) {
  switch (e.kind) {
    case EditEvent::Char: b.type(e.ch); break;
    case EditEvent::Backspace: b.backspace(e.ctrl); break;
    case EditEvent::Delete: b.del(e.ctrl); break;
    case EditEvent::Enter: b.newline(); break;
    case EditEvent::Tab:
      if (e.shift) b.outdent();
      else b.tab();
      break;
    case EditEvent::Left: b.left(e.shift, e.ctrl); break;
    case EditEvent::Right: b.right(e.shift, e.ctrl); break;
    case EditEvent::Up: b.up(e.shift); break;
    case EditEvent::Down: b.down(e.shift); break;
    case EditEvent::Home: b.home(e.shift, e.ctrl); break;
    case EditEvent::End: b.end(e.shift, e.ctrl); break;
    case EditEvent::PageUp: b.page(-kPageLines, e.shift); break;
    case EditEvent::PageDown: b.page(kPageLines, e.shift); break;
    case EditEvent::SelectAll: b.select_all(); break;
    case EditEvent::Copy:
      if (b.has_selection()) { clip = b.selected(); return true; }
      break;
    case EditEvent::Cut:
      if (b.has_selection()) {
        clip = b.selected();
        b.delete_selection();
        return true;
      }
      break;
    case EditEvent::Paste: {
      const std::string_view t = system_paste.empty() ? std::string_view(clip) : system_paste;
      if (!t.empty()) b.insert(t);
      break;
    }
    case EditEvent::Undo: b.undo(); break;
    case EditEvent::Redo: b.redo(); break;
  }
  return false;
}

}  // namespace nv
