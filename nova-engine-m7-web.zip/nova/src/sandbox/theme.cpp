#include "sandbox/theme.hpp"

#include <algorithm>
#include <cmath>

namespace nv::theme {
namespace {

Image make(u32 w, u32 h) {
  Image im;
  im.w = w;
  im.h = h;
  im.rgba.assign(std::size_t{w} * h * 4, 255);
  return im;
}
void set_alpha(Image& im, u32 x, u32 y, f32 a) {
  im.rgba[(std::size_t{y} * im.w + x) * 4 + 3] = static_cast<u8>(std::clamp(a, 0.f, 1.f) * 255.f + 0.5f);
}
f32 smooth(f32 e0, f32 e1, f32 x) {
  const f32 t = std::clamp((x - e0) / (e1 - e0), 0.f, 1.f);
  return t * t * (3.f - 2.f * t);
}
// Pixel center -> [-1, 1]
f32 norm(u32 i, u32 n) { return (static_cast<f32>(i) + 0.5f) / static_cast<f32>(n) * 2.f - 1.f; }

}  // namespace

Image soft_disc(u32 n) {
  Image im = make(n, n);
  for (u32 y = 0; y < n; ++y)
    for (u32 x = 0; x < n; ++x) {
      const f32 r = std::hypot(norm(x, n), norm(y, n));
      set_alpha(im, x, y, 1.f - smooth(0.62f, 1.f, r));
    }
  return im;
}

Image ring(u32 n) {
  Image im = make(n, n);
  for (u32 y = 0; y < n; ++y)
    for (u32 x = 0; x < n; ++x) {
      const f32 r = std::hypot(norm(x, n), norm(y, n));
      const f32 band = 1.f - std::fabs(r - 0.78f) / 0.14f;
      set_alpha(im, x, y, smooth(0.f, 1.f, band));
    }
  return im;
}

Image glow(u32 n) {
  Image im = make(n, n);
  for (u32 y = 0; y < n; ++y)
    for (u32 x = 0; x < n; ++x) {
      const f32 r = std::hypot(norm(x, n), norm(y, n));
      set_alpha(im, x, y, r >= 1.f ? 0.f : std::exp(-4.2f * r * r) * (1.f - smooth(0.7f, 1.f, r)));
    }
  return im;
}

Image triangle(u32 n) {
  Image im = make(n, n);
  const f32 px = 2.f / static_cast<f32>(n);  // one texel in [-1, 1] units
  for (u32 y = 0; y < n; ++y)
    for (u32 x = 0; x < n; ++x) {
      // apex at the top-center, base along the bottom; inside when |x| <= (y + 1) / 2 * 0.9
      const f32 fx = std::fabs(norm(x, n)), fy = norm(y, n);
      const f32 half_w = (fy + 1.f) * 0.5f * 0.9f;
      const f32 d = std::max(fx - half_w, std::max(-0.9f - fy, fy - 0.9f));  // > 0 outside
      set_alpha(im, x, y, std::clamp(0.5f - d / px * 0.7f, 0.f, 1.f));
    }
  return im;
}

Image crisp_disc(u32 n) {
  Image im = make(n, n);
  const f32 texel = 2.f / static_cast<f32>(n);
  for (u32 y = 0; y < n; ++y)
    for (u32 x = 0; x < n; ++x) {
      const f32 r = std::hypot(norm(x, n), norm(y, n));
      set_alpha(im, x, y, std::clamp((0.992f - r) / (texel * 1.5f) + 0.5f, 0.f, 1.f));
    }
  return im;
}

Image bar(u32 w, u32 h) {
  Image im = make(w, h);
  const f32 texel = 2.f / static_cast<f32>(h);
  for (u32 y = 0; y < h; ++y)
    for (u32 x = 0; x < w; ++x)
      set_alpha(im, x, y, std::clamp((0.985f - std::fabs(norm(y, h))) / (texel * 1.5f) + 0.5f, 0.f, 1.f));
  return im;
}

Image grain(u32 n, u32 seed) {
  Image im = make(n, n);
  u32 s = seed ? seed : 0x9E3779B9u;  // xorshift32: deterministic, so the texture is identical on every run
  for (u32 y = 0; y < n; ++y)
    for (u32 x = 0; x < n; ++x) {
      s ^= s << 13; s ^= s >> 17; s ^= s << 5;
      const f32 t = static_cast<f32>(s >> 8) * (1.0f / 16777216.0f);
      set_alpha(im, x, y, t * t);  // squared: mostly faint, a few brighter specks (reads as paper / film grain)
    }
  return im;
}

Image round_rect(u32 w, u32 h, f32 radius, f32 border) {
  Image im = make(w, h);
  const f32 hw = static_cast<f32>(w) * 0.5f, hh = static_cast<f32>(h) * 0.5f;
  for (u32 y = 0; y < h; ++y)
    for (u32 x = 0; x < w; ++x) {
      // Signed distance to a rounded box (negative inside), 1px antialiasing.
      const f32 qx = std::fabs(static_cast<f32>(x) + 0.5f - hw) - (hw - radius);
      const f32 qy = std::fabs(static_cast<f32>(y) + 0.5f - hh) - (hh - radius);
      const f32 d = std::hypot(std::max(qx, 0.f), std::max(qy, 0.f)) + std::min(std::max(qx, qy), 0.f) - radius;
      f32 a = std::clamp(0.5f - d, 0.f, 1.f);  // filled coverage
      if (border > 0.f) a = std::min(a, std::clamp(border + d + 0.5f, 0.f, 1.f));  // keep only the rim
      set_alpha(im, x, y, a);
    }
  return im;
}

}  // namespace nv::theme
