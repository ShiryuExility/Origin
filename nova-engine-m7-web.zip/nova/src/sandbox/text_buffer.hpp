#pragma once
// Plain-text editing buffer behind the code editor. Pure logic (no SDL, no drawing), unit-tested.
// ASCII only, because the baked fonts are printable ASCII: bytes 32..126 and '\n'. '\t' becomes two spaces,
// everything else (CR, UTF-8, control codes) is dropped on the way in.
#include <algorithm>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "core/types.hpp"

namespace nv {

class TextBuffer {
 public:
  static constexpr std::size_t kMaxBytes = 32768;
  static constexpr std::size_t kMaxUndo = 100;

  TextBuffer() { rebuild(); }

  [[nodiscard]] static bool allowed(char c) noexcept { return c == '\n' || (c >= 32 && c <= 126); }
  [[nodiscard]] static std::string sanitize(std::string_view s) {
    std::string o;
    o.reserve(s.size());
    for (const char c : s) {
      if (c == '\t') o += "  ";
      else if (allowed(c)) o += c;
    }
    return o;
  }

  // Replaces everything; the cursor goes to the end and the undo history is dropped.
  void set(std::string_view s) {
    text_ = sanitize(s);
    if (text_.size() > kMaxBytes) text_.resize(kMaxBytes);
    cur_ = anchor_ = text_.size();
    undo_.clear();
    redo_.clear();
    last_ = Kind::None;
    changed();
  }

  // ---- queries ----
  [[nodiscard]] const std::string& str() const noexcept { return text_; }
  [[nodiscard]] std::size_t size() const noexcept { return text_.size(); }
  [[nodiscard]] std::size_t cursor() const noexcept { return cur_; }
  [[nodiscard]] bool has_selection() const noexcept { return anchor_ != cur_; }
  [[nodiscard]] std::size_t sel_begin() const noexcept { return std::min(anchor_, cur_); }
  [[nodiscard]] std::size_t sel_end() const noexcept { return std::max(anchor_, cur_); }
  [[nodiscard]] std::string selected() const { return text_.substr(sel_begin(), sel_end() - sel_begin()); }
  [[nodiscard]] u32 version() const noexcept { return version_; }  // bumps on every text change
  [[nodiscard]] bool can_undo() const noexcept { return !undo_.empty(); }
  [[nodiscard]] bool can_redo() const noexcept { return !redo_.empty(); }

  [[nodiscard]] std::size_t line_count() const noexcept { return starts_.size(); }
  [[nodiscard]] std::size_t line_start(std::size_t l) const noexcept { return starts_[std::min(l, starts_.size() - 1)]; }
  // One past the last character of the line ('\n' not included).
  [[nodiscard]] std::size_t line_end(std::size_t l) const noexcept {
    l = std::min(l, starts_.size() - 1);
    return l + 1 < starts_.size() ? starts_[l + 1] - 1 : text_.size();
  }
  [[nodiscard]] std::size_t line_len(std::size_t l) const noexcept { return line_end(l) - line_start(l); }
  [[nodiscard]] std::string_view line(std::size_t l) const noexcept {
    return std::string_view(text_).substr(line_start(l), line_len(l));
  }
  [[nodiscard]] std::size_t line_of(std::size_t off) const noexcept {
    const auto it = std::upper_bound(starts_.begin(), starts_.end(), std::min(off, text_.size()));
    return static_cast<std::size_t>(it - starts_.begin()) - 1;
  }
  [[nodiscard]] std::size_t col_of(std::size_t off) const noexcept { return off - line_start(line_of(off)); }

  // ---- editing ----
  void type(char c) {  // one typed character; runs of letters merge into one undo step
    if (c == '\n') { newline(); return; }
    if (!allowed(c)) return;
    insert_impl(std::string_view(&c, 1), c == ' ' ? Kind::Other : Kind::Typing);
  }
  void insert(std::string_view s) { insert_impl(s, Kind::Other); }  // paste

  void newline() {  // keeps the indentation; after '{' '(' '[' it adds one level (and splits an empty pair)
    if (size_after_replace(2) > kMaxBytes) return;
    push_undo(Kind::Other);
    erase_selection_raw();
    const std::size_t ls = line_start(line_of(cur_));
    std::size_t indent = 0;
    while (ls + indent < cur_ && text_[ls + indent] == ' ') ++indent;
    const char before = cur_ > 0 ? text_[cur_ - 1] : '\0';
    const char after = cur_ < text_.size() ? text_[cur_] : '\0';
    const bool opener = before == '{' || before == '(' || before == '[';
    const bool pair = (before == '{' && after == '}') || (before == '(' && after == ')') || (before == '[' && after == ']');
    std::string ins = "\n" + std::string(indent + (opener ? 2 : 0), ' ');
    const std::size_t caret = ins.size();
    if (pair) ins += "\n" + std::string(indent, ' ');
    if (text_.size() + ins.size() > kMaxBytes) { changed(); return; }
    text_.insert(cur_, ins);
    cur_ = anchor_ = cur_ + caret;
    changed();
  }
  void tab() { insert_impl("  ", Kind::Other); }
  void outdent() {  // shift+tab: drops up to two leading spaces of the cursor's line
    const std::size_t ls = line_start(line_of(cur_));
    std::size_t n = 0;
    while (n < 2 && ls + n < text_.size() && text_[ls + n] == ' ') ++n;
    if (n == 0) return;
    push_undo(Kind::Other);
    text_.erase(ls, n);
    const auto fix = [&](std::size_t p) { return p >= ls + n ? p - n : (p > ls ? ls : p); };
    cur_ = fix(cur_);
    anchor_ = cur_;
    changed();
  }
  void backspace(bool word = false) {
    if (has_selection()) { delete_selection(); return; }
    if (cur_ == 0) return;
    const std::size_t from = word ? word_left(cur_) : cur_ - 1;
    push_undo(Kind::Delete);
    text_.erase(from, cur_ - from);
    cur_ = anchor_ = from;
    changed();
  }
  void del(bool word = false) {
    if (has_selection()) { delete_selection(); return; }
    if (cur_ >= text_.size()) return;
    const std::size_t to = word ? word_right(cur_) : cur_ + 1;
    push_undo(Kind::Delete);
    text_.erase(cur_, to - cur_);
    anchor_ = cur_;
    changed();
  }
  void delete_selection() {  // the selected text goes (cut)
    if (!has_selection()) return;
    push_undo(Kind::Other);
    erase_selection_raw();
    changed();
  }

  // ---- cursor ----
  void move_to(std::size_t off, bool extend) {
    cur_ = std::min(off, text_.size());
    if (!extend) anchor_ = cur_;
    last_ = Kind::None;
    goal_ = col_of(cur_);
  }
  void left(bool extend, bool word) {
    if (!extend && has_selection()) { move_to(sel_begin(), false); return; }
    move_to(word ? word_left(cur_) : (cur_ > 0 ? cur_ - 1 : 0), extend);
  }
  void right(bool extend, bool word) {
    if (!extend && has_selection()) { move_to(sel_end(), false); return; }
    move_to(word ? word_right(cur_) : cur_ + 1, extend);
  }
  void up(bool extend) { vertical(-1, extend); }
  void down(bool extend) { vertical(1, extend); }
  void page(int lines, bool extend) { vertical(lines, extend); }
  void home(bool extend, bool whole) {
    if (whole) { move_to(0, extend); return; }
    const std::size_t ls = line_start(line_of(cur_));
    std::size_t ns = ls;
    while (ns < text_.size() && text_[ns] == ' ') ++ns;
    move_to(cur_ == ns ? ls : ns, extend);  // first press: first word; again: column 0
  }
  void end(bool extend, bool whole) { move_to(whole ? text_.size() : line_end(line_of(cur_)), extend); }
  void select_all() {
    anchor_ = 0;
    cur_ = text_.size();
    last_ = Kind::None;
  }

  // ---- undo ----
  bool undo() {
    if (undo_.empty()) return false;
    redo_.push_back(snap());
    restore(undo_.back());
    undo_.pop_back();
    return true;
  }
  bool redo() {
    if (redo_.empty()) return false;
    undo_.push_back(snap());
    restore(redo_.back());
    redo_.pop_back();
    return true;
  }

 private:
  enum class Kind : u8 { None, Typing, Delete, Other };
  struct Snap { std::string text; std::size_t cur, anchor; };

  static bool is_word(char c) noexcept {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c == '$';
  }
  [[nodiscard]] std::size_t word_left(std::size_t i) const noexcept {
    while (i > 0 && !is_word(text_[i - 1])) --i;
    while (i > 0 && is_word(text_[i - 1])) --i;
    return i;
  }
  [[nodiscard]] std::size_t word_right(std::size_t i) const noexcept {
    const std::size_t n = text_.size();
    while (i < n && !is_word(text_[i])) ++i;
    while (i < n && is_word(text_[i])) ++i;
    return i;
  }
  [[nodiscard]] std::size_t size_after_replace(std::size_t added) const noexcept {
    return text_.size() - (sel_end() - sel_begin()) + added;
  }

  void rebuild() {
    starts_.clear();
    starts_.push_back(0);
    for (std::size_t i = 0; i < text_.size(); ++i)
      if (text_[i] == '\n') starts_.push_back(i + 1);
  }
  void changed() {
    rebuild();
    goal_ = col_of(cur_);
    ++version_;
  }
  [[nodiscard]] Snap snap() const { return {text_, cur_, anchor_}; }
  void restore(const Snap& s) {
    text_ = s.text;
    cur_ = s.cur;
    anchor_ = s.anchor;
    last_ = Kind::None;
    changed();
  }
  void push_undo(Kind k) {
    redo_.clear();
    const bool merge = (k == Kind::Typing || k == Kind::Delete) && last_ == k && !undo_.empty();
    if (!merge) {
      undo_.push_back(snap());
      if (undo_.size() > kMaxUndo) undo_.erase(undo_.begin());
    }
    last_ = k;
  }
  void erase_selection_raw() {
    if (!has_selection()) return;
    const std::size_t b = sel_begin();
    text_.erase(b, sel_end() - b);
    cur_ = anchor_ = b;
  }
  void insert_impl(std::string_view s_in, Kind k) {
    std::string s = sanitize(s_in);
    if (s.empty() && !has_selection()) return;
    const std::size_t room = kMaxBytes - (text_.size() - (sel_end() - sel_begin()));
    if (s.size() > room) s.resize(room);
    if (s.empty() && !has_selection()) return;
    push_undo(has_selection() ? Kind::Other : k);
    erase_selection_raw();
    text_.insert(cur_, s);
    cur_ = anchor_ = cur_ + s.size();
    changed();
  }
  void vertical(int delta, bool extend) {
    const long target = static_cast<long>(line_of(cur_)) + delta;
    last_ = Kind::None;
    if (target < 0) { cur_ = 0; }
    else if (target >= static_cast<long>(line_count())) { cur_ = text_.size(); }
    else {
      const std::size_t l = static_cast<std::size_t>(target);
      cur_ = line_start(l) + std::min(goal_, line_len(l));
    }
    if (!extend) anchor_ = cur_;
  }

  std::string text_;
  std::size_t cur_ = 0, anchor_ = 0, goal_ = 0;
  std::vector<std::size_t> starts_;
  std::vector<Snap> undo_, redo_;
  Kind last_ = Kind::None;
  u32 version_ = 0;
};

}  // namespace nv
