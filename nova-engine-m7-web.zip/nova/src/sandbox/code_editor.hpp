#pragma once
// Full-screen code editor for the script attached to one object: text area with line numbers and syntax
// colors, an edit toolbar and an on-screen keyboard built from the engine's own widgets (so it works on a
// phone browser, where there is no system keyboard for a canvas). The text logic lives in TextBuffer; the
// state kept here is header-only so Editor can drive it without SDL. frame() (update + draw) is in
// code_editor.cpp.
#include <string>
#include <string_view>
#include <vector>

#include "sandbox/edit_events.hpp"
#include "sandbox/highlight.hpp"
#include "sandbox/text_buffer.hpp"
#include "sandbox/ui.hpp"

namespace nv {

// One frame of input for the code screen (physical pixels).
struct CodeFrame {
  f32 width = 0.f, height = 0.f;  // window
  f32 x = 0.f, y = 0.f;           // pointer
  bool pressed = false, down = false, released = false;
  bool touch = false;             // the pointer is a finger: dragging scrolls instead of selecting
  f32 wheel = 0.f;                // wheel notches (+ = up)
  f32 dt = 0.f;
  const EditQueue* keys = nullptr;  // typed this frame (may be null)
};

enum class CodeResult : u8 { None, Apply, Cancel };

class CodeEditor {
 public:
  void open(std::string_view script, std::string_view title) {
    buf_.set(script);
    original_ = buf_.str();
    title_.assign(title);
    open_ = true;
    scroll_x_ = scroll_y_ = 0.f;
    follow_ = true;
    drag_ = Drag::None;
    held_ = -1;
    sel_mode_ = shift_ = symbols_ = false;
    if (!keys_touched_) keys_open_ = kDefaultKeys;
  }
  void close() {
    open_ = false;
    drag_ = Drag::None;
    held_ = -1;
  }
  [[nodiscard]] bool is_open() const noexcept { return open_; }
  [[nodiscard]] bool dirty() const { return buf_.str() != original_; }
  // A finger drag or a held key is in progress: keep rendering every frame.
  [[nodiscard]] bool busy() const noexcept { return open_ && (drag_ != Drag::None || held_ >= 0); }
  [[nodiscard]] const std::string& text() const noexcept { return buf_.str(); }
  [[nodiscard]] TextBuffer& buffer() noexcept { return buf_; }

  // Applies this frame's input and draws the screen. Returns Apply / Cancel when a button was pressed.
  CodeResult frame(ui::Ui& gui, const CodeFrame& f);

 private:
  enum class Drag : u8 { None, Pending, Scroll, Select };
#if defined(__EMSCRIPTEN__) || defined(SDL_PLATFORM_ANDROID) || defined(__ANDROID__)
  static constexpr bool kDefaultKeys = true;   // phones: the on-screen keyboard starts open
#else
  static constexpr bool kDefaultKeys = false;  // desktop: a physical keyboard (the KEYS button shows it)
#endif

  bool run_event(const EditEvent& e, std::string_view system_paste);

  TextBuffer buf_;
  std::string original_, title_, clip_;
  bool open_ = false;
  bool keys_open_ = kDefaultKeys, keys_touched_ = false;
  bool sel_mode_ = false;   // taps and arrows extend the selection
  bool shift_ = false;      // one-shot shift of the on-screen keyboard
  bool symbols_ = false;    // on-screen keyboard page
  bool follow_ = true;      // scroll so the cursor is visible after the next edit / move
  f32 scroll_x_ = 0.f, scroll_y_ = 0.f;
  Drag drag_ = Drag::None;
  f32 press_x_ = 0.f, press_y_ = 0.f, press_sx_ = 0.f, press_sy_ = 0.f;
  int held_ = -1;           // on-screen key being held (backspace repeats)
  f32 hold_t_ = 0.f, hold_acc_ = 0.f;
  std::vector<Tok> toks_;
};

}  // namespace nv
