#pragma once
// Syntax coloring for the code editor: a tiny line tokenizer for JavaScript-like scripts (keywords, strings,
// numbers, // and /* */ comments). Pure logic, unit-tested. Block comments carry over lines through `block`.
#include <cstddef>
#include <string_view>

#include "core/types.hpp"

namespace nv {

enum class Tok : u8 { Plain, Keyword, String, Number, Comment, Punct };

namespace detail {
inline constexpr std::string_view kKeywords[] = {
    "let", "const", "var", "function", "return", "if", "else", "for", "while", "do", "break", "continue", "true",
    "false", "null", "undefined", "new", "class", "extends", "this", "import", "export", "from", "of", "in",
    "switch", "case", "default", "try", "catch", "finally", "throw", "async", "await", "typeof", "static", "super"};
inline bool is_alpha(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c == '$'; }
inline bool is_digit(char c) { return c >= '0' && c <= '9'; }
}  // namespace detail

// Classifies every character of `line` into out[0..line.size()) (`out` may be null: only the block state is
// advanced). `block`: true on entry when the line starts inside a /* comment; on exit when it ends inside one.
inline void highlight_line(std::string_view line, bool& block, Tok* out) {
  using namespace detail;
  const std::size_t n = line.size();
  const auto mark = [&](std::size_t from, std::size_t to, Tok t) {
    if (out)
      for (std::size_t i = from; i < to; ++i) out[i] = t;
  };
  std::size_t i = 0;
  while (i < n) {
    if (block) {
      const std::size_t j = line.find("*/", i);
      const std::size_t end = j == std::string_view::npos ? n : j + 2;
      mark(i, end, Tok::Comment);
      if (j != std::string_view::npos) block = false;
      i = end;
      continue;
    }
    const char c = line[i];
    if (c == '/' && i + 1 < n && line[i + 1] == '/') { mark(i, n, Tok::Comment); return; }
    if (c == '/' && i + 1 < n && line[i + 1] == '*') { block = true; mark(i, i + 2, Tok::Comment); i += 2; continue; }
    if (c == '"' || c == '\'' || c == '`') {
      std::size_t j = i + 1;
      while (j < n && line[j] != c) j += line[j] == '\\' ? 2 : 1;
      j = j + 1 < n ? j + 1 : n;
      mark(i, j, Tok::String);
      i = j;
      continue;
    }
    if (is_digit(c) || (c == '.' && i + 1 < n && is_digit(line[i + 1]))) {
      std::size_t j = i + 1;
      while (j < n && (is_alpha(line[j]) || is_digit(line[j]) || line[j] == '.')) ++j;
      mark(i, j, Tok::Number);
      i = j;
      continue;
    }
    if (is_alpha(c)) {
      std::size_t j = i + 1;
      while (j < n && (is_alpha(line[j]) || is_digit(line[j]))) ++j;
      const std::string_view w = line.substr(i, j - i);
      Tok t = Tok::Plain;
      for (const std::string_view k : kKeywords)
        if (k == w) { t = Tok::Keyword; break; }
      mark(i, j, t);
      i = j;
      continue;
    }
    const bool punct = c != ' ' && !is_alpha(c) && !is_digit(c);
    mark(i, i + 1, punct ? Tok::Punct : Tok::Plain);
    ++i;
  }
}

}  // namespace nv
