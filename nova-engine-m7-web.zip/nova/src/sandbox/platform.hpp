#pragma once
// The few places where desktop / Android / browser (WebAssembly) differ. Everything else is shared C++.
#include <string>
#include <string_view>

struct SDL_Window;

namespace nv::platform {

#if defined(__EMSCRIPTEN__)
inline constexpr bool kIsWeb = true;
#else
inline constexpr bool kIsWeb = false;
#endif

// Writable per-user folder for settings + the project file, with a trailing '/' ("" when there is none).
// Browser: "/persist/", which web/shell.html mounts on IndexedDB.
std::string pref_dir();

// Browser: copies the pref folder to IndexedDB so it survives a reload (asynchronous, calls coalesce).
// Desktop / Android: nothing to do.
void flush_storage();

// Browser: resizes the SDL window (= the canvas) to the page, so phone rotation and the address bar work.
// Returns true when the size was changed. Desktop / Android: the window manager does this, always false.
bool fit_window_to_page(SDL_Window* window);

// System clipboard (best effort: the browser may refuse). Text only.
std::string clipboard_get();
void clipboard_set(std::string_view text);

// The code editor wants OS text events (physical keyboard) while it is open. Android / iOS: nothing, the
// editor draws its own keyboard and the system one must not pop up over it.
void text_input(SDL_Window* window, bool on);

}  // namespace nv::platform
