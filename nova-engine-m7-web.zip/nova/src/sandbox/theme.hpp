#pragma once
// Obsidian + silver look: palette and procedurally generated textures (no image assets).
// All textures are white RGBA with the shape in alpha, tinted per sprite by vertex color.
#include <vector>

#include "core/types.hpp"

namespace nv::theme {

// Obsidian: near-black with a cool cast. Silver: neutral light grey with a hint of blue.
inline constexpr Color kClear{7, 8, 11, 255};     // lobby / settings background (flat, no gradient)
inline constexpr Color kCanvas{17, 18, 23, 255};  // editor canvas: a touch lighter so ink reads clearly
inline constexpr Color kSilverHi{236, 239, 244, 255};
inline constexpr Color kSilverMid{176, 181, 191, 255};
inline constexpr Color kSilverLo{104, 109, 120, 255};

// Shapes packed into the shared atlas page (UI icons, widget knobs, canvas strokes).
enum Shape : u32 { kDisc, kRing, kGlow, kTriangle, kCrisp, kBar, kShapeCount };

struct Image {
  u32 w = 0, h = 0;
  std::vector<u8> rgba;
};

Image soft_disc(u32 n);               // crisp core, soft rim
Image ring(u32 n);                    // thin circle outline
Image glow(u32 n);                    // gaussian-like falloff (ambient light behind the menu)
Image triangle(u32 n);                // upward-pointing triangle, 1px-ish soft edge
Image crisp_disc(u32 n);              // full-alpha disc with a ~1.5 texel edge (canvas ellipses, brush caps)
Image bar(u32 w, u32 h);              // stroke body: opaque, antialiased on the two long edges only
Image grain(u32 n, u32 seed);         // seamless fine noise tile (alpha only), tinted + tiled for the menu backdrop
Image round_rect(u32 w, u32 h, f32 radius, f32 border);  // border <= 0: filled, else outline only

}  // namespace nv::theme
