#pragma once
// Tiny immediate-mode UI for the sandbox: buttons, toggles, sliders and the editor chrome.
// Everything is drawn through SpriteBatch (one batch, submit order = z-order), so it works
// the same on every backend. Input is mouse (SDL synthesizes it from touch) + keyboard focus.
#include <algorithm>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

#include "render/font.hpp"
#include "render/renderer.hpp"
#include "render/sprite_batch.hpp"
#include "sandbox/theme.hpp"

namespace nv::ui {

struct FontTex {
  BakedFont font;
  TextureId tex = 0;
};

struct Input {
  f32 x = 0.f, y = 0.f;  // pointer, physical pixels
  bool down = false;      // primary button held
  bool pressed = false;   // went down this frame
  bool released = false;  // went up this frame
  bool moved = false;     // real mouse motion this frame (switches off keyboard focus mode)
  bool touch = false;     // last pointer event came from touch (no hover afterwards)
  int nav_y = 0;          // keyboard: -1 up, +1 down
  int nav_x = 0;          // keyboard: -1 left, +1 right (sliders)
  bool activate = false;  // Enter / Space
  bool back = false;      // Esc / Android back
};

// Fixed logical sizes of the editor chrome skins (the editor lays its widgets out inside them).
inline constexpr f32 kRailW = 108.f, kRailH = 252.f;  // tool rail: two lines of 5 slots of 44 + gaps (turned in portrait)
inline constexpr f32 kDockW = 360.f, kDockH = 46.f;  // color swatches + brush sizes
inline constexpr f32 kZoomW = 132.f, kZoomH = 40.f;  // - 100% +
inline constexpr f32 kPickerW = 360.f, kPickerH = 132.f;  // custom color panel (opens above the dock)
inline constexpr f32 kMenuW = 252.f, kMenuH = 132.f;       // action menu: 3 x 3 mini buttons (opens above the MORE button)

// Edge of the square grain tile baked into the atlas (texels). The menu backdrop tiles it over the screen.
inline constexpr u32 kGrainPx = 128;

// A rounded panel baked at a fixed logical size (fill + 1px edge: white RGBA tinted per draw).
// Both live in the shared atlas; `fill`/`edge` are their uv rectangles.
struct Skin {
  Rect fill{}, edge{};
  f32 w = 0.f, h = 0.f;  // logical size (scaled by Ui::u() when drawn)
};

// Everything the widgets draw with. Created once by make_assets(). One atlas page holds the white
// pixel, all theme shapes and every skin, so UI and canvas sprites merge into very few draw calls.
struct Assets {
  TextureId atlas = 0;
  Rect uv[theme::kShapeCount];  // theme shapes
  Rect white{};                 // solid white region (flat rectangles)
  QuantUv white_q{};
  QuantUv grain_q{};            // kGrainPx x kGrainPx noise tile (menu backdrop texture)
  TextureId ellipse = 0;        // large crisp disc for big canvas ellipses (own texture: too big for the atlas)
  Skin wide, small, mini, pill, tool, rail, dock, zoom, picker, menu;
  FontTex hero, title, value, label, button;
  bool fonts_ok = false;
};

enum class Align { Left, Center, Right };

class Ui {
 public:
  Ui(SpriteBatch& batch, const Assets& assets, f32 density) : b_(batch), a_(assets), density_(density) {}

  // Call once per frame before any widget. `user_scale` is the Settings UI-scale slider.
  void begin(const Input& in, f32 width, f32 height, f32 dt, f32 user_scale);
  void end();

  [[nodiscard]] f32 k() const noexcept { return k_; }
  [[nodiscard]] bool portrait() const noexcept { return h_ > w_; }
  // Rows narrower than this stack their label above the slider track (phones in portrait).
  [[nodiscard]] bool narrow_row(f32 row_w) const noexcept { return row_w < u(480.f); }
  // logical units -> physical pixels (density and layout scale applied)
  [[nodiscard]] f32 u(f32 logical) const noexcept { return logical * density_ * k_; }
  [[nodiscard]] f32 width() const noexcept { return w_; }
  [[nodiscard]] f32 height() const noexcept { return h_; }

  // ---- widgets: `r` is in physical pixels (build it with u()) ----
  bool button(u32 id, Rect r, std::string_view label, bool enabled = true, bool primary = false,
              std::string_view tag = {});
  bool small_button(u32 id, Rect r, std::string_view label);
  // ---- editor chrome ----
  bool mini_button(u32 id, Rect r, std::string_view label, bool enabled = true);
  // Square tool slot; `icon` receives the color the caller should draw its icon with.
  bool tool_button(u32 id, Rect r, bool selected, Color& icon);
  bool swatch(u32 id, Vec2 center, f32 diameter, Color c, bool selected);
  bool size_dot(u32 id, Rect hit, f32 dot, bool selected);
  bool glyph_button(u32 id, Rect r, std::string_view glyph);  // text-only button (zoom -/+)
  // Flat-color slider strip for the color picker: `segs` are `n` flat colors drawn side by side (no gradient
  // shader), `t` in 0..1 is the knob position, `knob` the color shown inside it. `r` is the full hit area.
  bool strip(u32 id, Rect r, f32& t, const Color* segs, int n, Color knob);
  void panel(const Skin& s, f32 x, f32 y, Color fill, Color edge);
  // Same skin turned 90 degrees: occupies (s.h x s.w) logical units with its top-left at x, y.
  // Lets the vertical tool rail double as the horizontal one in portrait (no second atlas skin).
  void panel_turned(const Skin& s, f32 x, f32 y, Color fill, Color edge);
  // Primitive drawing for icons: shapes come from the shared atlas, rects from the white texture.
  void shape(theme::Shape s, Vec2 center, f32 size, Color c, f32 rotation = 0.f);
  void bar(Vec2 center, f32 length, f32 thickness, f32 rotation, Color c);
  bool toggle(u32 id, Rect row, std::string_view label, bool& value);
  bool slider(u32 id, Rect row, std::string_view label, f32& value, f32 lo, f32 hi, f32 step,
              const std::string& shown);

  // ---- text (baseline position, physical pixels) ----
  void text(const FontTex& f, std::string_view s, f32 x, f32 y, Align al, f32 tracking_logical, Color c);
  void rule(f32 x, f32 y, f32 w, Color c);  // 1px hairline
  void fill(Rect r, Color c);

  [[nodiscard]] bool keyboard_mode() const noexcept { return kbd_; }
  [[nodiscard]] bool pointer_captured() const noexcept { return active_ != 0; }  // a widget owns the press
  [[nodiscard]] const Assets& assets() const noexcept { return a_; }

 private:
  struct Anim { f32 hover = 0.f, press = 0.f, aux = 0.f; };
  Anim& anim(u32 id) { return anims_[id]; }
  // Hit-test + focus + click bookkeeping shared by all widgets. Returns clicked.
  bool interact(u32 id, Rect r, bool enabled, bool& hot);
  void approach(f32& v, f32 target) const { v += (target - v) * std::min(1.f, dt_ * 16.f); }

  SpriteBatch& b_;
  const Assets& a_;
  f32 density_;
  f32 k_ = 1.f, w_ = 0.f, h_ = 0.f, dt_ = 0.f;
  Input in_;
  bool kbd_ = false;
  u32 focus_ = 0, active_ = 0;  // focused widget / widget the pointer went down on
  std::vector<u32> order_, order_prev_;
  // Text is queued and drawn in end(), grouped per font, so a screen costs one draw call per font
  // instead of one per label (labels never overlap each other, so the z-order is unaffected).
  struct PendingText { const FontTex* font; f32 x, y, tracking; Color color; u32 off, len; };
  std::vector<PendingText> texts_;
  std::string text_buf_;
  std::unordered_map<u32, Anim> anims_;
};

// Reads a file next to the executable (Android: from the APK assets). Empty on failure.
std::vector<u8> load_asset(const char* relative_path);

// Builds the atlas, skins and fonts (needs the renderer; fonts load from assets/fonts).
// Returns assets with atlas == 0 when the atlas could not be packed into one page.
Assets make_assets(IRenderer& r, f32 density);
void destroy_assets(IRenderer& r, Assets& a);

}  // namespace nv::ui
