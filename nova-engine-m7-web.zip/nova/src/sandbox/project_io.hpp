#pragma once
// Reads / writes the project file in the per-user pref folder (SDL). The format lives in project.hpp.
#include <span>
#include <vector>

#include "core/types.hpp"
#include "sandbox/editor.hpp"

namespace nv {

// Writes project.nova through a temp file + rename, so a crash mid-save never destroys the previous save.
bool save_project_file(std::span<const u8> bytes);
// The saved bytes, or empty when there is no project file yet / it cannot be read.
std::vector<u8> load_project_file();

// The two things the keyboard shortcuts and the action menu both do. Each returns a short status literal
// ("SAVED", "OPENED", ...) for Editor::set_status(); the details are logged.
const char* project_save(const Editor& editor);
const char* project_open(Editor& editor);

}  // namespace nv
