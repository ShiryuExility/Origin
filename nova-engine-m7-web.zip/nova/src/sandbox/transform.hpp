#pragma once
// Move / rotate / scale geometry for the Select tool. Pure math (no SDL, no rendering) so it is unit-tested.
//
// A selection has an oriented frame (center, rotation, half extents). Scale handles live on that frame; a gesture
// produces an `Xf`, and `transformed()` bakes it into a new shape:
//   Stroke / Line : points are rotated / scaled directly (rotation is baked, the brush width stays the same).
//   Box / Oval    : the rect keeps its own `rot`, so rotated boxes and ellipses stay exact.
#include <algorithm>
#include <cmath>
#include <numbers>

#include "core/types.hpp"
#include "sandbox/shape.hpp"

namespace nv {

inline Vec2 rotate(Vec2 v, f32 ang) {
  const f32 c = std::cos(ang), s = std::sin(ang);
  return {v.x * c - v.y * s, v.x * s + v.y * c};
}

struct Frame {
  Vec2 c{};         // center
  f32 rot = 0.f;    // radians, clockwise on screen (y down)
  f32 hx = 0.f, hy = 0.f;  // half extents along the frame's own axes
};

inline Vec2 frame_to_local(const Frame& f, Vec2 p) { return rotate({p.x - f.c.x, p.y - f.c.y}, -f.rot); }
inline Vec2 frame_to_world(const Frame& f, Vec2 l) {
  const Vec2 r = rotate(l, f.rot);
  return {f.c.x + r.x, f.c.y + r.y};
}

// World-space bounding box of a shape (brush width and rotation included).
inline void compute_bounds(Shape2D& s) {
  f32 x0, y0, x1, y1, pad = 0.f;
  switch (s.kind) {
    case Shape2D::Stroke:
      x0 = x1 = s.pts.front().x;
      y0 = y1 = s.pts.front().y;
      for (const Vec2& p : s.pts) { x0 = std::min(x0, p.x); x1 = std::max(x1, p.x); y0 = std::min(y0, p.y); y1 = std::max(y1, p.y); }
      pad = s.width * 0.5f;
      break;
    case Shape2D::Line:
      x0 = std::min(s.a.x, s.b.x); x1 = std::max(s.a.x, s.b.x);
      y0 = std::min(s.a.y, s.b.y); y1 = std::max(s.a.y, s.b.y);
      pad = s.width * 0.5f;
      break;
    default: {
      const f32 cx = (s.a.x + s.b.x) * 0.5f, cy = (s.a.y + s.b.y) * 0.5f;
      f32 hx = (s.b.x - s.a.x) * 0.5f, hy = (s.b.y - s.a.y) * 0.5f;
      if (s.rot != 0.f) {  // rotated: exact extents (rect: |corner| sums, ellipse: root of squares)
        const f32 c = std::cos(s.rot), sn = std::sin(s.rot);
        const bool oval = s.kind == Shape2D::Oval;
        const f32 ex = oval ? std::sqrt(hx * hx * c * c + hy * hy * sn * sn) : std::fabs(hx * c) + std::fabs(hy * sn);
        const f32 ey = oval ? std::sqrt(hx * hx * sn * sn + hy * hy * c * c) : std::fabs(hx * sn) + std::fabs(hy * c);
        hx = ex;
        hy = ey;
      }
      x0 = cx - hx; x1 = cx + hx; y0 = cy - hy; y1 = cy + hy;
      break;
    }
  }
  s.bounds = {x0 - pad, y0 - pad, x1 - x0 + 2.f * pad, y1 - y0 + 2.f * pad};
}

// Selection frame. Strokes / lines: an axis-aligned box around the geometry (bounds minus the brush), grown to at
// least `min_half` per axis so a straight line still gets a usable box. Boxes / ovals: their own rotated rect.
inline Frame frame_of(const Shape2D& s, f32 min_half) {
  Frame f;
  if (s.kind == Shape2D::Box || s.kind == Shape2D::Oval) {
    f.c = {(s.a.x + s.b.x) * 0.5f, (s.a.y + s.b.y) * 0.5f};
    f.rot = s.rot;
    f.hx = (s.b.x - s.a.x) * 0.5f;
    f.hy = (s.b.y - s.a.y) * 0.5f;
  } else {
    const f32 pad = s.width * 0.5f;
    f.c = {s.bounds.x + s.bounds.w * 0.5f, s.bounds.y + s.bounds.h * 0.5f};
    f.hx = std::max(s.bounds.w * 0.5f - pad, min_half);
    f.hy = std::max(s.bounds.h * 0.5f - pad, min_half);
  }
  return f;
}

enum class Handle : u8 { None, Rotate, NW, N, NE, E, SE, S, SW, W };

inline bool is_corner(Handle h) { return h == Handle::NW || h == Handle::NE || h == Handle::SE || h == Handle::SW; }

// Direction of a scale handle in the frame's local space (y down: N = -1).
inline Vec2 handle_dir(Handle h) {
  switch (h) {
    case Handle::NW: return {-1.f, -1.f};
    case Handle::N: return {0.f, -1.f};
    case Handle::NE: return {1.f, -1.f};
    case Handle::E: return {1.f, 0.f};
    case Handle::SE: return {1.f, 1.f};
    case Handle::S: return {0.f, 1.f};
    case Handle::SW: return {-1.f, 1.f};
    case Handle::W: return {-1.f, 0.f};
    default: return {0.f, 0.f};
  }
}

// Where a handle is drawn, in local space: scale handles sit on the frame grown by `pad`; the rotate handle floats
// `rot_off` above the top edge.
inline Vec2 handle_local(const Frame& f, Handle h, f32 pad, f32 rot_off) {
  if (h == Handle::Rotate) return {0.f, -(f.hy + pad + rot_off)};
  const Vec2 d = handle_dir(h);
  return {d.x * (f.hx + pad), d.y * (f.hy + pad)};
}

// One gesture's transform, applied in the order: scale (local, about `anchor`) -> rotate (about the frame center) -> move.
struct Xf {
  Vec2 move{};
  f32 rotate = 0.f;
  Vec2 anchor{};
  Vec2 scale{1.f, 1.f};
};

// Scale transform for dragging handle `h` by `delta` (pointer travel since the press, in local space).
// Corners keep the aspect ratio; sides stretch one axis. The opposite side / corner stays fixed. Never flips.
inline Xf scale_xf(const Frame& f, Handle h, Vec2 delta) {
  constexpr f32 kMin = 0.02f;
  Xf x;
  const Vec2 d = handle_dir(h);
  const Vec2 hp{d.x * f.hx, d.y * f.hy};
  const Vec2 an{-hp.x, -hp.y};
  const Vec2 t{hp.x + delta.x, hp.y + delta.y};
  x.anchor = an;
  if (d.x != 0.f && d.y != 0.f) {
    const Vec2 v{hp.x - an.x, hp.y - an.y};
    const f32 den = v.x * v.x + v.y * v.y;
    const f32 s = den > 1e-9f ? ((t.x - an.x) * v.x + (t.y - an.y) * v.y) / den : 1.f;
    x.scale = {std::max(s, kMin), std::max(s, kMin)};
  } else if (d.x != 0.f) {
    const f32 den = hp.x - an.x;
    if (std::fabs(den) > 1e-6f) x.scale.x = std::max((t.x - an.x) / den, kMin);
  } else if (d.y != 0.f) {
    const f32 den = hp.y - an.y;
    if (std::fabs(den) > 1e-6f) x.scale.y = std::max((t.y - an.y) / den, kMin);
  }
  return x;
}

// Snaps to multiples of 15 degrees when within 3 degrees of one (an absolute angle, radians).
inline f32 snap_angle(f32 total) {
  constexpr f32 kStep = std::numbers::pi_v<f32> / 12.f, kTol = std::numbers::pi_v<f32> / 60.f;
  const f32 near = std::round(total / kStep) * kStep;
  return std::fabs(total - near) < kTol ? near : total;
}

// The shape after applying `x` in frame `f`. Bounds are recomputed.
inline Shape2D transformed(const Shape2D& s, const Frame& f, const Xf& x) {
  Shape2D r = s;
  const auto fin = [&](Vec2 w) {  // after scaling: rotate about the frame center, then move
    const Vec2 d = rotate({w.x - f.c.x, w.y - f.c.y}, x.rotate);
    return Vec2{f.c.x + d.x + x.move.x, f.c.y + d.y + x.move.y};
  };
  if (s.kind == Shape2D::Box || s.kind == Shape2D::Oval) {
    const f32 x0 = x.anchor.x + (-f.hx - x.anchor.x) * x.scale.x, x1 = x.anchor.x + (f.hx - x.anchor.x) * x.scale.x;
    const f32 y0 = x.anchor.y + (-f.hy - x.anchor.y) * x.scale.y, y1 = x.anchor.y + (f.hy - x.anchor.y) * x.scale.y;
    const Vec2 c = fin(frame_to_world(f, {(x0 + x1) * 0.5f, (y0 + y1) * 0.5f}));
    const f32 hx = std::max(std::fabs(x1 - x0) * 0.5f, 0.5f), hy = std::max(std::fabs(y1 - y0) * 0.5f, 0.5f);
    r.rot = f.rot + x.rotate;
    r.a = {c.x - hx, c.y - hy};
    r.b = {c.x + hx, c.y + hy};
  } else {
    const auto map = [&](Vec2 p) {
      Vec2 l = frame_to_local(f, p);
      l = {x.anchor.x + (l.x - x.anchor.x) * x.scale.x, x.anchor.y + (l.y - x.anchor.y) * x.scale.y};
      return fin(frame_to_world(f, l));
    };
    for (Vec2& p : r.pts) p = map(p);
    r.a = map(s.a);
    r.b = map(s.b);
  }
  compute_bounds(r);
  return r;
}

}  // namespace nv
