#pragma once
// Pen-stroke simplification (Ramer-Douglas-Peucker). A finished stroke keeps only the points that matter,
// so the canvas draws, hit-tests and snapshots far fewer segments with no visible change.
#include <algorithm>
#include <cstddef>
#include <utility>
#include <vector>

#include "core/types.hpp"

namespace nv {

namespace stroke_detail {
inline f32 seg_dist2(Vec2 p, Vec2 a, Vec2 b) {
  const f32 dx = b.x - a.x, dy = b.y - a.y, len2 = dx * dx + dy * dy;
  f32 t = len2 > 0.f ? ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2 : 0.f;
  t = std::clamp(t, 0.f, 1.f);
  const f32 ex = p.x - (a.x + dx * t), ey = p.y - (a.y + dy * t);
  return ex * ex + ey * ey;
}
}  // namespace stroke_detail

// Removes points that lie within `eps` (world units) of the line through their kept neighbours.
// First and last point always stay. Iterative: no recursion depth limit on very long strokes.
inline void simplify_stroke(std::vector<Vec2>& pts, f32 eps) {
  const std::size_t n = pts.size();
  if (n < 3 || eps <= 0.f) return;
  std::vector<char> keep(n, 0);
  keep[0] = keep[n - 1] = 1;
  std::vector<std::pair<std::size_t, std::size_t>> todo{{0, n - 1}};
  const f32 e2 = eps * eps;
  while (!todo.empty()) {
    const auto [a, b] = todo.back();
    todo.pop_back();
    if (b <= a + 1) continue;
    f32 worst = 0.f;
    std::size_t at = a;
    for (std::size_t i = a + 1; i < b; ++i) {
      const f32 d = stroke_detail::seg_dist2(pts[i], pts[a], pts[b]);
      if (d > worst) { worst = d; at = i; }
    }
    if (worst > e2) {
      keep[at] = 1;
      todo.emplace_back(a, at);
      todo.emplace_back(at, b);
    }
  }
  std::size_t w = 0;
  for (std::size_t i = 0; i < n; ++i)
    if (keep[i]) pts[w++] = pts[i];
  pts.resize(w);
}

}  // namespace nv
