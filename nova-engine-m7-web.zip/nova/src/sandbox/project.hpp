#pragma once
// Project file: the drawing plus the view, as one little-endian binary blob (SDL-free, unit-tested).
//   "NVPR" | u32 version | u32 object_count | f32 cam_x, cam_y, zoom | objects... | u32 FNV-1a of everything before
//   object: u8 kind | u8 r,g,b,a | f32 width | f32 a.x a.y b.x b.y | f32 rot | u32 point_count | point_count x (f32 x, y)
//           | (version 2) u32 script_length | script bytes (printable ASCII and '\n', at most TextBuffer::kMaxBytes)
// Version 1 files (no scripts) still load.
// Loading never trusts the file: sizes are checked before anything is allocated, every float must be finite
// and sane, and the checksum must match. A bad file returns nullopt and leaves the open drawing alone.
#include <optional>
#include <span>
#include <vector>

#include "sandbox/history.hpp"

namespace nv {

inline constexpr u32 kProjectVersion = 2;

struct Project {
  Doc shapes;
  Vec2 cam{};
  f32 zoom = 1.f;
};

[[nodiscard]] std::vector<u8> serialize_project(const Doc& shapes, Vec2 cam, f32 zoom);
[[nodiscard]] std::optional<Project> parse_project(std::span<const u8> bytes);

}  // namespace nv
