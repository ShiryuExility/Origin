// Nova sandbox: a lobby (create / settings) on a static grain backdrop, and a
// blank-canvas editor. Same file runs on PC, Android and in the browser (WebAssembly + WebGL 2):
// everything the frame loop touches lives in `App`, and `App::step()` is one frame, so a plain `while`
// drives it natively and requestAnimationFrame drives it on the web.
// Flat colors only: no gradients anywhere (sprites carry one color).
//
// Dev flags:  --keys DDE   (inject keys: U D L R = arrows, E = enter, B = back,
//                           one every 0.4 s; every screen change is logged)
//             --live       (never sleep when idle: render every vsync, for FPS measurements)
#include <SDL3/SDL.h>
#include <SDL3/SDL_main.h>

#if defined(__EMSCRIPTEN__)
#include <emscripten/emscripten.h>
#endif

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <string>
#include <string_view>
#include <vector>

#include "render/atlas.hpp"
#include "render/font.hpp"
#include "render/renderer.hpp"
#include "render/sprite_batch.hpp"
#include "sandbox/editor.hpp"
#include "sandbox/input.hpp"
#include "sandbox/menu.hpp"
#include "sandbox/platform.hpp"
#include "sandbox/project_io.hpp"
#include "sandbox/settings.hpp"
#include "sandbox/theme.hpp"
#include "sandbox/ui.hpp"

using namespace nv;

namespace {

enum class Screen { Lobby, Settings, Editor };

const char* screen_name(Screen s) {
  switch (s) {
    case Screen::Lobby: return "Lobby";
    case Screen::Settings: return "Settings";
    case Screen::Editor: return "Editor";
  }
  return "?";
}

class App {
 public:
  App(SDL_Window* window, std::unique_ptr<IRenderer> renderer, f32 density, bool live, std::string key_script)
      : window_(window),
        renderer_(std::move(renderer)),
        density_(density),
        live_(live),
        key_script_(std::move(key_script)),
        settings_(load_settings()),
        // One atlas page holds the white pixel, every shape and every UI skin: particles, icons, knobs,
        // buttons and canvas strokes all batch into the same draw call.
        assets_(ui::make_assets(*renderer_, density_)),
        atlas_tex_(assets_.atlas),
        white_uv_(assets_.white_q),
        batch_(SpriteBatch::kMaxSprites),
        gui_(batch_, assets_, density_),
        editor_(density_),
        freq_(static_cast<double>(SDL_GetPerformanceFrequency())),
        last_(SDL_GetPerformanceCounter()) {
    int pw = 0, ph = 0;
    SDL_GetWindowSizeInPixels(window_, &pw, &ph);
    last_pw_ = static_cast<u32>(pw);
    last_ph_ = static_cast<u32>(ph);
  }

  [[nodiscard]] bool ready() const noexcept { return assets_.atlas != 0; }

  // One frame. Returns false once the app wants to quit.
  bool step() {
    ui::Input& in = frame_.in;
    Pointer& ptr = frame_.ptr;

    // Browser: follow the page size (phone rotation, address bar) before anything reads the window size.
    if (platform::fit_window_to_page(window_)) hot_frames_ = 24;

    // Every screen is static between inputs: sleep until something happens instead of redrawing
    // identical frames (big battery / thermal win on phones). `--live` turns this off for benchmarking.
    const bool animating = live_ || fade_ > 0.f || hot_frames_ > 0 ||
                           (screen_ == Screen::Editor && editor_.busy()) || key_index_ < key_script_.size();
    if (!animating) {
#if defined(__EMSCRIPTEN__)
      // The browser calls us once per display refresh and we must return: skip the frame when idle (the
      // canvas keeps showing the last one), render again as soon as an event is queued.
      SDL_PumpEvents();
      if (!SDL_HasEvents(SDL_EVENT_FIRST, SDL_EVENT_LAST)) return running_;
#else
      SDL_WaitEventTimeout(nullptr, 1000);  // NULL = peek: the loop below consumes it
#endif
    }

    // ---- input -------------------------------------------------------------------
    const bool got_event = poll_input(frame_, window_, *renderer_, density_, screen_ == Screen::Editor, editor_);
    if (frame_.quit) running_ = false;
    if (screen_ == Screen::Editor) {  // two fingers: drop what one finger started, then pan + zoom
      if (frame_.pinch.cancel) editor_.cancel_gesture();
      if (frame_.pinch.active)
        editor_.pinch(frame_.pinch.cx, frame_.pinch.cy, frame_.pinch.factor, frame_.pinch.dx, frame_.pinch.dy,
                      frame_.width, frame_.height);
    }
    if (got_event) hot_frames_ = 24;
    else if (hot_frames_ > 0) --hot_frames_;

    const u64 now = SDL_GetPerformanceCounter();
    double dt = static_cast<double>(now - last_) / freq_;
    last_ = now;
    if (dt > 0.25) dt = 0.25;
    const f32 ui_dt = static_cast<f32>(dt > 1.0 / 30.0 ? 1.0 / 30.0 : dt);  // no animation jumps after an idle sleep
    if (animating) {  // frames after an idle sleep would skew the FPS average
      fps_time_ += dt;
      ++frames_;
    } else {
      fps_time_ = 0.0;
      frames_ = 0;
    }

    // Scripted keys (dev/testing): one every 0.4 s.
    if (key_index_ < key_script_.size()) {
      key_timer_ -= dt;
      if (key_timer_ <= 0.0) {
        key_timer_ = 0.4;
        switch (key_script_[key_index_++]) {
          case 'U': in.nav_y = -1; break;
          case 'D': in.nav_y = 1; break;
          case 'L': in.nav_x = -1; break;
          case 'R': in.nav_x = 1; break;
          case 'E': in.activate = true; break;
          case 'B': in.back = true; break;
          default: break;
        }
      }
    }

    fade_ = std::fmax(0.f, fade_ - static_cast<f32>(dt) * 4.f);

    int pw = 0, ph = 0;
    SDL_GetWindowSizeInPixels(window_, &pw, &ph);
    if (static_cast<u32>(pw) != last_pw_ || static_cast<u32>(ph) != last_ph_) {
      // The drawable changed (the browser resizes the canvas without a guaranteed event): keep the viewport in sync.
      last_pw_ = static_cast<u32>(pw);
      last_ph_ = static_cast<u32>(ph);
      renderer_->resize(last_pw_, last_ph_);
    }
    const f32 W = static_cast<f32>(pw), H = static_cast<f32>(ph);
    Camera2D ui_cam;  // screen space: 1 unit = 1 physical pixel, origin top-left
    ui_cam.position = {W * 0.5f, H * 0.5f};
    ui_cam.zoom = 1.f;

    renderer_->begin_frame(screen_ == Screen::Editor ? theme::kCanvas : theme::kClear);
    draw_calls_ = sprites_ = 0;
    const auto flush = [&](const Camera2D& cam) {
      draw_calls_ += static_cast<u32>(batch_.runs().size());
      sprites_ += batch_.sprite_count();
      renderer_->draw(batch_, cam);
      batch_.clear();
    };
    gui_.begin(in, W, H, ui_dt, settings_.ui_scale);
    const f32 cx = W * 0.5f, cy = H * 0.5f;

    if (screen_ == Screen::Editor && in.back && editor_.code_open()) {  // back keeps the script and returns to the canvas
      editor_.close_code(true);
      in.back = false;
    }
    if (screen_ == Screen::Editor && editor_.code_open()) {
      // The code screen covers the whole window and takes all input; the canvas below is not touched.
      const CodeFrame cf{W, H, in.x, in.y, in.pressed, in.down, in.released, in.touch, ptr.wheel, ui_dt, &frame_.edits};
      editor_.code_ui(gui_, cf);
    } else if (screen_ == Screen::Editor) {
      // The canvas fills the whole window; there is no backdrop, vignette or scrim to blend.
      const Editor::Layout lay = editor_.layout(gui_, W, H);
      ptr.x = in.x;
      ptr.y = in.y;
      ptr.pressed = in.pressed;
      ptr.down = in.down;
      ptr.released = in.released;
      editor_.update(ptr, W, H, Editor::over_chrome(lay, in.x, in.y));
      editor_.draw_canvas(batch_, assets_, W, H, [&] { flush(editor_.camera()); });
      flush(editor_.camera());

      char hud[96];  // stack buffer: the frame loop does not touch the heap
      int hud_len = 0;
      if (settings_.show_hud)
        hud_len = std::snprintf(hud, sizeof hud, "FPS %u   /   OBJECTS %u   /   DRAW CALLS %u", shown_fps_,
                                editor_.object_count(), prev_draw_calls_);
      const bool leave = editor_.chrome(gui_, lay, std::string_view(hud, static_cast<std::size_t>(hud_len)));
      switch (editor_.take_request()) {  // file work asked for by the action menu
        case Editor::Request::Save: editor_.set_status(project_save(editor_)); break;
        case Editor::Request::Open: editor_.set_status(project_open(editor_)); break;
        case Editor::Request::None: break;
      }
      if (leave || in.back) go(Screen::Lobby);
    } else {
      menu::draw_backdrop(batch_, assets_, W, H, density_);
      const menu::Stats stats{shown_fps_, prev_draw_calls_, prev_sprites_};
      const menu::Action act = screen_ == Screen::Lobby
                                   ? menu::lobby(gui_, assets_, settings_.show_hud, stats)
                                   : menu::settings_screen(gui_, assets_, in.back, settings_, settings_dirty_, stats);
      switch (act) {
        case menu::Action::Create:
          editor_.reset();  // always a fresh blank canvas
          go(Screen::Editor);
          break;
        case menu::Action::Settings: go(Screen::Settings); break;
        case menu::Action::Back: go(Screen::Lobby); break;
        case menu::Action::Quit: running_ = false; break;
        case menu::Action::None: break;
      }
#if defined(SDL_PLATFORM_ANDROID)
      if (screen_ == Screen::Lobby && in.back) running_ = false;
#endif
    }
    gui_.end();

    // OS text events (physical keyboard) are only wanted while the code editor is open.
    const bool want_text = screen_ == Screen::Editor && editor_.code_open();
    if (want_text != text_input_) {
      text_input_ = want_text;
      platform::text_input(window_, want_text);
    }

    if (fade_ > 0.f)  // screen-change fade from black
      batch_.draw_quad(atlas_tex_, {cx, cy}, {W, H}, white_uv_, Color{7, 8, 11, static_cast<u8>(255.f * fade_)});
    flush(ui_cam);
    renderer_->end_frame();
    prev_draw_calls_ = draw_calls_;
    prev_sprites_ = sprites_;

    if (fps_time_ >= 0.25) {
      shown_fps_ = static_cast<u32>(frames_ / fps_time_ + 0.5);
#if !defined(__EMSCRIPTEN__)  // the browser tab title is not an FPS counter (the HUD shows it)
      char title[96];
      std::snprintf(title, sizeof title, "Nova - %s - %u fps", screen_name(screen_), shown_fps_);
      SDL_SetWindowTitle(window_, title);
#endif
      fps_time_ = 0.0;
      frames_ = 0;
    }
    return running_;
  }

  // Saves pending settings and tears SDL down. Safe to call twice.
  void finish() {
    if (finished_) return;
    finished_ = true;
    if (settings_dirty_) save_settings(settings_);
    ui::destroy_assets(*renderer_, assets_);
    renderer_.reset();
    SDL_DestroyWindow(window_);
    SDL_Quit();
  }

 private:
  void go(Screen s) {
    if (s == screen_) return;
    if (screen_ == Screen::Settings && settings_dirty_) {
      save_settings(settings_);
      settings_dirty_ = false;
    }
    SDL_Log("screen=%s", screen_name(s));
    screen_ = s;
    fade_ = 1.f;  // 1 = black, fades out after every screen change
  }

  SDL_Window* window_;
  std::unique_ptr<IRenderer> renderer_;
  f32 density_;
  bool live_;
  std::string key_script_;
  Settings settings_;
  ui::Assets assets_;
  TextureId atlas_tex_;
  QuantUv white_uv_;
  SpriteBatch batch_;
  ui::Ui gui_;
  Editor editor_;
  double freq_;
  u64 last_;

  Screen screen_ = Screen::Lobby;
  f32 fade_ = 1.f;
  bool settings_dirty_ = false;
  InputFrame frame_;
  std::size_t key_index_ = 0;
  double key_timer_ = 0.8;  // first scripted key after the window settled
  u32 hot_frames_ = 24;     // keep rendering this many frames after the last input (UI easing)
  double fps_time_ = 0.0;
  u32 frames_ = 0, shown_fps_ = 0, draw_calls_ = 0, prev_draw_calls_ = 0, sprites_ = 0, prev_sprites_ = 0;
  u32 last_pw_ = 0, last_ph_ = 0;
  bool running_ = true;
  bool finished_ = false;
  bool text_input_ = false;
};

}  // namespace

int main(int argc, char** argv) {
  Backend backend = Backend::GLES;  // Vulkan backend lands in a later milestone
  std::string key_script;
  bool live = false;
  for (int i = 1; i < argc; ++i) {
    if (!std::strcmp(argv[i], "--vulkan")) backend = Backend::Vulkan;
    if (!std::strcmp(argv[i], "--gles")) backend = Backend::GLES;
    if (!std::strcmp(argv[i], "--live")) live = true;
    if (!std::strcmp(argv[i], "--keys") && i + 1 < argc) key_script = argv[++i];
  }

  if (!SDL_Init(SDL_INIT_VIDEO)) {
    SDL_Log("SDL_Init failed: %s", SDL_GetError());
    return 1;
  }
  const u64 flags = renderer_window_flags(backend) | SDL_WINDOW_RESIZABLE | SDL_WINDOW_HIGH_PIXEL_DENSITY;
  SDL_Window* window = SDL_CreateWindow("Nova", 1280, 720, flags);
  if (!window) {
    SDL_Log("SDL_CreateWindow failed: %s", SDL_GetError());
    SDL_Quit();
    return 1;
  }
  platform::fit_window_to_page(window);  // browser: canvas = page; elsewhere nothing
  auto renderer = create_renderer(backend, window, SpriteBatch::kMaxSprites);
  if (!renderer) {
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 1;
  }
  {
    int pw = 0, ph = 0;
    SDL_GetWindowSizeInPixels(window, &pw, &ph);
    renderer->resize(static_cast<u32>(pw), static_cast<u32>(ph));
  }
  f32 density = SDL_GetWindowPixelDensity(window);
  if (density < 1.f) density = 1.f;

  auto app = std::make_unique<App>(window, std::move(renderer), density, live, std::move(key_script));
  if (!app->ready()) return 1;

#if defined(__EMSCRIPTEN__)
  // The browser owns the loop: one App::step() per requestAnimationFrame. With simulate_infinite_loop main()
  // never returns, so the App is released to live as long as the page does.
  emscripten_set_main_loop_arg(
      [](void* p) {
        auto* a = static_cast<App*>(p);
        if (!a->step()) {
          emscripten_cancel_main_loop();
          a->finish();
        }
      },
      app.release(), 0, true);
  return 0;
#else
  while (app->step()) {
  }
  app->finish();
  return 0;
#endif
}
