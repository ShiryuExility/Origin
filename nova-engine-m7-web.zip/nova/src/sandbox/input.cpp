#include "sandbox/input.hpp"
#include "sandbox/platform.hpp"
#include "sandbox/project_io.hpp"

#include <SDL3/SDL.h>

#include <algorithm>
#include <cmath>
#include <vector>

namespace nv {
namespace {

// Code editor open: control keys become edit events (printable characters arrive as SDL text input).
void code_key(EditQueue& q, const SDL_KeyboardEvent& k) {
  const bool ctrl = (k.mod & (SDL_KMOD_CTRL | SDL_KMOD_GUI)) != 0;
  const bool shift = (k.mod & SDL_KMOD_SHIFT) != 0;
  EditEvent e;
  e.shift = shift;
  e.ctrl = ctrl;
  switch (k.key) {
    case SDLK_BACKSPACE: e.kind = EditEvent::Backspace; break;
    case SDLK_DELETE: e.kind = EditEvent::Delete; break;
    case SDLK_RETURN: case SDLK_KP_ENTER: e.kind = EditEvent::Enter; break;
    case SDLK_TAB: e.kind = EditEvent::Tab; break;
    case SDLK_LEFT: e.kind = EditEvent::Left; break;
    case SDLK_RIGHT: e.kind = EditEvent::Right; break;
    case SDLK_UP: e.kind = EditEvent::Up; break;
    case SDLK_DOWN: e.kind = EditEvent::Down; break;
    case SDLK_HOME: e.kind = EditEvent::Home; break;
    case SDLK_END: e.kind = EditEvent::End; break;
    case SDLK_PAGEUP: e.kind = EditEvent::PageUp; break;
    case SDLK_PAGEDOWN: e.kind = EditEvent::PageDown; break;
    case SDLK_A: if (!ctrl) return; e.kind = EditEvent::SelectAll; break;
    case SDLK_C: if (!ctrl) return; e.kind = EditEvent::Copy; break;
    case SDLK_X: if (!ctrl) return; e.kind = EditEvent::Cut; break;
    case SDLK_V:
      if (!ctrl) return;
      e.kind = EditEvent::Paste;
      q.paste = platform::clipboard_get();
      break;
    case SDLK_Z: if (!ctrl) return; e.kind = shift ? EditEvent::Redo : EditEvent::Undo; break;
    case SDLK_Y: if (!ctrl) return; e.kind = EditEvent::Redo; break;
    default: return;
  }
  q.push(e);
}

int finger_slot(const InputFrame& f, u64 id) {
  for (int i = 0; i < 2; ++i)
    if (f.fingers[i].down && f.fingers[i].id == id) return i;
  return -1;
}

}  // namespace

bool poll_input(InputFrame& f, SDL_Window* window, IRenderer& renderer, f32 density, bool editor_active,
                Editor& editor) {
  f.in.pressed = f.in.released = f.in.moved = f.in.activate = f.in.back = false;
  f.in.nav_x = f.in.nav_y = 0;
  f.ptr.wheel = 0.f;
  f.ptr.trail_n = 0;
  f.pinch = {};
  f.edits.clear();
  {
    int pw = 0, ph = 0;
    SDL_GetWindowSizeInPixels(window, &pw, &ph);
    f.width = static_cast<f32>(pw);
    f.height = static_cast<f32>(ph);
  }
  bool got_event = false;
  SDL_Event ev;
  while (SDL_PollEvent(&ev)) {
    got_event = true;
    switch (ev.type) {
      case SDL_EVENT_QUIT:
        f.quit = true;
        break;
      case SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED:
        renderer.resize(static_cast<u32>(ev.window.data1), static_cast<u32>(ev.window.data2));
        break;
      case SDL_EVENT_TEXT_INPUT:
        if (editor_active && editor.code_open()) {
          for (const char* c = ev.text.text; *c; ++c) {
            if (!TextBuffer::allowed(*c) || *c == '\n') continue;  // ASCII only: the fonts have no more
            EditEvent e;
            e.kind = EditEvent::Char;
            e.ch = *c;
            f.edits.push(e);
          }
        }
        break;
      case SDL_EVENT_MOUSE_MOTION:
      if (f.latched && ev.motion.which == SDL_TOUCH_MOUSEID) break;  // pinching: no drawing
        f.in.x = ev.motion.x * density;
        f.in.y = ev.motion.y * density;
        f.in.touch = ev.motion.which == SDL_TOUCH_MOUSEID;
        f.in.moved = !f.in.touch;
        if (f.in.down && f.ptr.trail_n < Pointer::kTrailMax)  // keep every sample, not just the last one of the frame
          f.ptr.trail[f.ptr.trail_n++] = {f.in.x, f.in.y};
        break;
      case SDL_EVENT_MOUSE_WHEEL:
        f.ptr.wheel += ev.wheel.y;
        break;
      case SDL_EVENT_MOUSE_BUTTON_DOWN:
      if (f.latched && ev.button.which == SDL_TOUCH_MOUSEID) break;  // pinching: no drawing
        f.in.x = ev.button.x * density;
        f.in.y = ev.button.y * density;
        if (ev.button.button == SDL_BUTTON_LEFT) {
          f.in.touch = ev.button.which == SDL_TOUCH_MOUSEID;
          f.in.pressed = f.in.down = true;
        } else if (ev.button.button == SDL_BUTTON_MIDDLE || ev.button.button == SDL_BUTTON_RIGHT) {
          f.ptr.pan_down = true;
        }
        break;
      case SDL_EVENT_MOUSE_BUTTON_UP:
      if (f.latched && ev.button.which == SDL_TOUCH_MOUSEID) break;  // pinching: no drawing
        f.in.x = ev.button.x * density;
        f.in.y = ev.button.y * density;
        if (ev.button.button == SDL_BUTTON_LEFT) {
          f.in.released = true;
          f.in.down = false;
        } else if (ev.button.button == SDL_BUTTON_MIDDLE || ev.button.button == SDL_BUTTON_RIGHT) {
          f.ptr.pan_down = false;
        }
        break;
      case SDL_EVENT_KEY_DOWN: {
        const SDL_Keycode k = ev.key.key;
        const bool repeat = ev.key.repeat;
        if (k == SDLK_ESCAPE || k == SDLK_AC_BACK) {
          if (!repeat) f.in.back = true;
          break;
        }
        if (editor_active && editor.code_open()) {  // the code editor takes every key
          code_key(f.edits, ev.key);
          break;
        }
        if (editor_active) {  // letters are tool shortcuts here, not menu navigation
          const bool ctrl = (ev.key.mod & (SDL_KMOD_CTRL | SDL_KMOD_GUI)) != 0;
          const bool shift = (ev.key.mod & SDL_KMOD_SHIFT) != 0;
          int pw = 0, ph = 0;
          SDL_GetWindowSizeInPixels(window, &pw, &ph);
          const f32 cw = static_cast<f32>(pw), ch = static_cast<f32>(ph);
          if (ctrl && k == SDLK_Z) { if (shift) editor.redo(); else editor.undo(); }
          else if (ctrl && k == SDLK_Y) editor.redo();
          else if (ctrl && !repeat && k == SDLK_D) editor.duplicate_selection();
          else if (ctrl && !repeat && k == SDLK_S) editor.set_status(project_save(editor));
          else if (ctrl && !repeat && k == SDLK_O) editor.set_status(project_open(editor));
          else if (!ctrl && !repeat) {
            switch (k) {
              case SDLK_V: case SDLK_1: editor.set_tool(Tool::Select); break;
              case SDLK_M: case SDLK_9: editor.set_tool(Tool::Move); break;
              case SDLK_S: editor.set_tool(Tool::Scale); break;
              case SDLK_Q: case SDLK_8: editor.set_tool(Tool::Rotate); break;
              case SDLK_RETURN: case SDLK_KP_ENTER: editor.open_code(); break;  // script of the selected object
              case SDLK_H: case SDLK_2: editor.set_tool(Tool::Hand); break;
              case SDLK_P: case SDLK_3: editor.set_tool(Tool::Pen); break;
              case SDLK_L: case SDLK_4: editor.set_tool(Tool::Line); break;
              case SDLK_R: case SDLK_5: editor.set_tool(Tool::Rect); break;
              case SDLK_O: case SDLK_6: editor.set_tool(Tool::Ellipse); break;
              case SDLK_E: case SDLK_7: editor.set_tool(Tool::Eraser); break;
              case SDLK_G: editor.toggle_grid(); break;
              case SDLK_F: editor.zoom_to_fit(); break;
              case SDLK_LEFTBRACKET: editor.send_to_back(); break;
              case SDLK_RIGHTBRACKET: editor.bring_to_front(); break;
              case SDLK_0: editor.reset_view(); break;
              case SDLK_DELETE: case SDLK_BACKSPACE: editor.delete_selection(); break;
              default: break;
            }
          }
          switch (k) {
            case SDLK_EQUALS: case SDLK_PLUS: case SDLK_KP_PLUS: editor.zoom_by(1.2f, cw * 0.5f, ch * 0.5f, cw, ch); break;
            case SDLK_MINUS: case SDLK_KP_MINUS: editor.zoom_by(1.f / 1.2f, cw * 0.5f, ch * 0.5f, cw, ch); break;
            case SDLK_LEFT: editor.pan_pixels(-48.f, 0.f); break;
            case SDLK_RIGHT: editor.pan_pixels(48.f, 0.f); break;
            case SDLK_UP: editor.pan_pixels(0.f, -48.f); break;
            case SDLK_DOWN: editor.pan_pixels(0.f, 48.f); break;
            default: break;
          }
          break;
        }
        switch (k) {
          case SDLK_UP: case SDLK_W: f.in.nav_y = -1; break;
          case SDLK_DOWN: case SDLK_S: f.in.nav_y = 1; break;
          case SDLK_LEFT: case SDLK_A: f.in.nav_x = -1; break;
          case SDLK_RIGHT: case SDLK_D: f.in.nav_x = 1; break;
          case SDLK_RETURN: case SDLK_KP_ENTER: case SDLK_SPACE:
            if (!repeat) f.in.activate = true;
            break;
          default: break;
        }
        break;
      }
      case SDL_EVENT_FINGER_DOWN: {
        const u64 id = ev.tfinger.fingerID;
        if (finger_slot(f, id) >= 0) break;
        const int free_slot = !f.fingers[0].down ? 0 : (!f.fingers[1].down ? 1 : -1);
        if (free_slot < 0) break;  // a third finger is ignored
        f.fingers[free_slot] = {id, ev.tfinger.x * f.width, ev.tfinger.y * f.height, true};
        if (f.fingers[0].down && f.fingers[1].down) {
          f.latched = true;
          f.pinch.cancel = true;
          f.in.pressed = f.in.released = f.in.down = false;  // whatever finger 1 was doing is over
          const f32 dx = f.fingers[1].x - f.fingers[0].x, dy = f.fingers[1].y - f.fingers[0].y;
          f.prev_dist = std::sqrt(dx * dx + dy * dy);
          f.prev_cx = (f.fingers[0].x + f.fingers[1].x) * 0.5f;
          f.prev_cy = (f.fingers[0].y + f.fingers[1].y) * 0.5f;
        }
        break;
      }
      case SDL_EVENT_FINGER_MOTION: {
        const int i = finger_slot(f, ev.tfinger.fingerID);
        if (i < 0) break;
        f.fingers[i].x = ev.tfinger.x * f.width;
        f.fingers[i].y = ev.tfinger.y * f.height;
        if (f.latched && f.fingers[0].down && f.fingers[1].down) {
          const f32 dx = f.fingers[1].x - f.fingers[0].x, dy = f.fingers[1].y - f.fingers[0].y;
          const f32 dist = std::sqrt(dx * dx + dy * dy);
          const f32 cx = (f.fingers[0].x + f.fingers[1].x) * 0.5f, cy = (f.fingers[0].y + f.fingers[1].y) * 0.5f;
          if (f.prev_dist > 1.f) {
            f.pinch.factor *= std::clamp(dist / f.prev_dist, 0.5f, 2.f);
            f.pinch.dx += cx - f.prev_cx;
            f.pinch.dy += cy - f.prev_cy;
            f.pinch.active = true;
          }
          f.pinch.cx = cx;
          f.pinch.cy = cy;
          f.prev_dist = dist;
          f.prev_cx = cx;
          f.prev_cy = cy;
        }
        break;
      }
      case SDL_EVENT_FINGER_UP:
      case SDL_EVENT_FINGER_CANCELED: {
        const int i = finger_slot(f, ev.tfinger.fingerID);
        if (i >= 0) f.fingers[i].down = false;
        f.prev_dist = 0.f;  // one finger left: no more pinch until two are down again
        if (!f.fingers[0].down && !f.fingers[1].down) {
          f.latched = false;  // everything lifted: single-touch drawing works again
          f.in.down = false;
        }
        break;
      }
      default:
        break;
    }
  }
  return got_event;
}

}  // namespace nv
