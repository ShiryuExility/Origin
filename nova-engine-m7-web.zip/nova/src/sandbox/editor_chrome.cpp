#include <algorithm>
#include <cmath>
#include <cstdio>

#include "sandbox/editor.hpp"
#include "sandbox/editor_internal.hpp"

// Floating chrome of the editor: tool rail, color dock + custom color panel, zoom pill, top-right buttons.
namespace nv {
using namespace ed;
namespace {

constexpr Color kPanelFill{13, 14, 19, 234}, kPanelEdge{190, 196, 208, 56};
constexpr Color kHudDim{104, 109, 120, 210};

enum Id : u32 { kToolBase = 200, kSwatchBase = 220, kSizeBase = 240, kUndo = 250, kRedo, kLobby, kZoomOut, kZoomIn,
                kRecentBase = 260, kHue = 270, kSat, kVal, kMore = 280, kMenuBase = 290 };

const char* tool_name(Tool t) {
  switch (t) {
    case Tool::Select: return "SELECT";
    case Tool::Move: return "MOVE";
    case Tool::Scale: return "SCALE";
    case Tool::Rotate: return "ROTATE";
    case Tool::Hand: return "HAND";
    case Tool::Pen: return "PEN";
    case Tool::Line: return "LINE";
    case Tool::Rect: return "RECTANGLE";
    case Tool::Ellipse: return "ELLIPSE";
    case Tool::Eraser: return "ERASER";
    default: return "";
  }
}

}  // namespace

Editor::Layout Editor::layout(const ui::Ui& gui, f32 W, f32 H) const {
  const auto u = [&](f32 v) { return gui.u(v); };
  const f32 m = u(14.f);
  Layout l;
  l.portrait = gui.portrait();
  l.dock = {(W - u(ui::kDockW)) * 0.5f, H - m - u(ui::kDockH), u(ui::kDockW), u(ui::kDockH)};
  if (l.portrait) {  // bottom stack, thumb height: dock, rail (turned horizontal), zoom pill
    const f32 gap = u(8.f);
    l.rail = {(W - u(ui::kRailH)) * 0.5f, l.dock.y - gap - u(ui::kRailW), u(ui::kRailH), u(ui::kRailW)};
    l.zoom = {W - m - u(ui::kZoomW), l.rail.y - gap - u(ui::kZoomH), u(ui::kZoomW), u(ui::kZoomH)};
  } else {
    l.rail = {m, H * 0.5f - u(ui::kRailH) * 0.5f, u(ui::kRailW), u(ui::kRailH)};
    l.zoom = {W - m - u(ui::kZoomW), H - m - u(ui::kZoomH), u(ui::kZoomW), u(ui::kZoomH)};
  }
  const f32 bw = u(72.f), bh = u(32.f), gap = u(8.f);
  const f32 pgap = u(8.f), ph = u(ui::kPickerH);
  const f32 top = l.portrait ? l.zoom.y : l.dock.y;  // the panel sits above the whole bottom stack
  l.picker = {l.dock.x, std::fmax(0.f, top - pgap - ph), u(ui::kPickerW), ph};
  l.picker_open = picker_;
  // MORE sits right above the zoom pill (thumb reach, out of the way of the top row); its menu opens above it
  l.more = {l.zoom.x + l.zoom.w - bw, l.zoom.y - gap - bh, bw, bh};
  l.menu = {l.zoom.x + l.zoom.w - u(ui::kMenuW), std::fmax(0.f, l.more.y - gap - u(ui::kMenuH)), u(ui::kMenuW), u(ui::kMenuH)};
  l.menu_open = menu_;
  l.lobby = {W - m - bw, m, bw, bh};
  l.redo = {l.lobby.x - gap - bw, m, bw, bh};
  l.undo = {l.redo.x - gap - bw, m, bw, bh};
  return l;
}

bool Editor::over_chrome(const Layout& l, f32 x, f32 y) {
  return contains(l.rail, x, y) || contains(l.dock, x, y) || contains(l.zoom, x, y) || contains(l.undo, x, y) ||
         contains(l.redo, x, y) || contains(l.lobby, x, y) || contains(l.more, x, y) ||
         (l.picker_open && contains(l.picker, x, y)) || (l.menu_open && contains(l.menu, x, y));
}

void Editor::draw_icon(ui::Ui& gui, Tool t, Vec2 c, f32 s, Color col) const {
  const f32 th = std::fmax(1.5f, s * 0.1f);
  switch (t) {
    case Tool::Select:  // cursor arrow
      gui.shape(theme::kTriangle, {c.x - s * 0.04f, c.y - s * 0.06f}, s * 0.92f, col, -0.55f);
      gui.bar({c.x + s * 0.22f, c.y + s * 0.3f}, s * 0.42f, th * 1.5f, -0.55f - 1.5708f + 0.62f, col);
      break;
    case Tool::Rotate: {  // circular arrow: a ring with an arrow head at the top right
      gui.shape(theme::kRing, c, s * 1.04f, col);
      gui.shape(theme::kTriangle, {c.x + s * 0.37f, c.y - s * 0.37f}, s * 0.42f, col, 2.356f);
      break;
    }
    case Tool::Move:  // four arrows
      gui.bar(c, s * 0.9f, th, 0.f, col);
      gui.bar(c, s * 0.9f, th, 1.5708f, col);
      for (int i = 0; i < 4; ++i) {
        const f32 ang = static_cast<f32>(i) * 1.5708f;
        gui.shape(theme::kTriangle, {c.x + std::sin(ang) * s * 0.46f, c.y - std::cos(ang) * s * 0.46f}, s * 0.34f, col, ang);
      }
      break;
    case Tool::Scale: {  // a box with a diagonal arrow growing out of it
      const f32 h = s * 0.6f;
      const Vec2 q{c.x - s * 0.1f, c.y + s * 0.1f};
      gui.bar({q.x, q.y - h * 0.5f}, h + th, th, 0.f, col);
      gui.bar({q.x, q.y + h * 0.5f}, h + th, th, 0.f, col);
      gui.bar({q.x - h * 0.5f, q.y}, h + th, th, 1.5708f, col);
      gui.bar({q.x + h * 0.5f, q.y}, h + th, th, 1.5708f, col);
      gui.bar({c.x + s * 0.2f, c.y - s * 0.2f}, s * 0.46f, th, -0.7854f, col);
      gui.shape(theme::kTriangle, {c.x + s * 0.42f, c.y - s * 0.42f}, s * 0.32f, col, 0.7854f);
      break;
    }
    case Tool::Hand: {  // open hand: four fingers, a palm and a thumb (pans the view)
      const f32 fw = s * 0.13f;
      for (int i = 0; i < 4; ++i) {
        const f32 x = c.x + (static_cast<f32>(i) - 1.5f) * s * 0.2f;
        const f32 len = (i == 1 || i == 2) ? s * 0.5f : s * 0.42f;
        gui.bar({x, c.y + s * 0.07f - len * 0.5f}, len, fw, 1.5708f, col);
      }
      gui.bar({c.x, c.y + s * 0.2f}, s * 0.72f, s * 0.34f, 0.f, col);
      gui.bar({c.x - s * 0.46f, c.y + s * 0.02f}, s * 0.34f, fw, 0.7f, col);
      break;
    }
    case Tool::Pen:  // pencil
      gui.bar({c.x + s * 0.1f, c.y - s * 0.1f}, s * 0.66f, s * 0.2f, -0.7854f, col);
      gui.shape(theme::kTriangle, {c.x - s * 0.32f, c.y + s * 0.32f}, s * 0.3f, col, 3.927f);
      break;
    case Tool::Line:
      gui.bar(c, s * 0.9f, th, -0.7854f, col);
      gui.shape(theme::kDisc, {c.x - s * 0.32f, c.y + s * 0.32f}, s * 0.26f, col);
      gui.shape(theme::kDisc, {c.x + s * 0.32f, c.y - s * 0.32f}, s * 0.26f, col);
      break;
    case Tool::Rect: {
      const f32 h = s * 0.72f;
      gui.bar({c.x, c.y - h * 0.5f}, h + th, th, 0.f, col);
      gui.bar({c.x, c.y + h * 0.5f}, h + th, th, 0.f, col);
      gui.bar({c.x - h * 0.5f, c.y}, h + th, th, 1.5708f, col);
      gui.bar({c.x + h * 0.5f, c.y}, h + th, th, 1.5708f, col);
      break;
    }
    case Tool::Ellipse:
      gui.shape(theme::kRing, c, s * 1.12f, col);
      break;
    case Tool::Eraser:
      gui.bar(c, s * 0.8f, s * 0.42f, -0.6f, col);
      gui.bar({c.x, c.y + s * 0.46f}, s * 0.9f, th, 0.f, col);
      break;
    default:
      break;
  }
}

bool Editor::chrome(ui::Ui& gui, const Layout& l, std::string_view hud) {
  const ui::Assets& a = gui.assets();
  const auto u = [&](f32 v) { return gui.u(v); };
  bool leave = false;

  // ---- tool rail ----
  if (l.portrait) gui.panel_turned(a.rail, l.rail.x, l.rail.y, kPanelFill, kPanelEdge);
  else gui.panel(a.rail, l.rail.x, l.rail.y, kPanelFill, kPanelEdge);
  constexpr int kPerLine = static_cast<int>(Tool::kCount) / 2;  // two lines: pick / transform / view, then draw
  static_assert(static_cast<int>(Tool::kCount) % 2 == 0);
  for (int i = 0; i < static_cast<int>(Tool::kCount); ++i) {
    const f32 along = static_cast<f32>(i % kPerLine) * u(48.f), across = static_cast<f32>(i / kPerLine) * u(48.f);
    const Rect r = l.portrait ? Rect{l.rail.x + u(8.f) + along, l.rail.y + u(6.f) + across, u(44.f), u(44.f)}
                              : Rect{l.rail.x + u(6.f) + across, l.rail.y + u(8.f) + along, u(44.f), u(44.f)};
    Color ink;
    if (gui.tool_button(kToolBase + static_cast<u32>(i), r, tool_ == static_cast<Tool>(i), ink)) set_tool(static_cast<Tool>(i));
    draw_icon(gui, static_cast<Tool>(i), {r.x + r.w * 0.5f, r.y + r.h * 0.5f}, u(21.f), ink);
  }

  // ---- color + brush dock ----
  gui.panel(a.dock, l.dock.x, l.dock.y, kPanelFill, kPanelEdge);
  const f32 cy = l.dock.y + l.dock.h * 0.5f;
  for (int i = 0; i < 7; ++i) {
    const Vec2 c{l.dock.x + u(22.f) + static_cast<f32>(i) * u(28.f), cy};
    if (gui.swatch(kSwatchBase + static_cast<u32>(i), c, u(19.f), kPalette[i], same_rgb(color_, kPalette[i]))) {
      color_ = kPalette[i];
      close_picker();
    }
  }
  {  // custom slot: a faint outer ring marks it; tap to open / close the HSV panel
    const Vec2 c{l.dock.x + u(218.f), cy};
    gui.shape(theme::kRing, c, u(27.f), Color{170, 176, 190, 110});
    if (gui.swatch(kSwatchBase + 7, c, u(19.f), custom_, picker_ || same_rgb(color_, custom_))) {
      color_ = custom_;
      if (picker_) close_picker();
      else { picker_ = true; menu_ = false; }  // one panel at a time
    }
  }
  gui.fill({l.dock.x + u(236.f), cy - u(11.f), std::fmax(1.f, std::round(gui.u(1.f))), u(22.f)}, Color{190, 196, 208, 40});
  const f32 dots[3] = {u(6.f), u(10.f), u(15.f)};
  for (int i = 0; i < 3; ++i) {
    const Rect hit{l.dock.x + u(248.f) + static_cast<f32>(i) * u(32.f), cy - u(18.f), u(28.f), u(36.f)};
    if (gui.size_dot(kSizeBase + static_cast<u32>(i), hit, dots[i], size_idx_ == i)) size_idx_ = i;
  }

  // ---- custom color panel (only built while open: costs nothing otherwise) ----
  if (picker_) {
    const Rect p = l.picker;
    gui.panel(a.picker, p.x, p.y, kPanelFill, kPanelEdge);
    const f32 r1 = p.y + u(24.f);
    gui.shape(theme::kDisc, {p.x + u(26.f), r1}, u(22.f), custom_);
    for (int i = 0; i < recent_n_; ++i) {
      const Vec2 c{p.x + u(72.f) + static_cast<f32>(i) * u(30.f), r1};
      if (gui.swatch(kRecentBase + static_cast<u32>(i), c, u(17.f), recent_[i], same_rgb(color_, recent_[i]))) {
        custom_ = color_ = recent_[i];
        rgb_to_hsv(custom_, hsv_);
      }
    }
    Color seg_h[18], seg_s[8], seg_v[8];
    for (int i = 0; i < 18; ++i) seg_h[i] = hsv_to_rgb((static_cast<f32>(i) + 0.5f) / 18.f, 1.f, 1.f);
    for (int i = 0; i < 8; ++i) {
      const f32 t = static_cast<f32>(i) / 7.f;
      seg_s[i] = hsv_to_rgb(hsv_[0], t, hsv_[2]);
      seg_v[i] = hsv_to_rgb(hsv_[0], hsv_[1], t);
    }
    const char* names[3] = {"HUE", "SAT", "VAL"};
    const f32 ink = a.label.font.pixel_height * 0.36f * gui.k();
    bool changed = false;
    for (int row = 0; row < 3; ++row) {
      const f32 rc = p.y + u(58.f) + static_cast<f32>(row) * u(28.f);
      gui.text(a.label, names[row], p.x + u(16.f), rc + ink, ui::Align::Left, 2.2f, kHudDim);
      const Rect r{p.x + u(76.f), rc - u(12.f), u(264.f), u(24.f)};
      if (row == 0) changed |= gui.strip(kHue, r, hsv_[0], seg_h, 18, hsv_to_rgb(hsv_[0], 1.f, 1.f));
      else if (row == 1) changed |= gui.strip(kSat, r, hsv_[1], seg_s, 8, custom_);
      else changed |= gui.strip(kVal, r, hsv_[2], seg_v, 8, custom_);
    }
    if (changed) {
      custom_ = color_ = hsv_to_rgb(hsv_[0], hsv_[1], hsv_[2]);
      custom_dirty_ = true;
    }
  }

  // ---- zoom pill ----
  gui.panel(a.zoom, l.zoom.x, l.zoom.y, kPanelFill, kPanelEdge);
  const f32 zw = u(36.f);
  if (gui.glyph_button(kZoomOut, {l.zoom.x + u(4.f), l.zoom.y + u(2.f), zw, l.zoom.h - u(4.f)}, "-"))
    zoom_by(1.f / 1.25f, W_ * 0.5f, H_ * 0.5f, W_, H_);
  if (gui.glyph_button(kZoomIn, {l.zoom.x + l.zoom.w - u(4.f) - zw, l.zoom.y + u(2.f), zw, l.zoom.h - u(4.f)}, "+"))
    zoom_by(1.25f, W_ * 0.5f, H_ * 0.5f, W_, H_);
  char pct[16];
  std::snprintf(pct, sizeof pct, "%d%%", static_cast<int>(std::lround(zoom_ * 100.f)));
  gui.text(a.label, pct, l.zoom.x + l.zoom.w * 0.5f, l.zoom.y + l.zoom.h * 0.5f + a.label.font.pixel_height * 0.36f * gui.k(),
           ui::Align::Center, 1.4f, Color{214, 220, 232, 255});

  // ---- MORE + action menu (the menu is only built while open) ----
  if (gui.mini_button(kMore, l.more, "MORE")) {
    menu_ = !menu_;
    if (menu_) close_picker();
  }
  if (menu_) {
    const Rect p = l.menu;
    gui.panel(a.menu, p.x, p.y, kPanelFill, kPanelEdge);
    const f32 bw = u(72.f), bh = u(32.f), gx = u(8.f), pad = u(10.f);
    struct Item { const char* label; bool enabled; };
    const bool has = !doc_.empty();
    const Item items[9] = {{"SAVE", has}, {"OPEN", true}, {"FIT", has},
                           {"COPY", selectable_action()}, {"FRONT", selectable_action()}, {"BACK", selectable_action()},
                           {"CODE", selectable_action()}, {"GRID", true}, {"HOME", true}};
    int picked = -1;
    for (int i = 0; i < 9; ++i) {
      const Rect r{p.x + pad + static_cast<f32>(i % 3) * (bw + gx), p.y + pad + static_cast<f32>(i / 3) * (bh + gx), bw, bh};
      if (gui.mini_button(kMenuBase + static_cast<u32>(i), r, items[i].label, items[i].enabled)) picked = i;
    }
    if (picked >= 0) {
      switch (picked) {
        case 0: request_ = Request::Save; break;
        case 1: request_ = Request::Open; break;
        case 2: zoom_to_fit(); break;
        case 3: duplicate_selection(); break;
        case 4: bring_to_front(); break;
        case 5: send_to_back(); break;
        case 6: open_code(); break;
        case 7: toggle_grid(); break;
        default: reset_view(); break;
      }
      menu_ = false;  // one tap, one action: the menu gets out of the way of the canvas
    }
  }

  // ---- top-right actions ----
  if (gui.mini_button(kUndo, l.undo, "UNDO", hist_.undo_steps() > 0)) undo();
  if (gui.mini_button(kRedo, l.redo, "REDO", hist_.redo_steps() > 0)) redo();
  if (gui.mini_button(kLobby, l.lobby, "LOBBY")) leave = true;

  // ---- status (tool name, optional stats) ----
  // Landscape: one line, "TOOL   /   stats". Portrait is too narrow for that: the tool name sits next to
  // the buttons and the stats get their own line below. Stack buffer: no heap allocation per frame.
  const char* name = status_ ? status_ : tool_name(tool_);
  const f32 base_y = l.undo.y + l.undo.h * 0.5f + a.label.font.pixel_height * 0.36f * gui.k();
  const f32 x = l.portrait ? u(14.f) : l.rail.x + u(4.f);  // portrait: left margin
  char line[200];
  if (l.portrait) {
    gui.text(a.label, name, x, base_y, ui::Align::Left, 2.6f, kHudDim);
    if (!hud.empty()) {
      std::snprintf(line, sizeof line, "%.*s", static_cast<int>(hud.size()), hud.data());
      gui.text(a.label, line, x, l.undo.y + l.undo.h + u(18.f), ui::Align::Left, 2.6f, kHudDim);
    }
  } else {
    if (hud.empty()) std::snprintf(line, sizeof line, "%s", name);
    else std::snprintf(line, sizeof line, "%s   /   %.*s", name, static_cast<int>(hud.size()), hud.data());
    gui.text(a.label, line, x, base_y, ui::Align::Left, 2.6f, kHudDim);
  }
  return leave;
}

bool Editor::code_ui(ui::Ui& gui, const CodeFrame& f) {
  const CodeResult r = code_.frame(gui, f);
  if (r == CodeResult::Apply) close_code(true);
  else if (r == CodeResult::Cancel) close_code(false);
  return code_.is_open();
}

}  // namespace nv
