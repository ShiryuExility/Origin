// Single translation unit that compiles the vendored stb_truetype implementation.
#define STB_TRUETYPE_IMPLEMENTATION
#include "third_party/stb_truetype.h"
