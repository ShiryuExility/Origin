#pragma once
// Bitmap font: rasterizes printable ASCII from a TTF/OTF once (stb_truetype), packs the glyphs
// with the texture atlas packer, and draws text as ordinary sprites through SpriteBatch.
// Bake at the *physical* pixel size (logical size * display density) for crisp text on phones.
#include <array>
#include <optional>
#include <span>
#include <string_view>

#include "render/atlas.hpp"
#include "render/sprite_batch.hpp"

namespace nv {

struct Glyph {
  Rect uv{};          // inside 0..1 of the font page
  QuantUv quv{};      // same rectangle, pre-converted for SpriteBatch::draw_quad
  f32 x_off = 0.f;    // offset of the bitmap's top-left from the pen position / baseline
  f32 y_off = 0.f;    // (y-down: negative = above the baseline)
  f32 w = 0.f, h = 0.f;
  f32 advance = 0.f;
  bool has_bitmap = false;  // false for space
};

struct BakedFont {
  static constexpr u32 kFirst = 32, kLast = 126;
  AtlasPage page;  // white RGBA, alpha = coverage; upload with create_texture(linear = true)
  std::array<Glyph, kLast - kFirst + 1> glyphs{};
  f32 pixel_height = 0.f;
  f32 ascent = 0.f, descent = 0.f, line_gap = 0.f;  // descent is negative

  [[nodiscard]] const Glyph& glyph(char c) const noexcept {
    const u32 u = static_cast<u8>(c);
    return glyphs[(u >= kFirst && u <= kLast) ? u - kFirst : '?' - kFirst];
  }
  [[nodiscard]] f32 line_height() const noexcept { return ascent - descent + line_gap; }
};

// Returns nullopt for unreadable font data.
[[nodiscard]] std::optional<BakedFont> bake_font(std::span<const u8> font_file, f32 pixel_height);

struct TextStyle {
  f32 tracking = 0.f;  // extra space between glyphs, in output pixels (caps look elegant with +)
  f32 scale = 1.f;     // 1 = baked size
  Color color{255, 255, 255, 255};
};

[[nodiscard]] f32 measure_text(const BakedFont& font, std::string_view text, const TextStyle& style = {});

// `baseline_left` is the pen start on the baseline. Glyph origins are snapped to whole pixels.
// Returns the width drawn. Stops silently when the batch is full.
f32 draw_text(SpriteBatch& batch, TextureId font_texture, const BakedFont& font, std::string_view text,
              Vec2 baseline_left, const TextStyle& style = {});

}  // namespace nv
