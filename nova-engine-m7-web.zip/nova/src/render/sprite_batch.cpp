#include "render/sprite_batch.hpp"

#include <algorithm>
#include <cmath>
#include <utility>

namespace nv {
namespace {
u16 quantize_uv(f32 v) noexcept {
  v = v < 0.f ? 0.f : (v > 1.f ? 1.f : v);
  return static_cast<u16>(v * 65535.0f + 0.5f);
}
}  // namespace

SpriteBatch::SpriteBatch(u32 max_sprites)
    : max_(std::min(max_sprites, kMaxSprites)),
      vertices_(std::make_unique_for_overwrite<SpriteVertex[]>(std::size_t{max_} * 4)) {  // no zero-fill: every slot is written before use
  runs_.reserve(256);
}

void SpriteBatch::clear() noexcept {
  count_ = 0;
  runs_.clear();
}

bool SpriteBatch::draw(const SpriteDesc& s) {
  if (count_ >= max_) return false;

  const f32 x0 = -s.pivot.x * s.size.x;
  const f32 y0 = -s.pivot.y * s.size.y;
  const f32 x1 = x0 + s.size.x;
  const f32 y1 = y0 + s.size.y;

  f32 sn = 0.f, cs = 1.f;
  if (s.rotation != 0.f) {
    sn = std::sin(s.rotation);
    cs = std::cos(s.rotation);
  }

  f32 u0 = s.uv.x, u1 = s.uv.x + s.uv.w;
  f32 v0 = s.uv.y, v1 = s.uv.y + s.uv.h;
  if (s.flip_x) std::swap(u0, u1);
  if (s.flip_y) std::swap(v0, v1);
  const u16 qu0 = quantize_uv(u0), qu1 = quantize_uv(u1);
  const u16 qv0 = quantize_uv(v0), qv1 = quantize_uv(v1);

  const auto px = [&](f32 lx, f32 ly) { return s.position.x + lx * cs - ly * sn; };
  const auto py = [&](f32 lx, f32 ly) { return s.position.y + lx * sn + ly * cs; };

  SpriteVertex* v = vertices_.get() + std::size_t{count_} * 4;
  v[0] = {px(x0, y0), py(x0, y0), qu0, qv0, s.color};  // top-left
  v[1] = {px(x1, y0), py(x1, y0), qu1, qv0, s.color};  // top-right
  v[2] = {px(x1, y1), py(x1, y1), qu1, qv1, s.color};  // bottom-right
  v[3] = {px(x0, y1), py(x0, y1), qu0, qv1, s.color};  // bottom-left
  push_run(s.texture);
  return true;
}

QuantUv SpriteBatch::quantize(const Rect& uv) noexcept {
  return {quantize_uv(uv.x), quantize_uv(uv.y), quantize_uv(uv.x + uv.w), quantize_uv(uv.y + uv.h)};
}

bool SpriteBatch::draw_quad(TextureId texture, Vec2 c, Vec2 size, const QuantUv& uv, Color color) {
  if (count_ >= max_) return false;
  const f32 hx = size.x * 0.5f, hy = size.y * 0.5f;
  const f32 x0 = c.x - hx, x1 = c.x + hx, y0 = c.y - hy, y1 = c.y + hy;
  SpriteVertex* v = vertices_.get() + std::size_t{count_} * 4;
  v[0] = {x0, y0, uv.u0, uv.v0, color};
  v[1] = {x1, y0, uv.u1, uv.v0, color};
  v[2] = {x1, y1, uv.u1, uv.v1, color};
  v[3] = {x0, y1, uv.u0, uv.v1, color};
  push_run(texture);
  return true;
}

bool SpriteBatch::draw_segment(TextureId texture, Vec2 p, Vec2 q, f32 thickness, const QuantUv& uv, Color color) {
  if (count_ >= max_) return false;
  const f32 dx = q.x - p.x, dy = q.y - p.y;
  const f32 len2 = dx * dx + dy * dy;
  // half-thickness normal; a zero-length segment falls back to rotation 0 like draw() does
  const f32 k = len2 > 0.f ? thickness * 0.5f / std::sqrt(len2) : 0.f;
  const f32 nx = len2 > 0.f ? -dy * k : 0.f, ny = len2 > 0.f ? dx * k : thickness * 0.5f;
  SpriteVertex* v = vertices_.get() + std::size_t{count_} * 4;
  v[0] = {p.x - nx, p.y - ny, uv.u0, uv.v0, color};
  v[1] = {q.x - nx, q.y - ny, uv.u1, uv.v0, color};
  v[2] = {q.x + nx, q.y + ny, uv.u1, uv.v1, color};
  v[3] = {p.x + nx, p.y + ny, uv.u0, uv.v1, color};
  push_run(texture);
  return true;
}

void SpriteBatch::push_run(TextureId texture) {
  if (!runs_.empty() && runs_.back().texture == texture) {
    ++runs_.back().count;
  } else {
    runs_.push_back({texture, count_, 1});
  }
  ++count_;
}

}  // namespace nv
