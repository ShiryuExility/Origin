#include "render/font.hpp"

#include <cmath>
#include <vector>

#include "third_party/stb_truetype.h"

namespace nv {

std::optional<BakedFont> bake_font(std::span<const u8> font_file, f32 pixel_height) {
  stbtt_fontinfo info;
  if (font_file.empty() || pixel_height < 4.f) return std::nullopt;
  const int off = stbtt_GetFontOffsetForIndex(font_file.data(), 0);
  if (off < 0 || !stbtt_InitFont(&info, font_file.data(), off)) return std::nullopt;

  BakedFont out;
  out.pixel_height = pixel_height;
  const f32 scale = stbtt_ScaleForPixelHeight(&info, pixel_height);
  int asc = 0, desc = 0, gap = 0;
  stbtt_GetFontVMetrics(&info, &asc, &desc, &gap);
  out.ascent = static_cast<f32>(asc) * scale;
  out.descent = static_cast<f32>(desc) * scale;
  out.line_gap = static_cast<f32>(gap) * scale;

  constexpr u32 kCount = BakedFont::kLast - BakedFont::kFirst + 1;
  std::vector<std::vector<u8>> bitmaps(kCount);
  std::vector<AtlasImage> images(kCount);
  std::array<int, kCount> bx{}, by{};

  for (u32 i = 0; i < kCount; ++i) {
    const int cp = static_cast<int>(BakedFont::kFirst + i);
    int adv = 0, lsb = 0;
    stbtt_GetCodepointHMetrics(&info, cp, &adv, &lsb);
    Glyph& g = out.glyphs[i];
    g.advance = static_cast<f32>(adv) * scale;

    int x0, y0, x1, y1;
    stbtt_GetCodepointBitmapBox(&info, cp, scale, scale, &x0, &y0, &x1, &y1);
    const int w = x1 - x0, h = y1 - y0;
    if (w <= 0 || h <= 0) continue;  // space etc.
    std::vector<u8> cov(std::size_t(w) * h);
    stbtt_MakeCodepointBitmap(&info, cov.data(), w, h, w, scale, scale, cp);
    bitmaps[i].resize(cov.size() * 4);
    for (std::size_t p = 0; p < cov.size(); ++p) {  // white, alpha = coverage
      bitmaps[i][p * 4 + 0] = bitmaps[i][p * 4 + 1] = bitmaps[i][p * 4 + 2] = 255;
      bitmaps[i][p * 4 + 3] = cov[p];
    }
    images[i] = {static_cast<u32>(w), static_cast<u32>(h), bitmaps[i].data()};
    bx[i] = x0;
    by[i] = y0;
    g.has_bitmap = true;
  }

  AtlasConfig cfg;
  cfg.max_page_size = 2048;
  cfg.padding = 1;
  Atlas atlas = build_atlas(images, cfg);
  if (atlas.pages.size() != 1) return std::nullopt;  // does not fit one page: size too large
  out.page = std::move(atlas.pages[0]);

  for (u32 i = 0; i < kCount; ++i) {
    Glyph& g = out.glyphs[i];
    if (!g.has_bitmap) continue;
    g.uv = atlas.uv(i);
    g.quv = SpriteBatch::quantize(g.uv);
    g.x_off = static_cast<f32>(bx[i]);
    g.y_off = static_cast<f32>(by[i]);
    g.w = static_cast<f32>(images[i].width);
    g.h = static_cast<f32>(images[i].height);
  }
  return out;
}

f32 measure_text(const BakedFont& font, std::string_view text, const TextStyle& style) {
  f32 w = 0.f;
  for (const char c : text) w += font.glyph(c).advance * style.scale + style.tracking;
  return text.empty() ? 0.f : w - style.tracking;  // no trailing tracking
}

f32 draw_text(SpriteBatch& batch, TextureId tex, const BakedFont& font, std::string_view text,
              Vec2 baseline_left, const TextStyle& style) {
  f32 pen = baseline_left.x;
  for (const char c : text) {
    const Glyph& g = font.glyph(c);
    if (g.has_bitmap) {
      const f32 w = g.w * style.scale, h = g.h * style.scale;
      const f32 x = std::round(pen + g.x_off * style.scale), y = std::round(baseline_left.y + g.y_off * style.scale);
      if (!batch.draw_quad(tex, {x + w * 0.5f, y + h * 0.5f}, {w, h}, g.quv, style.color)) break;
    }
    pen += g.advance * style.scale + style.tracking;
  }
  return pen - baseline_left.x - (text.empty() ? 0.f : style.tracking);
}

}  // namespace nv
