#include "render/atlas.hpp"

#include <algorithm>
#include <cstring>
#include <numeric>

namespace nv {

// ---- MaxRectsPacker ---------------------------------------------------------------

MaxRectsPacker::MaxRectsPacker(u32 bin_w, u32 bin_h) : bin_w_(bin_w), bin_h_(bin_h) {
  if (bin_w_ && bin_h_) free_.push_back({0, 0, bin_w_, bin_h_});
}

bool MaxRectsPacker::insert(u32 w, u32 h, PackedRect& out) {
  if (w == 0 || h == 0) return false;

  // Best short side fit: smallest leftover on the tighter axis, then on the other axis.
  const FreeRect* best = nullptr;
  u32 best_short = ~0u, best_long = ~0u;
  for (const FreeRect& f : free_) {
    if (f.w < w || f.h < h) continue;
    const u32 lw = f.w - w, lh = f.h - h;
    const u32 s = std::min(lw, lh), l = std::max(lw, lh);
    if (s < best_short || (s == best_short && l < best_long)) {
      best = &f;
      best_short = s;
      best_long = l;
    }
  }
  if (!best) return false;

  out = {best->x, best->y};
  split_and_prune(out.x, out.y, w, h);
  used_area_ += u64{w} * h;
  return true;
}

void MaxRectsPacker::split_and_prune(u32 x, u32 y, u32 w, u32 h) {
  const u32 x2 = x + w, y2 = y + h;
  const std::size_t original = free_.size();
  for (std::size_t i = 0; i < original; ++i) {
    const FreeRect f = free_[i];  // copy: push_back below may reallocate
    const u32 fx2 = f.x + f.w, fy2 = f.y + f.h;
    if (x >= fx2 || x2 <= f.x || y >= fy2 || y2 <= f.y) continue;  // no overlap: keep as is

    // Mark for removal (w == 0), then add the leftover slices.
    free_[i].w = 0;
    if (x > f.x) free_.push_back({f.x, f.y, x - f.x, f.h});            // left
    if (x2 < fx2) free_.push_back({x2, f.y, fx2 - x2, f.h});           // right
    if (y > f.y) free_.push_back({f.x, f.y, f.w, y - f.y});            // top
    if (y2 < fy2) free_.push_back({f.x, y2, f.w, fy2 - y2});          // bottom
  }
  std::erase_if(free_, [](const FreeRect& f) { return f.w == 0 || f.h == 0; });

  // Drop free rects fully contained in another one.
  for (std::size_t i = 0; i < free_.size(); ++i) {
    for (std::size_t j = i + 1; j < free_.size();) {
      const FreeRect &a = free_[i], &b = free_[j];
      const auto inside = [](const FreeRect& in, const FreeRect& out) {
        return in.x >= out.x && in.y >= out.y && in.x + in.w <= out.x + out.w &&
               in.y + in.h <= out.y + out.h;
      };
      if (inside(b, a)) {
        free_[j] = free_.back();
        free_.pop_back();
      } else if (inside(a, b)) {
        free_[i] = free_[j];
        free_[j] = free_.back();
        free_.pop_back();
        j = i + 1;  // free_[i] changed: rescan against the new occupant
      } else {
        ++j;
      }
    }
  }
}

f32 MaxRectsPacker::occupancy() const noexcept {
  const u64 total = u64{bin_w_} * bin_h_;
  return total ? static_cast<f32>(static_cast<double>(used_area_) / static_cast<double>(total)) : 0.f;
}

// ---- Atlas ------------------------------------------------------------------------

Rect Atlas::uv(u32 image_index) const noexcept {
  if (image_index >= regions.size()) return {};
  const AtlasRegion& r = regions[image_index];
  if (!r.valid()) return {};
  const AtlasPage& p = pages[r.page];
  const f32 iw = 1.f / static_cast<f32>(p.width), ih = 1.f / static_cast<f32>(p.height);
  return {static_cast<f32>(r.x) * iw, static_cast<f32>(r.y) * ih, static_cast<f32>(r.w) * iw,
          static_cast<f32>(r.h) * ih};
}

bool Atlas::all_placed() const noexcept {
  return std::all_of(regions.begin(), regions.end(), [](const AtlasRegion& r) { return r.valid(); });
}

namespace {

u32 next_pow2(u32 v) noexcept {
  u32 p = 1;
  while (p < v && p < 0x80000000u) p <<= 1;
  return p;
}

struct PageBuild {
  MaxRectsPacker packer;
  std::vector<u32> members;  // input image indices
  u32 used_w = 0, used_h = 0;
};

// Fills the padded slot whose top-left corner is (slot_x, slot_y): the image in the middle,
// its edge pixels replicated `pad` pixels outward on every side (corners included).
void blit_with_extrusion(AtlasPage& page, const AtlasImage& img, u32 slot_x, u32 slot_y, u32 pad) {
  const i32 w = static_cast<i32>(img.width), h = static_cast<i32>(img.height);
  const i32 ip = static_cast<i32>(pad);
  for (i32 row = 0; row < h + 2 * ip; ++row) {
    const i32 sy = std::clamp(row - ip, 0, h - 1);
    u8* dst = page.rgba.data() + (std::size_t{slot_y + static_cast<u32>(row)} * page.width + slot_x) * 4;
    const u8* src = img.rgba + std::size_t{static_cast<u32>(sy)} * img.width * 4;
    for (i32 col = 0; col < w + 2 * ip; ++col) {
      const i32 sx = std::clamp(col - ip, 0, w - 1);
      std::memcpy(dst + std::size_t{static_cast<u32>(col)} * 4, src + std::size_t{static_cast<u32>(sx)} * 4, 4);
    }
  }
}

}  // namespace

Atlas build_atlas(std::span<const AtlasImage> images, const AtlasConfig& cfg) {
  Atlas atlas;
  atlas.regions.assign(images.size(), AtlasRegion{});

  const u32 pad = cfg.padding;
  const u32 max_size = std::max<u32>(cfg.max_page_size, 1);

  // Slot = image + padding on every side. Skip anything unusable or larger than a page.
  const auto slot_w = [&](const AtlasImage& i) { return u64{i.width} + 2ull * pad; };
  const auto slot_h = [&](const AtlasImage& i) { return u64{i.height} + 2ull * pad; };
  std::vector<u32> order;
  order.reserve(images.size());
  for (u32 i = 0; i < images.size(); ++i) {
    const AtlasImage& im = images[i];
    if (!im.rgba || im.width == 0 || im.height == 0) continue;
    if (slot_w(im) > max_size || slot_h(im) > max_size) continue;
    order.push_back(i);
  }

  // Big first packs tighter; the index tie-break keeps the result deterministic.
  std::sort(order.begin(), order.end(), [&](u32 a, u32 b) {
    const AtlasImage &ia = images[a], &ib = images[b];
    const u32 ma = std::max(ia.width, ia.height), mb = std::max(ib.width, ib.height);
    if (ma != mb) return ma > mb;
    const u64 aa = u64{ia.width} * ia.height, ab = u64{ib.width} * ib.height;
    if (aa != ab) return aa > ab;
    return a < b;
  });

  std::vector<PageBuild> builds;
  for (const u32 idx : order) {
    const AtlasImage& im = images[idx];
    const u32 sw = static_cast<u32>(slot_w(im)), sh = static_cast<u32>(slot_h(im));

    PackedRect at;
    PageBuild* target = nullptr;
    for (PageBuild& pb : builds) {
      if (pb.packer.insert(sw, sh, at)) {
        target = &pb;
        break;
      }
    }
    if (!target) {  // a fresh page always fits it: size was checked above
      builds.push_back({MaxRectsPacker(max_size, max_size), {}, 0, 0});
      target = &builds.back();
      const bool ok = target->packer.insert(sw, sh, at);
      (void)ok;
    }
    target->members.push_back(idx);
    target->used_w = std::max(target->used_w, at.x + sw);
    target->used_h = std::max(target->used_h, at.y + sh);
    atlas.regions[idx] = {static_cast<u32>(&*target - builds.data()), at.x + pad, at.y + pad, im.width, im.height};
  }

  // Materialize pages: tight size, transparent black background, then blit.
  atlas.pages.resize(builds.size());
  for (std::size_t p = 0; p < builds.size(); ++p) {
    const PageBuild& pb = builds[p];
    AtlasPage& page = atlas.pages[p];
    page.width = cfg.pow2_pages ? std::min(next_pow2(pb.used_w), max_size) : pb.used_w;
    page.height = cfg.pow2_pages ? std::min(next_pow2(pb.used_h), max_size) : pb.used_h;
    page.rgba.assign(std::size_t{page.width} * page.height * 4, 0);
    for (const u32 idx : pb.members) {
      const AtlasRegion& r = atlas.regions[idx];
      blit_with_extrusion(page, images[idx], r.x - pad, r.y - pad, pad);
    }
  }
  return atlas;
}

}  // namespace nv
