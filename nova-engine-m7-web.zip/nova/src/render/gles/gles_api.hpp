#pragma once
// Tiny hand-rolled OpenGL ES 3.0 surface, loaded at runtime through
// SDL_GL_GetProcAddress. No glad/GLEW, no Khronos headers, same code on
// Android and desktop (Mesa/NVIDIA/AMD expose ES contexts too).
// Browser (Emscripten) build: the same calls are WebGL 2, and Emscripten's GL library provides them as
// ordinary link-time symbols, so they are declared extern "C" below instead of looked up at runtime.
#include <cstddef>

#if defined(_WIN32) && !defined(APIENTRY)
#define APIENTRY __stdcall
#elif !defined(APIENTRY)
#define APIENTRY
#endif

namespace nv::gles {

using GLenum = unsigned int;
using GLbitfield = unsigned int;
using GLuint = unsigned int;
using GLint = int;
using GLsizei = int;
using GLboolean = unsigned char;
using GLfloat = float;
using GLchar = char;
using GLsizeiptr = std::ptrdiff_t;

inline constexpr GLenum GL_COLOR_BUFFER_BIT = 0x4000;
inline constexpr GLenum GL_TRIANGLES = 0x0004;
inline constexpr GLenum GL_UNSIGNED_BYTE = 0x1401;
inline constexpr GLenum GL_UNSIGNED_SHORT = 0x1403;
inline constexpr GLenum GL_FLOAT = 0x1406;
inline constexpr GLenum GL_RGBA = 0x1908;
inline constexpr GLenum GL_RGBA8 = 0x8058;
inline constexpr GLenum GL_NEAREST = 0x2600;
inline constexpr GLenum GL_LINEAR = 0x2601;
inline constexpr GLenum GL_TEXTURE_MAG_FILTER = 0x2800;
inline constexpr GLenum GL_TEXTURE_MIN_FILTER = 0x2801;
inline constexpr GLenum GL_TEXTURE_WRAP_S = 0x2802;
inline constexpr GLenum GL_TEXTURE_WRAP_T = 0x2803;
inline constexpr GLenum GL_CLAMP_TO_EDGE = 0x812F;
inline constexpr GLenum GL_TEXTURE_2D = 0x0DE1;
inline constexpr GLenum GL_TEXTURE0 = 0x84C0;
inline constexpr GLenum GL_BLEND = 0x0BE2;
inline constexpr GLenum GL_DEPTH_TEST = 0x0B71;
inline constexpr GLenum GL_CULL_FACE = 0x0B44;
inline constexpr GLenum GL_ONE = 1;
inline constexpr GLenum GL_SRC_ALPHA = 0x0302;
inline constexpr GLenum GL_ONE_MINUS_SRC_ALPHA = 0x0303;
inline constexpr GLenum GL_ARRAY_BUFFER = 0x8892;
inline constexpr GLenum GL_ELEMENT_ARRAY_BUFFER = 0x8893;
inline constexpr GLenum GL_STREAM_DRAW = 0x88E0;
inline constexpr GLenum GL_STATIC_DRAW = 0x88E4;
inline constexpr GLenum GL_FRAGMENT_SHADER = 0x8B30;
inline constexpr GLenum GL_VERTEX_SHADER = 0x8B31;
inline constexpr GLenum GL_COMPILE_STATUS = 0x8B81;
inline constexpr GLenum GL_LINK_STATUS = 0x8B82;
inline constexpr GLboolean GL_TRUE = 1;
inline constexpr GLboolean GL_FALSE = 0;

// X(return type, name without "gl", (args))
#define NV_GLES_FUNCS(X)                                                                     \
  X(void, ClearColor, (GLfloat, GLfloat, GLfloat, GLfloat))                                  \
  X(void, Clear, (GLbitfield))                                                               \
  X(void, Viewport, (GLint, GLint, GLsizei, GLsizei))                                        \
  X(void, Enable, (GLenum))                                                                  \
  X(void, Disable, (GLenum))                                                                 \
  X(void, BlendFuncSeparate, (GLenum, GLenum, GLenum, GLenum))                               \
  X(GLuint, CreateShader, (GLenum))                                                          \
  X(void, ShaderSource, (GLuint, GLsizei, const GLchar* const*, const GLint*))               \
  X(void, CompileShader, (GLuint))                                                           \
  X(void, GetShaderiv, (GLuint, GLenum, GLint*))                                             \
  X(void, GetShaderInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*))                            \
  X(void, DeleteShader, (GLuint))                                                            \
  X(GLuint, CreateProgram, ())                                                               \
  X(void, AttachShader, (GLuint, GLuint))                                                    \
  X(void, LinkProgram, (GLuint))                                                             \
  X(void, GetProgramiv, (GLuint, GLenum, GLint*))                                            \
  X(void, GetProgramInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*))                           \
  X(void, DeleteProgram, (GLuint))                                                           \
  X(void, UseProgram, (GLuint))                                                              \
  X(GLint, GetUniformLocation, (GLuint, const GLchar*))                                      \
  X(void, Uniform1i, (GLint, GLint))                                                         \
  X(void, Uniform4f, (GLint, GLfloat, GLfloat, GLfloat, GLfloat))                            \
  X(void, GenBuffers, (GLsizei, GLuint*))                                                    \
  X(void, BindBuffer, (GLenum, GLuint))                                                      \
  X(void, BufferData, (GLenum, GLsizeiptr, const void*, GLenum))                             \
  X(void, DeleteBuffers, (GLsizei, const GLuint*))                                           \
  X(void, GenVertexArrays, (GLsizei, GLuint*))                                               \
  X(void, BindVertexArray, (GLuint))                                                         \
  X(void, DeleteVertexArrays, (GLsizei, const GLuint*))                                      \
  X(void, EnableVertexAttribArray, (GLuint))                                                 \
  X(void, VertexAttribPointer, (GLuint, GLint, GLenum, GLboolean, GLsizei, const void*))     \
  X(void, DrawElements, (GLenum, GLsizei, GLenum, const void*))                              \
  X(void, GenTextures, (GLsizei, GLuint*))                                                   \
  X(void, BindTexture, (GLenum, GLuint))                                                     \
  X(void, ActiveTexture, (GLenum))                                                           \
  X(void, TexImage2D, (GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*)) \
  X(void, TexParameteri, (GLenum, GLenum, GLint))                                            \
  X(void, DeleteTextures, (GLsizei, const GLuint*))

#if defined(__EMSCRIPTEN__)
extern "C" {
#define X(ret, name, args) ret gl##name args;
NV_GLES_FUNCS(X)
#undef X
}
#endif

struct Functions {
#define X(ret, name, args) ret(APIENTRY* name) args = nullptr;
  NV_GLES_FUNCS(X)
#undef X
};

}  // namespace nv::gles
