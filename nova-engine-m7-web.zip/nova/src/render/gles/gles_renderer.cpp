#include "render/gles/gles_renderer.hpp"

#include <SDL3/SDL.h>

#include <cstdint>
#include <vector>

#include "render/gles/gles_api.hpp"

namespace nv {
namespace {

using namespace gles;

constexpr const char* kVertexShader = R"(#version 300 es
layout(location = 0) in vec2 a_pos;
layout(location = 1) in vec2 a_uv;
layout(location = 2) in vec4 a_color;
uniform vec4 u_view;  // xy = scale, zw = offset
out highp vec2 v_uv;
out lowp vec4 v_color;
void main() {
  gl_Position = vec4(a_pos * u_view.xy + u_view.zw, 0.0, 1.0);
  v_uv = a_uv;
  v_color = a_color;
}
)";

constexpr const char* kFragmentShader = R"(#version 300 es
precision mediump float;
in highp vec2 v_uv;   // atlas pages are up to 2048 wide: texture coordinates need the precision
in lowp vec4 v_color;
uniform lowp sampler2D u_tex;
out lowp vec4 o_color;
void main() {
  // Flat colors only (no gradients), so no banding to dither away: one fetch and one multiply.
  o_color = texture(u_tex, v_uv) * v_color;
}
)";

class GlesRenderer final : public IRenderer {
 public:
  GlesRenderer(SDL_Window* window, u32 max_sprites) : window_(window), max_sprites_(max_sprites) {}
  ~GlesRenderer() override { shutdown(); }

  bool init() {
    ctx_ = SDL_GL_CreateContext(window_);
    if (!ctx_) {
      SDL_Log("GLES: cannot create context: %s", SDL_GetError());
      return false;
    }
    SDL_GL_MakeCurrent(window_, ctx_);
    SDL_GL_SetSwapInterval(1);
    if (!load_functions() || !build_program()) return false;
    build_buffers();

    int w = 0, h = 0;
    SDL_GetWindowSizeInPixels(window_, &w, &h);
    width_ = static_cast<u32>(w);
    height_ = static_cast<u32>(h);

    gl_.Disable(GL_DEPTH_TEST);
    gl_.Disable(GL_CULL_FACE);
    gl_.Enable(GL_BLEND);
    // Alpha channel: src + dst * (1 - src). Plain (SRC_ALPHA, ONE_MINUS_SRC_ALPHA) would also square the source
    // alpha into the framebuffer alpha, which a browser canvas (alpha is composited with the page) shows as a
    // see-through screen after the fade quad. Desktop and Android windows ignore destination alpha.
    gl_.BlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
    textures_.push_back(0);  // slot 0 = invalid id
    return true;
  }

  [[nodiscard]] Backend backend() const noexcept override { return Backend::GLES; }

  void resize(u32 w, u32 h) override {
    width_ = w;
    height_ = h;
  }

  TextureId create_texture(u32 w, u32 h, const void* rgba8, bool linear) override {
    GLuint tex = 0;
    gl_.GenTextures(1, &tex);
    gl_.BindTexture(GL_TEXTURE_2D, tex);
    gl_.TexImage2D(GL_TEXTURE_2D, 0, static_cast<GLint>(GL_RGBA8), static_cast<GLsizei>(w),
                   static_cast<GLsizei>(h), 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba8);
    const GLint filter = static_cast<GLint>(linear ? GL_LINEAR : GL_NEAREST);
    gl_.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter);
    gl_.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter);
    gl_.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, static_cast<GLint>(GL_CLAMP_TO_EDGE));
    gl_.TexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, static_cast<GLint>(GL_CLAMP_TO_EDGE));

    if (!free_ids_.empty()) {
      const TextureId id = free_ids_.back();
      free_ids_.pop_back();
      textures_[id] = tex;
      return id;
    }
    textures_.push_back(tex);
    return static_cast<TextureId>(textures_.size() - 1);
  }

  void destroy_texture(TextureId id) override {
    if (id == 0 || id >= textures_.size() || textures_[id] == 0) return;
    gl_.DeleteTextures(1, &textures_[id]);
    textures_[id] = 0;
    free_ids_.push_back(id);
  }

  void begin_frame(Color c) override {
    gl_.Viewport(0, 0, static_cast<GLsizei>(width_), static_cast<GLsizei>(height_));
    gl_.ClearColor(c.r / 255.f, c.g / 255.f, c.b / 255.f, c.a / 255.f);
    gl_.Clear(GL_COLOR_BUFFER_BIT);
  }

  void draw(const SpriteBatch& batch, const Camera2D& camera) override {
    if (batch.sprite_count() == 0) return;
    SDL_assert(batch.capacity() <= max_sprites_);

    gl_.UseProgram(program_);
    const auto v = camera.view_params(width_, height_);
    gl_.Uniform4f(u_view_, v[0], v[1], v[2], v[3]);
    gl_.ActiveTexture(GL_TEXTURE0);

    gl_.BindVertexArray(vao_);
    gl_.BindBuffer(GL_ARRAY_BUFFER, vbo_);
    const auto verts = batch.vertices();
    // Re-specifying the store each draw "orphans" the old one, which avoids
    // stalling on a buffer the GPU is still reading (important on tilers).
    gl_.BufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(verts.size_bytes()), verts.data(),
                   GL_STREAM_DRAW);

    for (const SpriteRun& run : batch.runs()) {
      const GLuint tex = run.texture < textures_.size() ? textures_[run.texture] : 0;
      gl_.BindTexture(GL_TEXTURE_2D, tex);
      const auto offset = static_cast<std::uintptr_t>(run.first) * 6u * sizeof(u16);
      gl_.DrawElements(GL_TRIANGLES, static_cast<GLsizei>(run.count * 6), GL_UNSIGNED_SHORT,
                       reinterpret_cast<const void*>(offset));
    }
  }

  void end_frame() override { SDL_GL_SwapWindow(window_); }

 private:
  bool load_functions() {
#if defined(__EMSCRIPTEN__)
#define X(ret, name, args) gl_.name = &gl##name;
    NV_GLES_FUNCS(X)
#undef X
    return true;
#else
#define X(ret, name, args)                                                              \
  gl_.name = reinterpret_cast<ret(APIENTRY*) args>(SDL_GL_GetProcAddress("gl" #name)); \
  if (!gl_.name) {                                                                      \
    SDL_Log("GLES: missing function gl" #name);                                         \
    return false;                                                                       \
  }
    NV_GLES_FUNCS(X)
#undef X
    return true;
#endif
  }

  GLuint compile(GLenum type, const char* src) {
    const GLuint s = gl_.CreateShader(type);
    gl_.ShaderSource(s, 1, &src, nullptr);
    gl_.CompileShader(s);
    GLint ok = 0;
    gl_.GetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
      char log[1024];
      gl_.GetShaderInfoLog(s, sizeof log, nullptr, log);
      SDL_Log("GLES: shader compile failed: %s", log);
      gl_.DeleteShader(s);
      return 0;
    }
    return s;
  }

  bool build_program() {
    const GLuint vs = compile(GL_VERTEX_SHADER, kVertexShader);
    const GLuint fs = compile(GL_FRAGMENT_SHADER, kFragmentShader);
    if (!vs || !fs) return false;
    program_ = gl_.CreateProgram();
    gl_.AttachShader(program_, vs);
    gl_.AttachShader(program_, fs);
    gl_.LinkProgram(program_);
    gl_.DeleteShader(vs);
    gl_.DeleteShader(fs);
    GLint ok = 0;
    gl_.GetProgramiv(program_, GL_LINK_STATUS, &ok);
    if (!ok) {
      char log[1024];
      gl_.GetProgramInfoLog(program_, sizeof log, nullptr, log);
      SDL_Log("GLES: program link failed: %s", log);
      return false;
    }
    u_view_ = gl_.GetUniformLocation(program_, "u_view");
    gl_.UseProgram(program_);
    gl_.Uniform1i(gl_.GetUniformLocation(program_, "u_tex"), 0);
    return true;
  }

  void build_buffers() {
    // Static index buffer shared by every sprite: (0,1,2)(2,3,0) + 4*i.
    std::vector<u16> indices(std::size_t{max_sprites_} * 6);
    for (u32 i = 0; i < max_sprites_; ++i) {
      const u16 b = static_cast<u16>(i * 4);
      u16* p = &indices[std::size_t{i} * 6];
      p[0] = b;
      p[1] = static_cast<u16>(b + 1);
      p[2] = static_cast<u16>(b + 2);
      p[3] = static_cast<u16>(b + 2);
      p[4] = static_cast<u16>(b + 3);
      p[5] = b;
    }

    gl_.GenVertexArrays(1, &vao_);
    gl_.BindVertexArray(vao_);

    gl_.GenBuffers(1, &vbo_);
    gl_.BindBuffer(GL_ARRAY_BUFFER, vbo_);
    gl_.BufferData(GL_ARRAY_BUFFER,
                   static_cast<GLsizeiptr>(std::size_t{max_sprites_} * 4 * sizeof(SpriteVertex)),
                   nullptr, GL_STREAM_DRAW);

    gl_.GenBuffers(1, &ibo_);
    gl_.BindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo_);  // captured by the VAO
    gl_.BufferData(GL_ELEMENT_ARRAY_BUFFER,
                   static_cast<GLsizeiptr>(indices.size() * sizeof(u16)), indices.data(),
                   GL_STATIC_DRAW);

    constexpr GLsizei stride = sizeof(SpriteVertex);
    gl_.EnableVertexAttribArray(0);
    gl_.VertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride,
                            reinterpret_cast<const void*>(offsetof(SpriteVertex, x)));
    gl_.EnableVertexAttribArray(1);
    gl_.VertexAttribPointer(1, 2, GL_UNSIGNED_SHORT, GL_TRUE, stride,
                            reinterpret_cast<const void*>(offsetof(SpriteVertex, u)));
    gl_.EnableVertexAttribArray(2);
    gl_.VertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, stride,
                            reinterpret_cast<const void*>(offsetof(SpriteVertex, c)));
  }

  void shutdown() {
    if (!ctx_) return;
    SDL_GL_MakeCurrent(window_, ctx_);
    for (std::size_t i = 1; i < textures_.size(); ++i) {
      if (textures_[i]) gl_.DeleteTextures(1, &textures_[i]);
    }
    if (vao_) gl_.DeleteVertexArrays(1, &vao_);
    if (vbo_) gl_.DeleteBuffers(1, &vbo_);
    if (ibo_) gl_.DeleteBuffers(1, &ibo_);
    if (program_) gl_.DeleteProgram(program_);
    SDL_GL_DestroyContext(ctx_);
    ctx_ = nullptr;
  }

  SDL_Window* window_;
  SDL_GLContext ctx_ = nullptr;
  u32 max_sprites_;
  u32 width_ = 0, height_ = 0;
  Functions gl_{};
  GLuint program_ = 0, vao_ = 0, vbo_ = 0, ibo_ = 0;
  GLint u_view_ = -1;
  std::vector<GLuint> textures_;
  std::vector<TextureId> free_ids_;
};

}  // namespace

std::unique_ptr<IRenderer> make_gles_renderer(SDL_Window* window, u32 max_sprites) {
  auto r = std::make_unique<GlesRenderer>(window, max_sprites);
  if (!r->init()) return nullptr;
  return r;
}

}  // namespace nv
