#pragma once
#include <memory>

#include "render/renderer.hpp"

namespace nv {
std::unique_ptr<IRenderer> make_gles_renderer(SDL_Window* window, u32 max_sprites);
}
