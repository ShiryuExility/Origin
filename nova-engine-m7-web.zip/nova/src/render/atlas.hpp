#pragma once
// Texture atlas packer. CPU-only, no dependencies, no GPU calls: it takes RGBA8 images,
// packs them into one or more pages (MaxRects, best-short-side-fit) and returns the page
// pixels plus a region per input image. Upload each page with IRenderer::create_texture;
// every page is one TextureId, so sprites from the same page share a draw call.
//
// Bleeding: each image gets `padding` pixels of edge extrusion on all sides, so linear
// filtering and tiny camera offsets never sample a neighbour. Regions exclude the padding.
#include <span>
#include <vector>

#include "core/types.hpp"

namespace nv {

// ---- raw rectangle packer ---------------------------------------------------------
struct PackedRect {
  u32 x = 0, y = 0;
};

// Packs rectangles into one fixed-size bin. No rotation (SpriteBatch has no rotated UVs).
class MaxRectsPacker {
 public:
  MaxRectsPacker(u32 bin_w, u32 bin_h);

  // Places a w*h rectangle. Returns false when it does not fit (state is unchanged).
  [[nodiscard]] bool insert(u32 w, u32 h, PackedRect& out);

  [[nodiscard]] u32 width() const noexcept { return bin_w_; }
  [[nodiscard]] u32 height() const noexcept { return bin_h_; }
  // Used / bin area, 0..1.
  [[nodiscard]] f32 occupancy() const noexcept;

 private:
  struct FreeRect {
    u32 x, y, w, h;
  };
  void split_and_prune(u32 x, u32 y, u32 w, u32 h);

  u32 bin_w_, bin_h_;
  u64 used_area_ = 0;
  std::vector<FreeRect> free_;
};

// ---- atlas builder ----------------------------------------------------------------
struct AtlasImage {
  u32 width = 0, height = 0;
  const u8* rgba = nullptr;  // width*height*4 bytes, tightly packed, top row first
};

struct AtlasConfig {
  u32 max_page_size = 2048;  // phones: 2048 is safe everywhere, 4096 on most
  u32 padding = 1;           // extruded border per image, in pixels
  bool pow2_pages = true;    // round each page up to a power of two (capped at max_page_size)
};

inline constexpr u32 kInvalidPage = ~0u;

struct AtlasRegion {
  u32 page = kInvalidPage;  // kInvalidPage: image was empty, null or too big for a page
  u32 x = 0, y = 0, w = 0, h = 0;  // pixel rect of the image itself (padding excluded)

  [[nodiscard]] bool valid() const noexcept { return page != kInvalidPage; }
};

struct AtlasPage {
  u32 width = 0, height = 0;
  std::vector<u8> rgba;  // width*height*4, ready for create_texture
};

struct Atlas {
  std::vector<AtlasPage> pages;
  std::vector<AtlasRegion> regions;  // same order and size as the input images

  // UV rect for SpriteDesc::uv. Always inside 0..1. Rect{} for an invalid region.
  [[nodiscard]] Rect uv(u32 image_index) const noexcept;
  [[nodiscard]] bool all_placed() const noexcept;
};

// Never throws on bad input: unplaceable images get an invalid region (check all_placed()).
[[nodiscard]] Atlas build_atlas(std::span<const AtlasImage> images, const AtlasConfig& cfg = {});

}  // namespace nv
