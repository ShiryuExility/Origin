#pragma once
// CPU-side sprite batcher. Backend-agnostic: it only produces a vertex array
// plus "runs" (consecutive sprites sharing a texture). Each backend uploads the
// vertices once and issues one draw call per run, using a static index buffer.
#include <memory>
#include <span>
#include <vector>

#include "core/types.hpp"

namespace nv {

using TextureId = u32;  // 0 = invalid

// 16 bytes: float2 pos, unorm16x2 uv, unorm8x4 color. Small = less bandwidth on phones.
struct SpriteVertex {
  f32 x, y;
  u16 u, v;
  Color c;
};
static_assert(sizeof(SpriteVertex) == 16);

struct SpriteDesc {
  TextureId texture = 0;
  Vec2 position{};        // world position of the pivot
  Vec2 size{1.f, 1.f};
  Vec2 pivot{0.5f, 0.5f}; // 0..1 inside the sprite
  f32 rotation = 0.f;     // radians, clockwise on screen (y-down)
  Rect uv{0.f, 0.f, 1.f, 1.f};  // must stay inside 0..1
  Color color{};         // flat tint (no gradients: one color per sprite keeps vertices cheap)
  bool flip_x = false;
  bool flip_y = false;
};

// A UV rectangle already converted to the vertex format. Convert once (SpriteBatch::quantize),
// then reuse it for thousands of sprites instead of converting four floats per sprite per frame.
struct QuantUv {
  u16 u0 = 0, v0 = 0, u1 = 65535, v1 = 65535;
};

struct SpriteRun {
  TextureId texture;
  u32 first;  // first sprite index
  u32 count;  // number of sprites
};

class SpriteBatch {
 public:
  // 4 vertices per sprite with u16 indices => at most 16383 sprites per batch.
  static constexpr u32 kMaxSprites = 65535 / 4;

  explicit SpriteBatch(u32 max_sprites);

  void clear() noexcept;
  bool draw(const SpriteDesc& s);  // false when the batch is full
  // Fast path for axis-aligned sprites (no rotation, no flip, centered pivot): the particle field
  // and most UI take it. Same output as draw() with those defaults.
  bool draw_quad(TextureId texture, Vec2 center, Vec2 size, const QuantUv& uv, Color color);
  // Fast path for stroke bodies: a thick segment from p to q (what draw() makes with a rotated,
  // centered bar of length |pq|), built straight from the endpoints: no sin / cos / atan2.
  bool draw_segment(TextureId texture, Vec2 p, Vec2 q, f32 thickness, const QuantUv& uv, Color color);
  [[nodiscard]] static QuantUv quantize(const Rect& uv) noexcept;

  [[nodiscard]] u32 sprite_count() const noexcept { return count_; }
  [[nodiscard]] u32 capacity() const noexcept { return max_; }
  [[nodiscard]] std::span<const SpriteVertex> vertices() const noexcept {
    return {vertices_.get(), std::size_t{count_} * 4};
  }
  [[nodiscard]] std::span<const SpriteRun> runs() const noexcept { return runs_; }

 private:
  void push_run(TextureId texture);
  u32 max_;
  u32 count_ = 0;
  std::unique_ptr<SpriteVertex[]> vertices_;
  std::vector<SpriteRun> runs_;
};

}  // namespace nv
