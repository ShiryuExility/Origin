#pragma once
#include <array>
#include <memory>

#include "core/types.hpp"
#include "render/sprite_batch.hpp"

struct SDL_Window;

namespace nv {

enum class Backend : u8 { Vulkan, GLES };

// 2D camera, y-down (screen-style). position = world point at the screen center.
struct Camera2D {
  Vec2 position{};
  f32 zoom = 1.f;  // pixels per world unit

  // {scaleX, scaleY, offsetX, offsetY}: clip = world * scale + offset
  [[nodiscard]] std::array<f32, 4> view_params(u32 vw, u32 vh) const noexcept {
    const f32 w = vw ? static_cast<f32>(vw) : 1.f;
    const f32 h = vh ? static_cast<f32>(vh) : 1.f;
    const f32 sx = 2.f * zoom / w;
    const f32 sy = -2.f * zoom / h;
    return {sx, sy, -position.x * sx, -position.y * sy};
  }
};

class IRenderer {
 public:
  virtual ~IRenderer() = default;
  [[nodiscard]] virtual Backend backend() const noexcept = 0;
  virtual void resize(u32 pixel_w, u32 pixel_h) = 0;

  virtual TextureId create_texture(u32 w, u32 h, const void* rgba8, bool linear_filter) = 0;
  virtual void destroy_texture(TextureId id) = 0;

  virtual void begin_frame(Color clear) = 0;
  virtual void draw(const SpriteBatch& batch, const Camera2D& camera) = 0;
  virtual void end_frame() = 0;  // present
};

// Call BEFORE SDL_CreateWindow; OR the result into the window flags.
// (Sets the GL attributes for GLES, or returns the Vulkan flag.)
[[nodiscard]] u64 renderer_window_flags(Backend backend);

// Returns nullptr (and logs why) if the backend is unavailable.
[[nodiscard]] std::unique_ptr<IRenderer> create_renderer(Backend backend, SDL_Window* window,
                                                         u32 max_sprites);

}  // namespace nv
