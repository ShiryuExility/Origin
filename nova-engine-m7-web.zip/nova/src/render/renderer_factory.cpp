#include <SDL3/SDL.h>

#include "render/gles/gles_renderer.hpp"
#include "render/renderer.hpp"

namespace nv {

u64 renderer_window_flags(Backend backend) {
  switch (backend) {
    case Backend::GLES:
      SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
      SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
      SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
      SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
      SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 0);  // 2D: no depth buffer, saves bandwidth
      return SDL_WINDOW_OPENGL;
    case Backend::Vulkan:
      return SDL_WINDOW_VULKAN;
  }
  return 0;
}

std::unique_ptr<IRenderer> create_renderer(Backend backend, SDL_Window* window, u32 max_sprites) {
  switch (backend) {
    case Backend::GLES:
      return make_gles_renderer(window, max_sprites);
    case Backend::Vulkan:
      SDL_Log("Vulkan backend is not implemented yet (next milestone).");
      return nullptr;
  }
  return nullptr;
}

}  // namespace nv
