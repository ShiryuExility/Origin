#pragma once
// Linear (bump) arena. O(1) alloc, O(1) reset, zero fragmentation, zero GC.
// Use one per frame for temp data: no allocation spikes mid-frame on phones.
#include <cassert>
#include <memory>
#include <new>
#include <type_traits>
#include <utility>

#include "core/types.hpp"

namespace nv {

class LinearArena {
 public:
  static constexpr std::size_t kBaseAlign = 64;  // cache line

  explicit LinearArena(std::size_t capacity)
      : base_(static_cast<std::byte*>(::operator new(capacity, std::align_val_t{kBaseAlign}))),
        cap_(capacity) {}
  ~LinearArena() { ::operator delete(base_, std::align_val_t{kBaseAlign}); }

  LinearArena(const LinearArena&) = delete;
  LinearArena& operator=(const LinearArena&) = delete;

  // align must be a power of two <= kBaseAlign. Returns nullptr when full.
  [[nodiscard]] void* allocate(std::size_t size, std::size_t align = alignof(std::max_align_t)) noexcept {
    assert(align != 0 && (align & (align - 1)) == 0 && align <= kBaseAlign);
    const std::size_t start = (used_ + align - 1) & ~(align - 1);
    if (start > cap_ || size > cap_ - start) return nullptr;
    used_ = start + size;
    return base_ + start;
  }

  template <class T, class... Args>
  [[nodiscard]] T* create(Args&&... args) {
    static_assert(std::is_trivially_destructible_v<T>, "arena never runs destructors");
    void* mem = allocate(sizeof(T), alignof(T));
    return mem ? ::new (mem) T(std::forward<Args>(args)...) : nullptr;
  }

  template <class T>
  [[nodiscard]] T* create_array(std::size_t n) {
    static_assert(std::is_trivially_destructible_v<T>, "arena never runs destructors");
    void* mem = allocate(sizeof(T) * n, alignof(T));
    if (!mem) return nullptr;
    T* p = static_cast<T*>(mem);
    std::uninitialized_value_construct_n(p, n);
    return p;
  }

  void reset() noexcept { used_ = 0; }
  [[nodiscard]] std::size_t used() const noexcept { return used_; }
  [[nodiscard]] std::size_t capacity() const noexcept { return cap_; }

 private:
  std::byte* base_;
  std::size_t cap_;
  std::size_t used_ = 0;
};

}  // namespace nv
