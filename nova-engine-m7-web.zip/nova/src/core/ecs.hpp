#pragma once
// Minimal sparse-set ECS. Components live in dense arrays (cache-friendly
// iteration), entity handles carry a generation so stale handles are detected.
// Single-threaded. Do NOT add/remove components or destroy entities inside each().
#include <array>
#include <cassert>
#include <memory>
#include <span>
#include <tuple>
#include <utility>
#include <vector>

#include "core/types.hpp"

namespace nv {

using Entity = u32;  // [ generation:12 | index:20 ]
inline constexpr u32 kEntityIndexBits = 20;
inline constexpr u32 kEntityIndexMask = (1u << kEntityIndexBits) - 1;
inline constexpr u32 kEntityGenMask = (1u << (32 - kEntityIndexBits)) - 1;
inline constexpr Entity kNullEntity = ~Entity{0};

constexpr u32 entity_index(Entity e) noexcept { return e & kEntityIndexMask; }
constexpr u32 entity_gen(Entity e) noexcept { return e >> kEntityIndexBits; }

namespace detail {
inline std::size_t next_component_id() noexcept {
  static std::size_t n = 0;
  return n++;
}
template <class T>
std::size_t component_id() noexcept {
  static const std::size_t id = next_component_id();
  return id;
}
}  // namespace detail

class PoolBase {
 public:
  virtual ~PoolBase() = default;
  virtual void remove(Entity e) noexcept = 0;
  [[nodiscard]] virtual std::span<const Entity> entities() const noexcept = 0;
};

template <class T>
class SparsePool final : public PoolBase {
 public:
  [[nodiscard]] bool has(Entity e) const noexcept {
    const u32 i = entity_index(e);
    if (i >= sparse_.size()) return false;
    const u32 d = sparse_[i];
    return d != kNone && dense_[d] == e;
  }

  template <class... Args>
  T& emplace(Entity e, Args&&... args) {
    const u32 i = entity_index(e);
    if (i >= sparse_.size()) {
      const std::size_t grown = sparse_.size() * 2;
      sparse_.resize(grown > i + 1 ? grown : i + 1, kNone);
    }
    if (has(e)) {
      T& slot = data_[sparse_[i]];
      slot = T(std::forward<Args>(args)...);
      return slot;
    }
    sparse_[i] = static_cast<u32>(dense_.size());
    dense_.push_back(e);
    return data_.emplace_back(std::forward<Args>(args)...);
  }

  [[nodiscard]] T& get(Entity e) noexcept {
    assert(has(e));
    return data_[sparse_[entity_index(e)]];
  }

  void remove(Entity e) noexcept override {
    if (!has(e)) return;
    const u32 i = entity_index(e);
    const u32 d = sparse_[i];
    const u32 last_d = static_cast<u32>(dense_.size() - 1);
    if (d != last_d) {
      const Entity last = dense_[last_d];
      dense_[d] = last;
      data_[d] = std::move(data_[last_d]);
      sparse_[entity_index(last)] = d;
    }
    dense_.pop_back();
    data_.pop_back();
    sparse_[i] = kNone;
  }

  [[nodiscard]] std::span<const Entity> entities() const noexcept override { return dense_; }
  [[nodiscard]] std::size_t size() const noexcept { return dense_.size(); }

 private:
  static constexpr u32 kNone = ~0u;
  std::vector<u32> sparse_;   // entity index -> dense slot
  std::vector<Entity> dense_; // dense slot -> entity
  std::vector<T> data_;       // dense slot -> component
};

class Registry {
 public:
  [[nodiscard]] Entity create() {
    u32 idx;
    if (!free_.empty()) {
      idx = free_.back();
      free_.pop_back();
    } else {
      idx = static_cast<u32>(generations_.size());
      assert(idx < kEntityIndexMask && "entity limit reached");
      generations_.push_back(0);
    }
    ++alive_count_;
    return (generations_[idx] << kEntityIndexBits) | idx;
  }

  void destroy(Entity e) {
    if (!alive(e)) return;
    for (auto& p : pools_) {
      if (p) p->remove(e);
    }
    const u32 idx = entity_index(e);
    generations_[idx] = (generations_[idx] + 1) & kEntityGenMask;
    free_.push_back(idx);
    --alive_count_;
  }

  [[nodiscard]] bool alive(Entity e) const noexcept {
    const u32 idx = entity_index(e);
    return e != kNullEntity && idx < generations_.size() && generations_[idx] == entity_gen(e);
  }
  [[nodiscard]] std::size_t alive_count() const noexcept { return alive_count_; }

  template <class T, class... Args>
  T& add(Entity e, Args&&... args) {
    assert(alive(e));
    return pool<T>().emplace(e, std::forward<Args>(args)...);
  }
  template <class T>
  [[nodiscard]] bool has(Entity e) const noexcept {
    const auto* p = try_pool<T>();
    return p && p->has(e);
  }
  template <class T>
  [[nodiscard]] T& get(Entity e) noexcept {
    return pool<T>().get(e);
  }
  template <class T>
  void remove(Entity e) noexcept {
    if (auto* p = try_pool<T>()) p->remove(e);
  }
  template <class T>
  [[nodiscard]] std::size_t count() const noexcept {
    const auto* p = try_pool<T>();
    return p ? p->size() : 0;
  }

  // Calls f(Entity, Cs&...) for every entity owning all of Cs (each type once).
  // Iterates the smallest pool and probes the rest.
  template <class... Cs, class F>
  void each(F&& f) {
    static_assert(sizeof...(Cs) > 0, "each<> needs at least one component");
    const std::tuple<SparsePool<Cs>*...> ps{try_pool<Cs>()...};
    bool missing = false;
    std::apply([&](auto*... p) { missing = ((p == nullptr) || ...); }, ps);
    if (missing) return;

    std::span<const Entity> lead;
    bool first = true;
    auto consider = [&](const PoolBase& p) {
      const auto s = p.entities();
      if (first || s.size() < lead.size()) {
        lead = s;
        first = false;
      }
    };
    std::apply([&](auto*... p) { (consider(*p), ...); }, ps);

    for (std::size_t k = 0; k < lead.size(); ++k) {
      const Entity e = lead[k];
      std::apply([&](auto*... p) {
        if ((p->has(e) && ...)) f(e, p->get(e)...);
      }, ps);
    }
  }

 private:
  template <class T>
  SparsePool<T>& pool() {
    const std::size_t id = detail::component_id<T>();
    if (id >= pools_.size()) pools_.resize(id + 1);
    if (!pools_[id]) pools_[id] = std::make_unique<SparsePool<T>>();
    return static_cast<SparsePool<T>&>(*pools_[id]);
  }
  template <class T>
  SparsePool<T>* try_pool() const noexcept {
    const std::size_t id = detail::component_id<T>();
    if (id >= pools_.size() || !pools_[id]) return nullptr;
    return static_cast<SparsePool<T>*>(pools_[id].get());
  }

  std::vector<u32> generations_;
  std::vector<u32> free_;
  std::vector<std::unique_ptr<PoolBase>> pools_;
  std::size_t alive_count_ = 0;
};

}  // namespace nv
