#pragma once
#include <cstddef>
#include <cstdint>

namespace nv {

using u8 = std::uint8_t;
using u16 = std::uint16_t;
using u32 = std::uint32_t;
using u64 = std::uint64_t;
using i32 = std::int32_t;
using f32 = float;

struct Vec2 { f32 x = 0.f, y = 0.f; };
struct Rect { f32 x = 0.f, y = 0.f, w = 0.f, h = 0.f; };
struct Color { u8 r = 255, g = 255, b = 255, a = 255; };  // packed RGBA8: 4 bytes/vertex

}  // namespace nv
