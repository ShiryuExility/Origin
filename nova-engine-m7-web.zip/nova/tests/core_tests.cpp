// Dependency-free tests + micro benchmark. Build: g++ -std=c++23 -O2 -Isrc ...
#include "sandbox/stroke.hpp"
#include "sandbox/transform.hpp"
#include <array>
#include <chrono>
#include <cmath>
#include <numbers>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <vector>

#include "core/arena.hpp"
#include "core/ecs.hpp"
#include "render/atlas.hpp"
#include "render/font.hpp"
#include "render/sprite_batch.hpp"

using namespace nv;

static int g_fail = 0;
#define CHECK(c)                                                         \
  do {                                                                   \
    if (!(c)) {                                                          \
      std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #c);           \
      ++g_fail;                                                          \
    }                                                                    \
  } while (0)

struct A { int v; };
struct B { float f; };

static void test_stroke_simplify() {
  using namespace nv;
  std::vector<Vec2> line;  // collinear points collapse to the two ends
  for (int i = 0; i <= 100; ++i) line.push_back({static_cast<f32>(i), 2.f * static_cast<f32>(i)});
  simplify_stroke(line, 0.1f);
  CHECK(line.size() == 2 && line.front().x == 0.f && line.back().x == 100.f);

  std::vector<Vec2> circle;  // a smooth hand-drawn-like circle (r = 50, 1000 points)
  for (int i = 0; i <= 1000; ++i) {
    const f32 t = static_cast<f32>(i) * 6.2831853f / 1000.f;
    circle.push_back({50.f * std::cos(t), 50.f * std::sin(t)});
  }
  const std::vector<Vec2> orig = circle;
  simplify_stroke(circle, 0.4f);
  CHECK(circle.size() < orig.size() / 5 && circle.size() > 8);
  CHECK(circle.front().x == orig.front().x && circle.back().y == orig.back().y);
  for (const Vec2& p : orig) {  // every original point stays within eps of the simplified polyline
    f32 best = 1e9f;
    for (std::size_t i = 0; i + 1 < circle.size(); ++i)
      best = std::min(best, stroke_detail::seg_dist2(p, circle[i], circle[i + 1]));
    CHECK(best <= 0.4f * 0.4f + 1e-3f);
  }
  std::vector<Vec2> keep = orig;  // eps = 0 keeps everything; tiny inputs are untouched
  simplify_stroke(keep, 0.f);
  CHECK(keep.size() == orig.size());
  std::vector<Vec2> two{{0.f, 0.f}, {5.f, 5.f}};
  simplify_stroke(two, 1.f);
  CHECK(two.size() == 2);
}

static bool near(float a, float b, float e = 1e-3f) { return std::fabs(a - b) <= e; }

static void test_transform() {
  using namespace nv;
  Shape2D box;
  box.kind = Shape2D::Box; box.a = {0.f, 0.f}; box.b = {100.f, 50.f};
  compute_bounds(box);
  const Frame f = frame_of(box, 0.f);
  CHECK(near(f.c.x, 50.f) && near(f.c.y, 25.f) && near(f.hx, 50.f) && near(f.hy, 25.f));

  Xf rot90; rot90.rotate = std::numbers::pi_v<float> * 0.5f;  // 90 degrees: width and height swap about the center
  const Shape2D r = transformed(box, f, rot90);
  CHECK(near(r.rot, rot90.rotate));
  CHECK(near(r.bounds.x, 25.f) && near(r.bounds.y, -25.f) && near(r.bounds.w, 50.f) && near(r.bounds.h, 100.f));
  Xf back; back.rotate = -rot90.rotate;  // round trip returns the original rect
  const Shape2D r2 = transformed(r, frame_of(r, 0.f), back);
  CHECK(near(r2.rot, 0.f) && near(r2.a.x, 0.f) && near(r2.a.y, 0.f) && near(r2.b.x, 100.f) && near(r2.b.y, 50.f));

  // SE corner dragged along the diagonal by a full box size: uniform x2, the NW corner stays put
  const Shape2D big = transformed(box, f, scale_xf(f, Handle::SE, {100.f, 50.f}));
  CHECK(near(big.a.x, 0.f) && near(big.a.y, 0.f) && near(big.b.x, 200.f) && near(big.b.y, 100.f));
  // E side: stretch X only, the W edge stays put
  const Shape2D wide = transformed(box, f, scale_xf(f, Handle::E, {30.f, 99.f}));
  CHECK(near(wide.a.x, 0.f) && near(wide.b.x, 130.f) && near(wide.a.y, 0.f) && near(wide.b.y, 50.f));
  // dragging far past the opposite corner never flips: it bottoms out at a tiny positive size
  const Shape2D tiny = transformed(box, f, scale_xf(f, Handle::SE, {-900.f, -900.f}));
  CHECK(tiny.b.x >= tiny.a.x && tiny.b.y >= tiny.a.y && tiny.b.x - tiny.a.x <= 10.f);
  // rotated box: scaling works in its own axes (E handle of a 90-degree box points down on screen)
  const Frame fr = frame_of(r, 0.f);
  const Shape2D rw = transformed(r, fr, scale_xf(fr, Handle::E, {100.f, 0.f}));  // local x: 100 -> 200 wide
  CHECK(near(rw.b.x - rw.a.x, 200.f) && near(rw.rot, rot90.rotate));

  // stroke: rotating a horizontal stroke 90 degrees about its center makes it vertical; the brush is untouched
  Shape2D st;
  st.kind = Shape2D::Stroke; st.width = 6.f; st.pts = {{0.f, 0.f}, {100.f, 0.f}};
  compute_bounds(st);
  const Shape2D sr = transformed(st, frame_of(st, 0.f), rot90);
  CHECK(near(sr.pts[0].x, 50.f) && near(sr.pts[0].y, -50.f) && near(sr.pts[1].x, 50.f) && near(sr.pts[1].y, 50.f));
  CHECK(sr.width == 6.f && near(sr.bounds.w, 6.f));
  // a flat stroke still gets a usable frame (min_half) and can be scaled without dividing by zero
  const Frame fs = frame_of(st, 14.f);
  CHECK(fs.hy >= 14.f);
  const Shape2D ss = transformed(st, fs, scale_xf(fs, Handle::S, {0.f, 20.f}));
  CHECK(std::isfinite(ss.bounds.w) && std::isfinite(ss.bounds.h));
  // move
  Xf mv; mv.move = {10.f, 5.f};
  const Shape2D sm = transformed(st, frame_of(st, 0.f), mv);
  CHECK(near(sm.pts[0].x, 10.f) && near(sm.pts[0].y, 5.f) && near(sm.bounds.x, st.bounds.x + 10.f));

  // rotated ellipse: exact bounds (a 100x50 ellipse turned 90 degrees is 50 wide, 100 tall)
  Shape2D ov;
  ov.kind = Shape2D::Oval; ov.a = {0.f, 0.f}; ov.b = {100.f, 50.f}; ov.rot = rot90.rotate;
  compute_bounds(ov);
  CHECK(near(ov.bounds.w, 50.f, 0.01f) && near(ov.bounds.h, 100.f, 0.01f));

  // 15-degree snapping within 3 degrees
  CHECK(near(snap_angle(0.02f), 0.f) && near(snap_angle(0.2618f + 0.01f), std::numbers::pi_v<float> / 12.f));
  CHECK(near(snap_angle(0.15f), 0.15f));
  // handle geometry: rotate handle floats above the top edge; frame <-> world round trip
  const Vec2 rh = handle_local(f, Handle::Rotate, 4.f, 30.f);
  CHECK(near(rh.x, 0.f) && near(rh.y, -(25.f + 4.f + 30.f)));
  const Frame rf = frame_of(r, 0.f);
  const Vec2 w = frame_to_world(rf, frame_to_local(rf, {12.f, 34.f}));
  CHECK(near(w.x, 12.f) && near(w.y, 34.f));
}

static void test_arena() {
  LinearArena a(1024);
  void* p1 = a.allocate(1, 1);
  void* p2 = a.allocate(8, 8);
  CHECK(p1 && p2);
  CHECK(reinterpret_cast<std::uintptr_t>(p2) % 8 == 0);
  void* p3 = a.allocate(16, 64);
  CHECK(reinterpret_cast<std::uintptr_t>(p3) % 64 == 0);
  CHECK(a.allocate(2048) == nullptr);       // too big -> nullptr, no overflow
  CHECK(a.allocate(~std::size_t{0}) == nullptr);
  a.reset();
  CHECK(a.used() == 0);
  int* arr = a.create_array<int>(10);
  bool zero = true;
  for (int i = 0; i < 10; ++i) zero &= (arr[i] == 0);
  CHECK(zero);
  auto* x = a.create<A>(42);
  CHECK(x && x->v == 42);
}

static void test_ecs() {
  Registry r;
  Entity e1 = r.create(), e2 = r.create(), e3 = r.create();
  r.add<A>(e1, 1);
  r.add<A>(e2, 2);
  r.add<B>(e2, 2.5f);
  r.add<A>(e3, 3);
  CHECK(r.count<A>() == 3 && r.count<B>() == 1);
  CHECK(r.has<A>(e1) && !r.has<B>(e1));

  int sum = 0, visited = 0;
  r.each<A, B>([&](Entity e, A& a, B& b) { sum += a.v; ++visited; CHECK(e == e2); CHECK(b.f == 2.5f); });
  CHECK(visited == 1 && sum == 2);

  r.remove<A>(e1);  // swap-remove must keep e3 reachable
  CHECK(!r.has<A>(e1) && r.get<A>(e3).v == 3 && r.get<A>(e2).v == 2);

  r.destroy(e2);
  CHECK(!r.alive(e2) && !r.has<A>(e2) && !r.has<B>(e2));
  Entity e4 = r.create();                     // reuses the slot, new generation
  CHECK(entity_index(e4) == entity_index(e2) && e4 != e2);
  CHECK(!r.alive(e2) && r.alive(e4));
  CHECK(!r.has<A>(e2));                       // stale handle must not alias e4
  r.add<A>(e4, 9);
  CHECK(!r.has<A>(e2) && r.has<A>(e4));
  CHECK(r.alive_count() == 3);

  int none = 0;
  r.each<B>([&](Entity, B&) { ++none; });     // pool exists but empty
  CHECK(none == 0);
}

static void test_flat_and_quad() {
  SpriteBatch b(4);
  SpriteDesc d;
  d.texture = 1;
  d.position = {10.f, 20.f};
  d.size = {4.f, 2.f};
  d.uv = Rect{0.25f, 0.5f, 0.25f, 0.25f};
  d.color = Color{200, 100, 50, 255};
  b.draw(d);
  // the fast path must emit exactly what draw() emits for an axis-aligned centered sprite
  CHECK(b.draw_quad(1, {10.f, 20.f}, {4.f, 2.f}, SpriteBatch::quantize(d.uv), d.color));
  const auto v = b.vertices();
  CHECK(v.size() == 8);
  for (int i = 0; i < 4; ++i) {
    CHECK(v[static_cast<std::size_t>(i)].c.r == 200 && v[static_cast<std::size_t>(i)].c.g == 100);  // flat: all corners equal
    CHECK(v[static_cast<std::size_t>(i)].x == v[static_cast<std::size_t>(i) + 4].x);
    CHECK(v[static_cast<std::size_t>(i)].y == v[static_cast<std::size_t>(i) + 4].y);
    CHECK(v[static_cast<std::size_t>(i)].u == v[static_cast<std::size_t>(i) + 4].u);
    CHECK(v[static_cast<std::size_t>(i)].v == v[static_cast<std::size_t>(i) + 4].v);
  }
  CHECK(b.runs().size() == 1 && b.runs()[0].count == 2);  // same texture: one run
  SpriteBatch full(1);
  CHECK(full.draw_quad(1, {}, {1.f, 1.f}, {}, Color{}));
  CHECK(!full.draw_quad(1, {}, {1.f, 1.f}, {}, Color{}));  // full batch refuses
}

static void test_batch() {
  SpriteBatch b(4);
  SpriteDesc d;
  d.texture = 1;
  d.position = {10.f, 20.f};
  d.size = {4.f, 2.f};
  d.pivot = {0.f, 0.f};
  CHECK(b.draw(d));
  const auto v = b.vertices();
  CHECK(v.size() == 4);
  CHECK(v[0].x == 10.f && v[0].y == 20.f);
  CHECK(v[2].x == 14.f && v[2].y == 22.f);
  CHECK(v[0].u == 0 && v[0].v == 0 && v[2].u == 65535 && v[2].v == 65535);

  d.flip_x = true;
  CHECK(b.draw(d));
  CHECK(b.vertices()[4].u == 65535 && b.vertices()[5].u == 0);

  d.flip_x = false;
  d.texture = 2;
  CHECK(b.draw(d));
  d.texture = 2;
  CHECK(b.draw(d));
  CHECK(!b.draw(d));                           // full
  CHECK(b.runs().size() == 2);                 // tex1 x2, tex2 x2
  CHECK(b.runs()[0].count == 2 && b.runs()[1].first == 2 && b.runs()[1].count == 2);

  b.clear();
  CHECK(b.sprite_count() == 0 && b.runs().empty());

  SpriteDesc r;                                // 90 degree rotation about the pivot
  r.position = {0.f, 0.f};
  r.size = {2.f, 2.f};
  r.rotation = 3.14159265f * 0.5f;
  CHECK(b.draw(r));
  CHECK(std::fabs(b.vertices()[0].x - 1.f) < 1e-5f && std::fabs(b.vertices()[0].y + 1.f) < 1e-5f);
}

struct P { Vec2 p; };
struct V { Vec2 v; };
struct S { Vec2 size; Color c; };


static bool overlap(const AtlasRegion& a, const AtlasRegion& b) {
  return a.page == b.page && a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
}

static void test_maxrects() {
  MaxRectsPacker p(64, 64);
  PackedRect r;
  CHECK(!p.insert(0, 8, r));                  // empty rect rejected
  CHECK(!p.insert(65, 1, r));                 // does not fit
  for (int i = 0; i < 16; ++i) CHECK(p.insert(16, 16, r));  // 16 * 256 = exactly 64x64
  CHECK(!p.insert(1, 1, r));                  // full
  CHECK(p.occupancy() > 0.999f);

  // Random rects: never overlap, never leave the bin.
  MaxRectsPacker q(256, 256);
  std::vector<std::array<u32, 4>> placed;
  u32 s = 12345;
  auto rnd = [&] { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; };
  for (int i = 0; i < 400; ++i) {
    const u32 w = 4 + rnd() % 40, h = 4 + rnd() % 40;
    PackedRect at;
    if (!q.insert(w, h, at)) continue;
    CHECK(at.x + w <= 256 && at.y + h <= 256);
    for (const auto& o : placed)
      CHECK(!(at.x < o[0] + o[2] && o[0] < at.x + w && at.y < o[1] + o[3] && o[1] < at.y + h));
    placed.push_back({at.x, at.y, w, h});
  }
  CHECK(placed.size() > 40);
}

static void test_atlas() {
  // Solid-color images, color = index + 1, so every pixel's owner is checkable.
  const u32 sizes[][2] = {{30, 20}, {16, 16}, {8, 40}, {50, 50}, {1, 1}, {12, 7}, {64, 8}};
  constexpr u32 N = 7;
  std::vector<std::vector<u8>> px(N);
  std::vector<AtlasImage> imgs(N);
  for (u32 i = 0; i < N; ++i) {
    px[i].assign(std::size_t{sizes[i][0]} * sizes[i][1] * 4, static_cast<u8>(i + 1));
    imgs[i] = {sizes[i][0], sizes[i][1], px[i].data()};
  }
  AtlasConfig cfg;
  cfg.max_page_size = 128;
  cfg.padding = 2;
  Atlas a = build_atlas(imgs, cfg);
  CHECK(a.all_placed() && a.regions.size() == N);
  for (u32 i = 0; i < N; ++i) {
    const AtlasRegion& r = a.regions[i];
    CHECK(r.w == sizes[i][0] && r.h == sizes[i][1]);
    const AtlasPage& pg = a.pages[r.page];
    CHECK(r.x >= 2 && r.y >= 2 && r.x + r.w + 2 <= pg.width && r.y + r.h + 2 <= pg.height);
    // Interior + the 2px extruded ring (corners too) all carry this image's color.
    bool ok = true;
    for (u32 y = r.y - 2; y < r.y + r.h + 2; ++y)
      for (u32 x = r.x - 2; x < r.x + r.w + 2; ++x) ok &= pg.rgba[(std::size_t{y} * pg.width + x) * 4] == i + 1;
    CHECK(ok);
    for (u32 j = i + 1; j < N; ++j) {
      // Padded slots must not overlap either.
      AtlasRegion pi = r, pj = a.regions[j];
      pi.x -= 2; pi.y -= 2; pi.w += 4; pi.h += 4;
      pj.x -= 2; pj.y -= 2; pj.w += 4; pj.h += 4;
      CHECK(!overlap(pi, pj));
    }
    const Rect uv = a.uv(i);
    CHECK(uv.x >= 0.f && uv.y >= 0.f && uv.x + uv.w <= 1.f && uv.y + uv.h <= 1.f && uv.w > 0.f);
  }
  for (const auto& pg : a.pages) {
    CHECK((pg.width & (pg.width - 1)) == 0 && (pg.height & (pg.height - 1)) == 0);  // pow2
    CHECK(pg.width <= 128 && pg.height <= 128);
  }

  // Edge extrusion copies *edge* pixels: 2x1 image, left red, right blue.
  const u8 two[8] = {255, 0, 0, 255, 0, 0, 255, 255};
  const AtlasImage one[] = {{2, 1, two}};
  AtlasConfig c1;
  c1.padding = 1;
  c1.pow2_pages = false;
  Atlas b = build_atlas(one, c1);
  CHECK(b.pages.size() == 1 && b.pages[0].width == 4 && b.pages[0].height == 3);
  const auto at = [&](u32 x, u32 y) { return &b.pages[0].rgba[(std::size_t{y} * 4 + x) * 4]; };
  CHECK(at(0, 0)[0] == 255 && at(0, 2)[0] == 255);   // left column extruded from red
  CHECK(at(3, 0)[2] == 255 && at(3, 2)[2] == 255);   // right column extruded from blue

  // Multi-page overflow: 5 images of 100x100 into 128 pages (padding 1) -> 5 pages.
  std::vector<u8> big(100 * 100 * 4, 7);
  std::vector<AtlasImage> many(5, AtlasImage{100, 100, big.data()});
  AtlasConfig c2;
  c2.max_page_size = 128;
  Atlas m = build_atlas(many, c2);
  CHECK(m.all_placed() && m.pages.size() == 5);

  // Bad inputs never crash and are reported as invalid; good ones still pack.
  std::vector<u8> ok4(4 * 4 * 4, 1);
  const AtlasImage bad[] = {{0, 4, ok4.data()}, {4, 4, nullptr}, {500, 4, big.data()}, {4, 4, ok4.data()}};
  Atlas e = build_atlas(bad, c2);
  CHECK(!e.regions[0].valid() && !e.regions[1].valid() && !e.regions[2].valid() && e.regions[3].valid());
  CHECK(!e.all_placed());
  CHECK(e.uv(0).w == 0.f && e.uv(99).w == 0.f);

  // Deterministic.
  Atlas a2 = build_atlas(imgs, cfg);
  bool same = a2.pages.size() == a.pages.size();
  for (u32 i = 0; same && i < N; ++i)
    same = a.regions[i].x == a2.regions[i].x && a.regions[i].y == a2.regions[i].y && a.regions[i].page == a2.regions[i].page;
  CHECK(same);
}

static void test_font() {
  std::ifstream f("assets/fonts/InterDisplay-Light.otf", std::ios::binary);  // ctest runs from the repo root
  if (!f) {
    std::printf("skip test_font (run from the repo root)\n");
    return;
  }
  const std::vector<u8> bytes((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  CHECK(!bake_font({}, 24.f));                          // empty data -> nullopt
  auto font = bake_font(bytes, 24.f);
  CHECK(font.has_value());
  if (!font) return;
  CHECK(font->ascent > 0.f && font->descent < 0.f);
  const Glyph& w = font->glyph('W');
  CHECK(w.has_bitmap && w.w > 5.f && w.advance > 10.f && w.uv.w > 0.f && w.uv.x + w.uv.w <= 1.f);
  CHECK(!font->glyph(' ').has_bitmap && font->glyph(' ').advance > 0.f);
  CHECK(font->glyph('\x01').advance == font->glyph('?').advance);  // unknown -> '?'
  TextStyle st;
  st.tracking = 4.f;
  const f32 one = measure_text(*font, "N", st), three = measure_text(*font, "NNN", st);
  CHECK(std::fabs(three - (3 * one + 2 * 4.f)) < 0.01f);   // tracking only between glyphs
  SpriteBatch b(64);
  draw_text(b, 1, *font, "Nova 123", {10.f, 40.f}, st);
  CHECK(b.sprite_count() == 7);                          // 8 chars - 1 space
  bool inked = false;
  for (std::size_t i = 3; i < font->page.rgba.size(); i += 4) inked |= font->page.rgba[i] > 200;
  CHECK(inked);
}

static void test_segment() {
  // draw_segment must match draw() with a rotated, centered bar of length |pq| (what strokes used before)
  const Vec2 pts[][2] = {{{0.f, 0.f}, {10.f, 0.f}}, {{3.f, 4.f}, {-5.f, 9.f}}, {{-2.f, 7.f}, {-2.f, -3.f}}, {{1.f, 1.f}, {1.f, 1.f}}};
  const Rect uv{0.f, 0.f, 1.f, 1.f};
  for (const auto& s : pts) {
    SpriteBatch b(2);
    const f32 dx = s[1].x - s[0].x, dy = s[1].y - s[0].y;
    SpriteDesc d;
    d.texture = 1;
    d.uv = uv;
    d.position = {(s[0].x + s[1].x) * 0.5f, (s[0].y + s[1].y) * 0.5f};
    d.size = {std::sqrt(dx * dx + dy * dy), 6.f};
    d.rotation = std::atan2(dy, dx);
    d.color = Color{9, 8, 7, 255};
    b.draw(d);
    CHECK(b.draw_segment(1, s[0], s[1], 6.f, SpriteBatch::quantize(uv), d.color));
    const auto v = b.vertices();
    for (std::size_t i = 0; i < 4; ++i) {
      CHECK(std::fabs(v[i].x - v[i + 4].x) < 1e-4f && std::fabs(v[i].y - v[i + 4].y) < 1e-4f);
      CHECK(v[i].u == v[i + 4].u && v[i].v == v[i + 4].v);
    }
  }
  SpriteBatch full(1);
  CHECK(full.draw_segment(1, {}, {1.f, 0.f}, 1.f, {}, Color{}));
  CHECK(!full.draw_segment(1, {}, {1.f, 0.f}, 1.f, {}, Color{}));
}

static void bench() {
  using clk = std::chrono::steady_clock;
  constexpr u32 N = 16000;
  Registry r;
  for (u32 i = 0; i < N; ++i) {
    Entity e = r.create();
    r.add<P>(e, Vec2{float(i % 1280), float(i % 720)});
    r.add<V>(e, Vec2{1.f, 1.f});
    r.add<S>(e, Vec2{8.f, 8.f}, Color{});
  }
  SpriteBatch batch(N);
  const int iters = 200;
  double t_upd = 0, t_batch = 0, t_quad = 0;
  const QuantUv q = SpriteBatch::quantize(Rect{0.f, 0.f, 1.f, 1.f});
  for (int it = 0; it < iters; ++it) {
    auto t0 = clk::now();
    r.each<P, V>([](Entity, P& p, V& v) { p.p.x += v.v.x * 0.016f; p.p.y += v.v.y * 0.016f; });
    auto t1 = clk::now();
    batch.clear();
    r.each<P, S>([&](Entity, const P& p, const S& s) {
      SpriteDesc d;
      d.texture = 1;
      d.position = p.p;
      d.size = s.size;
      d.color = s.c;
      batch.draw(d);
    });
    auto t2 = clk::now();
    batch.clear();
    auto t3 = clk::now();
    r.each<P, S>([&](Entity, const P& p, const S& s) { batch.draw_quad(1, p.p, s.size, q, s.c); });
    auto t4 = clk::now();
    t_upd += std::chrono::duration<double, std::milli>(t1 - t0).count();
    t_batch += std::chrono::duration<double, std::milli>(t2 - t1).count();
    t_quad += std::chrono::duration<double, std::milli>(t4 - t3).count();
  }
  // stroke bodies: rotated draw() (sin/cos/atan2/sqrt per segment) vs draw_segment()
  double t_rot = 0, t_seg = 0;
  const QuantUv bq = SpriteBatch::quantize(Rect{0.f, 0.f, 1.f, 1.f});
  for (int it = 0; it < iters; ++it) {
    auto t0 = clk::now();
    batch.clear();
    for (u32 i = 1; i < N; ++i) {
      const Vec2 p{float(i % 1280), float(i % 720)}, q2{float((i + 3) % 1280), float((i * 7) % 720)};
      SpriteDesc d;
      d.texture = 1;
      d.position = {(p.x + q2.x) * 0.5f, (p.y + q2.y) * 0.5f};
      d.size = {std::sqrt((p.x - q2.x) * (p.x - q2.x) + (p.y - q2.y) * (p.y - q2.y)), 7.f};
      d.rotation = std::atan2(q2.y - p.y, q2.x - p.x);
      batch.draw(d);
    }
    auto t1 = clk::now();
    batch.clear();
    for (u32 i = 1; i < N; ++i)
      batch.draw_segment(1, {float(i % 1280), float(i % 720)}, {float((i + 3) % 1280), float((i * 7) % 720)}, 7.f, bq, Color{});
    auto t2 = clk::now();
    t_rot += std::chrono::duration<double, std::milli>(t1 - t0).count();
    t_seg += std::chrono::duration<double, std::milli>(t2 - t1).count();
  }
  std::printf("bench %u stroke segments: %.3f ms/frame (rotated draw), %.3f ms/frame (draw_segment)\n", N - 1, t_rot / iters,
              t_seg / iters);
  std::printf("bench %u sprites: update %.3f ms/frame, batch build %.3f ms/frame (draw), %.3f ms/frame (draw_quad)\n", N,
              t_upd / iters, t_batch / iters, t_quad / iters);
}

int main(int argc, char** argv) {
  test_stroke_simplify();
  test_transform();
  test_arena();
  test_ecs();
  test_batch();
  test_flat_and_quad();
  test_segment();
  test_font();
  test_maxrects();
  test_atlas();
  if (g_fail == 0) std::printf("all tests passed\n");
  if (argc > 1 && !std::strcmp(argv[1], "--bench")) bench();
  return g_fail ? 1 : 0;
}
