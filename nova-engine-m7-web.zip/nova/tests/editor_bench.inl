// Included by editor_tests.cpp (--bench). Headless timings of the editor hot paths.
using Clk = std::chrono::steady_clock;
static double ms_since(Clk::time_point t) { return std::chrono::duration<double, std::milli>(Clk::now() - t).count(); }

static void bench_stroke(Editor& ed, f32 ox, f32 oy, int pts, f32 r) {
  ptr(ed, ox + r, oy, true, true, false);
  for (int i = 1; i < pts; ++i) {
    const f32 t = 6.2831853f * static_cast<f32>(i) / static_cast<f32>(pts);
    ptr(ed, ox + r * std::cos(t), oy + r * std::sin(t), false, true, false);
  }
  ptr(ed, ox + r, oy, false, false, true);
}

static void editor_bench() {
  const ui::Assets a = fake_assets();
  for (int N : {500, 5000, 20000}) {
    Editor ed(1.f);
    ed.reset();
    ed.set_tool(Tool::Pen);
    ptr(ed, 0, 0, false, false, false);
    ed.zoom_by(0.2f, W * 0.5f, H * 0.5f, W, H);
    double worst = 0.0;
    auto t0 = Clk::now();
    for (int i = 0; i < N; ++i) {
      auto tc = Clk::now();
      bench_stroke(ed, 40.f + static_cast<f32>(i % 150) * 6.f, 20.f + static_cast<f32>(i / 150) * 6.f, 40, 2.5f);
      worst = std::max(worst, ms_since(tc));
    }
    std::printf("N=%d build=%.0f ms, worst stroke=%.3f ms\n", N, ms_since(t0), worst);
    SpriteBatch b(SpriteBatch::kMaxSprites);
    u32 flushes = 0, total = 0;
    const auto flush = [&] { ++flushes; total += b.sprite_count(); b.clear(); };
    const auto frame = [&](const char* label) {
      flushes = total = 0;
      const int iters = 30;
      auto t = Clk::now();
      for (int i = 0; i < iters; ++i) { b.clear(); ed.draw_canvas(b, a, W, H, flush); total += b.sprite_count(); }
      std::printf("  N=%-6d %-26s %.3f ms/frame, %u sprites/frame, %.1f flushes/frame\n", N, label, ms_since(t) / iters,
                  total / iters, static_cast<double>(flushes) / iters);
    };
    frame("zoom 0.2 (build view)");
    ed.zoom_by(0.5f, W * 0.5f, H * 0.5f, W, H);
    frame("zoom 0.1 (far out)");
    ed.reset_view();
    ed.zoom_by(8.f, W * 0.5f, H * 0.5f, W, H);
    frame("zoom 8 (few visible)");
    auto tu = Clk::now();
    for (int i = 0; i < 20; ++i) ed.undo();
    std::printf("  N=%-6d undo x20 %.3f ms\n", N, ms_since(tu));
  }
  // one huge scribble, partly on screen
  Editor g(1.f);
  g.reset(); g.set_tool(Tool::Pen); g.toggle_grid();
  ptr(g, 0, 0, false, false, false);
  ptr(g, 0, 360, true, true, false);
  for (int i = 1; i <= 20000; ++i) ptr(g, static_cast<f32>(i) * 0.25f, 360.f + 150.f * std::sin(static_cast<f32>(i) * 0.01f), false, true, false);
  ptr(g, 5000, 360, false, false, true);
  g.zoom_by(10.f, 40.f, 360.f, W, H);
  SpriteBatch b(SpriteBatch::kMaxSprites);
  auto t = Clk::now();
  for (int i = 0; i < 100; ++i) { b.clear(); g.draw_canvas(b, a, W, H, [&] { b.clear(); }); }
  std::printf("long scribble, zoomed in: %.3f ms/frame, %u sprites\n", ms_since(t) / 100, b.sprite_count());
}
