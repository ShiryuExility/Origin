// Editor tests: no SDL, no GL. Drives Editor through its public API. `--bench` prints timings.
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

#include "sandbox/editor.hpp"
#include "sandbox/history.hpp"
#include "sandbox/project.hpp"
#include "sandbox/theme.hpp"

using namespace nv;

static int g_fail = 0;
#define CHECK(c)                                                  \
  do {                                                            \
    if (!(c)) {                                                   \
      std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #c);    \
      ++g_fail;                                                   \
    }                                                             \
  } while (0)

static constexpr f32 W = 1280.f, H = 720.f;

static ui::Assets fake_assets() {
  ui::Assets a;
  a.atlas = 1;
  for (auto& r : a.uv) r = {0.1f, 0.1f, 0.05f, 0.05f};
  a.white = {0.5f, 0.5f, 0.01f, 0.01f};
  a.white_q = SpriteBatch::quantize(a.white);
  a.ellipse = 2;
  return a;
}

// One pointer frame helper.
static void ptr(Editor& e, f32 x, f32 y, bool pressed, bool down, bool released, const Vec2* trail = nullptr, int n = 0) {
  Pointer p;
  p.x = x; p.y = y; p.pressed = pressed; p.down = down; p.released = released;
  for (int i = 0; i < n; ++i) p.trail[i] = trail[i];
  p.trail_n = static_cast<u8>(n);
  e.update(p, W, H, false);
}
static void drag(Editor& e, Vec2 from, Vec2 to) {
  ptr(e, from.x, from.y, true, true, false);
  ptr(e, (from.x + to.x) * 0.5f, (from.y + to.y) * 0.5f, false, true, false);
  ptr(e, to.x, to.y, false, true, false);
  ptr(e, to.x, to.y, false, false, true);
}

static void click(Editor& e, f32 x, f32 y) {  // select-tool click (press + release in place)
  ptr(e, x, y, true, true, false);
  ptr(e, x, y, false, false, true);
}

static Obj make_box(f32 x0, f32 y0, f32 x1, f32 y1) {
  Shape2D s;
  s.kind = Shape2D::Box; s.a = {x0, y0}; s.b = {x1, y1}; s.color = {10, 20, 30, 255};
  compute_bounds(s);
  return std::make_shared<const Shape2D>(std::move(s));
}

static void test_history() {
  Doc d;
  History h;
  Obj a = make_box(0, 0, 1, 1), b = make_box(2, 2, 3, 3), c = make_box(4, 4, 5, 5), n = make_box(9, 9, 10, 10);
  h.begin(); h.insert(d, 0, a);
  h.begin(); h.insert(d, 1, b);
  h.begin(); h.insert(d, 2, c);
  CHECK(d.size() == 3 && d[2] == c);
  h.begin(); h.move(d, 0, 2);                    // a to the top: b c a
  CHECK(d[0] == b && d[1] == c && d[2] == a);
  h.begin(); h.replace(d, 1, n);                 // b n a
  h.begin(); h.erase(d, 0); h.erase(d, 0);       // one step, two erases: a
  CHECK(d.size() == 1 && d[0] == a);
  CHECK(h.undo(d) && d.size() == 3 && d[0] == b && d[1] == n && d[2] == a);  // both erases come back together
  CHECK(h.undo(d) && d[1] == c);
  CHECK(h.undo(d) && d[0] == a && d[1] == b && d[2] == c);
  CHECK(h.undo(d) && h.undo(d) && h.undo(d) && d.empty());
  CHECK(!h.undo(d));
  CHECK(h.redo(d) && h.redo(d) && h.redo(d) && d[2] == c);
  CHECK(h.redo(d) && d[0] == b && d[2] == a);  // the move
  CHECK(h.redo(d) && d[1] == n);
  CHECK(h.redo(d) && d.size() == 1 && d[0] == a);
  CHECK(!h.redo(d));
  h.undo(d);
  h.begin(); h.insert(d, 0, c);                  // a new edit drops redo
  CHECK(h.redo_steps() == 0);
  // depth limit
  History deep; Doc dd;
  for (int i = 0; i < 250; ++i) { deep.begin(); deep.insert(dd, dd.size(), a); }
  CHECK(deep.undo_steps() == History::kMaxSteps);
  int undone = 0;
  while (deep.undo(dd)) ++undone;
  CHECK(undone == static_cast<int>(History::kMaxSteps) && dd.size() == 250 - History::kMaxSteps);
  // move backwards and forwards round-trips
  Doc m{a, b, c, n}; History hm;
  hm.begin(); hm.move(m, 3, 0);
  CHECK(m[0] == n && m[1] == a && m[3] == c);
  hm.undo(m);
  CHECK(m[0] == a && m[1] == b && m[2] == c && m[3] == n);
}

static std::vector<u8> sample_project(Doc& out) {
  Shape2D st;
  st.kind = Shape2D::Stroke; st.color = {1, 2, 3, 4}; st.width = 7.f;
  st.pts = {{0, 0}, {5, 5}, {10, 2.5f}};
  compute_bounds(st);
  out.push_back(std::make_shared<const Shape2D>(st));
  out.push_back(make_box(-5, -6, 20, 30));
  Shape2D ln; ln.kind = Shape2D::Line; ln.a = {1, 1}; ln.b = {9, 9}; ln.width = 3.f; compute_bounds(ln);
  out.push_back(std::make_shared<const Shape2D>(ln));
  Shape2D ov; ov.kind = Shape2D::Oval; ov.a = {0, 0}; ov.b = {40, 20}; ov.rot = 0.5f; compute_bounds(ov);
  out.push_back(std::make_shared<const Shape2D>(ov));
  return serialize_project(out, {12.f, -7.f}, 2.5f);
}

static void test_project() {
  Doc src;
  const std::vector<u8> bytes = sample_project(src);
  const auto p = parse_project(bytes);
  CHECK(p.has_value());
  if (p) {
    CHECK(p->shapes.size() == 4 && p->cam.x == 12.f && p->cam.y == -7.f && p->zoom == 2.5f);
    for (std::size_t i = 0; i < src.size() && i < p->shapes.size(); ++i) {
      const Shape2D &x = *src[i], &y = *p->shapes[i];
      CHECK(x.kind == y.kind && x.width == y.width && x.rot == y.rot && x.a.x == y.a.x && x.b.y == y.b.y);
      CHECK(x.pts.size() == y.pts.size() && std::memcmp(&x.color, &y.color, 4) == 0);
      CHECK(x.bounds.x == y.bounds.x && x.bounds.w == y.bounds.w && x.bounds.h == y.bounds.h);  // rebuilt, identical
    }
  }
  CHECK(!parse_project({}));
  // every truncation is rejected, never a crash
  for (std::size_t n = 0; n < bytes.size(); ++n) CHECK(!parse_project(std::span<const u8>(bytes.data(), n)));
  // every single flipped bit is caught by the checksum or the validation
  int accepted = 0;
  for (std::size_t i = 0; i < bytes.size(); ++i) {
    std::vector<u8> bad = bytes;
    bad[i] ^= 0x10;
    if (parse_project(bad)) ++accepted;
  }
  CHECK(accepted == 0);
  // a hostile file with a valid checksum but absurd counts / NaN must still be refused without allocating
  auto forge = [&](auto mutate) {
    std::vector<u8> v = bytes;
    mutate(v);
    u32 h = 2166136261u;
    for (std::size_t i = 0; i + 4 < v.size(); ++i) { h ^= v[i]; h *= 16777619u; }
    std::memcpy(v.data() + v.size() - 4, &h, 4);
    return parse_project(v).has_value();
  };
  CHECK(!forge([](std::vector<u8>& v) { const u32 big = 0x7fffffff; std::memcpy(v.data() + 8, &big, 4); }));   // object count
  CHECK(!forge([](std::vector<u8>& v) { const f32 nan = std::nanf(""); std::memcpy(v.data() + 12, &nan, 4); }));  // camera NaN
  CHECK(!forge([](std::vector<u8>& v) { const u32 z = 99; std::memcpy(v.data() + 4, &z, 4); }));              // version
  CHECK(!forge([](std::vector<u8>& v) { v[24] = 9; }));                                                         // shape kind
  CHECK(forge([](std::vector<u8>&) {}));                                                                      // control: untouched passes
}

static void test_editor_features() {
  Editor e(1.f);
  e.reset();
  e.set_tool(Tool::Rect);
  ptr(e, 0, 0, false, false, false);                // size known
  drag(e, {100, 100}, {200, 180});                  // A
  drag(e, {300, 100}, {400, 180});                  // B
  drag(e, {500, 100}, {600, 180});                  // C
  CHECK(e.object_count() == 3);

  // select B and send it to the back, then front, undo each
  e.set_tool(Tool::Select);
  const auto b0 = e.save_project();
  click(e, 350, 140);
  e.send_to_back();
  const auto b1 = e.save_project();
  CHECK(b1 != b0);                                  // B moved from the middle to the bottom
  e.undo();                                         // (undo / redo clear the selection, like any edit that replaces the doc)
  CHECK(e.save_project() == b0);
  e.redo();
  CHECK(e.save_project() == b1);
  click(e, 350, 140);
  e.bring_to_front();
  CHECK(e.save_project() != b1 && e.save_project() != b0);
  e.undo(); e.undo();
  CHECK(e.save_project() == b0);
  CHECK(e.object_count() == 3);

  // duplicate: one more object, selected, undoable
  click(e, 350, 140);
  e.duplicate_selection();
  CHECK(e.object_count() == 4);
  e.undo();
  CHECK(e.object_count() == 3);
  e.redo();
  CHECK(e.object_count() == 4);

  // delete + undo (the duplicate sits on top of B and is the selected one)
  click(e, 350, 140);
  e.delete_selection();
  const u32 after_delete = e.object_count();
  CHECK(after_delete == 3 || after_delete == 4);   // the point may hit the copy or the original
  e.undo();
  CHECK(e.object_count() == after_delete + 1);

  // zoom to fit frames everything
  e.reset_view();
  e.zoom_to_fit();
  const Camera2D cam = e.camera();
  // world (0,0) is the window center at the reset view: the boxes span world x -540..-40 (+16 for the copy)
  const f32 left = (-540.f - cam.position.x) * cam.zoom + W * 0.5f, right = (-20.f - cam.position.x) * cam.zoom + W * 0.5f;
  CHECK(left >= 0.f && right <= W && right - left > W * 0.5f);

  // save -> load round trip into a fresh editor reproduces the drawing exactly
  const auto saved = e.save_project();
  Editor f(1.f);
  CHECK(f.load_project(saved));
  CHECK(f.object_count() == e.object_count() && f.save_project() == saved);
  CHECK(!f.load_project(std::span<const u8>(saved.data(), saved.size() - 3)));
  CHECK(f.save_project() == saved);                 // a bad file changed nothing
  f.undo();                                         // a freshly loaded document has no undo history
  CHECK(f.object_count() == e.object_count());
}

static void test_trail() {
  // Same pointer path, once with only the final position per frame, once with the device's intermediate samples.
  auto run = [](bool with_trail) {
    Editor e(1.f);
    e.reset();
    e.set_tool(Tool::Pen);
    ptr(e, 100, 100, true, true, false);
    for (int frame = 0; frame < 10; ++frame) {
      Vec2 tr[8];
      for (int k = 0; k < 8; ++k) {  // fast diagonal-then-curving path: 8 samples per frame
        const f32 t = static_cast<f32>(frame * 8 + k);
        tr[k] = {100.f + t * 6.f, 100.f + 80.f * std::sin(t * 0.15f)};
      }
      ptr(e, tr[7].x, tr[7].y, false, true, false, with_trail ? tr : nullptr, with_trail ? 8 : 0);
    }
    ptr(e, 100.f + 79.f * 6.f, 100.f + 80.f * std::sin(79.f * 0.15f), false, false, true);
    return e.save_project();
  };
  const auto coarse = run(false), fine = run(true);
  const auto pc = parse_project(coarse), pf = parse_project(fine);
  CHECK(pc && pf && pc->shapes.size() == 1 && pf->shapes.size() == 1);
  if (pc && pf) {
    // simplification removes redundant points, but the curve sampled 8x finer must keep more of its shape
    CHECK(pf->shapes[0]->pts.size() > pc->shapes[0]->pts.size());
    // and the points are in drawing order (x never goes backwards on this path)
    bool ordered = true;
    for (std::size_t i = 1; i < pf->shapes[0]->pts.size(); ++i)
      if (pf->shapes[0]->pts[i].x < pf->shapes[0]->pts[i - 1].x) ordered = false;
    CHECK(ordered);
  }
}

// Draws the canvas and returns the set of covered 1-px cells (rasterizing the emitted quads) to compare renderings.
static std::size_t sprites_of(const Editor& e, const ui::Assets& a) {
  SpriteBatch b(SpriteBatch::kMaxSprites);
  e.draw_canvas(b, a, W, H, [&] { b.clear(); });
  return b.sprite_count();
}

static void test_draw_paths() {
  const ui::Assets a = fake_assets();
  // LOD: 400 tiny strokes viewed far out collapse to about one sprite each
  Editor e(1.f);
  e.reset();
  e.set_tool(Tool::Pen);
  ptr(e, 0, 0, false, false, false);
  for (int i = 0; i < 400; ++i) {
    const f32 x = 40.f + static_cast<f32>(i % 40) * 20.f, y = 40.f + static_cast<f32>(i / 40) * 20.f;
    ptr(e, x, y, true, true, false);
    for (int k = 1; k <= 6; ++k) ptr(e, x + static_cast<f32>(k) * 2.f, y + static_cast<f32>(k % 3), false, true, false);
    ptr(e, x + 12.f, y, false, false, true);
  }
  CHECK(e.object_count() == 400);
  e.zoom_by(0.05f, W * 0.5f, H * 0.5f, W, H);  // clamps at the 5% minimum zoom: each stroke is about 1 px
  const std::size_t far = sprites_of(e, a);
  CHECK(far < 400 * 3 + 80);                   // grid sprites + one dot per stroke, not dozens per stroke
  e.reset_view();
  CHECK(sprites_of(e, a) > 0);

  // Segment culling: a long scribble zoomed in submits far fewer sprites than it has points, and nothing when off screen
  Editor g(1.f);
  g.reset();
  g.set_tool(Tool::Pen);
  ptr(g, 0, 0, false, false, false);
  ptr(g, 0, 360, true, true, false);
  for (int i = 1; i <= 1200; ++i) ptr(g, static_cast<f32>(i), 360.f + 150.f * std::sin(static_cast<f32>(i) * 0.05f), false, true, false);
  ptr(g, 1200, 360, false, false, true);
  CHECK(g.object_count() == 1);
  g.toggle_grid();                             // off: count only the stroke
  g.set_tool(Tool::Hand);                      // and no brush cursor
  const std::size_t whole = sprites_of(g, a);
  g.zoom_by(12.f, 40.f, 360.f, W, H);          // zoom into the left end: most of the stroke is now off screen
  const std::size_t part = sprites_of(g, a);
  CHECK(whole > 100 && part > 0 && part * 10 < whole);
  g.pan_pixels(1.0e6f, 0.f);                   // far away: object culled entirely
  CHECK(sprites_of(g, a) == 0);
}


static u32 test_fnv(const std::vector<u8>& v) {
  u32 h = 2166136261u;
  for (const u8 b : v) { h ^= b; h *= 16777619u; }
  return h;
}

template <class T> static void put_raw(std::vector<u8>& out, T v) {
  const std::size_t at = out.size();
  out.resize(at + sizeof(T));
  std::memcpy(out.data() + at, &v, sizeof(T));
}

static void test_scripts() {
  // script round trip, and a version 1 file (no scripts) still opens
  Shape2D bx; bx.kind = Shape2D::Box; bx.a = {0, 0}; bx.b = {10, 10}; bx.script = "let a = 1;\nif (a) { go(); }\n";
  compute_bounds(bx);
  Doc d{std::make_shared<const Shape2D>(bx)};
  const auto bytes = serialize_project(d, {0, 0}, 1.f);
  const auto p = parse_project(bytes);
  CHECK(p && p->shapes.size() == 1 && p->shapes[0]->script == bx.script);

  std::vector<u8> v1 = {'N', 'V', 'P', 'R'};
  put_raw<u32>(v1, 1); put_raw<u32>(v1, 1);
  put_raw<f32>(v1, 0.f); put_raw<f32>(v1, 0.f); put_raw<f32>(v1, 1.f);
  put_raw<u8>(v1, static_cast<u8>(Shape2D::Box));
  for (int i = 0; i < 4; ++i) put_raw<u8>(v1, 200);
  put_raw<f32>(v1, 4.f);
  put_raw<f32>(v1, 0.f); put_raw<f32>(v1, 0.f); put_raw<f32>(v1, 8.f); put_raw<f32>(v1, 6.f);
  put_raw<f32>(v1, 0.f); put_raw<u32>(v1, 0);
  put_raw<u32>(v1, test_fnv(v1));
  const auto old = parse_project(v1);
  CHECK(old && old->shapes.size() == 1 && old->shapes[0]->script.empty() && old->shapes[0]->b.x == 8.f);

  // a script with bytes the editor can never produce is refused
  Shape2D bad = bx; bad.script = std::string("ab") + '\x01' + "cd";
  Doc bd{std::make_shared<const Shape2D>(bad)};
  CHECK(!parse_project(serialize_project(bd, {0, 0}, 1.f)));
  // every truncation of a v2 file with a script is refused
  for (std::size_t n = 0; n < bytes.size(); ++n) CHECK(!parse_project(std::span<const u8>(bytes.data(), n)));

  // editor: open / edit / apply = one undo step; cancel changes nothing; the canvas is locked meanwhile
  Editor e(1.f);
  e.reset();
  e.set_tool(Tool::Rect);
  ptr(e, 0, 0, false, false, false);
  drag(e, {500, 300}, {700, 420});
  e.set_tool(Tool::Select);
  e.open_code();
  CHECK(!e.code_open());                       // nothing selected yet
  click(e, 600, 360);
  e.open_code();
  CHECK(e.code_open());
  e.code().buffer().insert("let a = 1;");
  e.set_tool(Tool::Pen);                       // locked while the code screen is open
  e.delete_selection();
  e.undo();
  CHECK(e.object_count() == 1);
  e.close_code(false);                         // cancel: nothing stored
  CHECK(!e.code_open());
  auto saved = parse_project(e.save_project());
  CHECK(saved && saved->shapes[0]->script.empty());
  CHECK(e.tool() == Tool::Select);

  e.open_code();
  e.code().buffer().insert("let a = 1;");
  e.close_code(true);
  saved = parse_project(e.save_project());
  CHECK(saved && saved->shapes[0]->script == "let a = 1;");
  e.open_code();                               // reopening shows the stored text; unchanged apply adds no undo step
  CHECK(e.code().text() == "let a = 1;");
  e.close_code(true);
  e.duplicate_selection();                     // a copy keeps the script
  saved = parse_project(e.save_project());
  CHECK(saved && saved->shapes.size() == 2 && saved->shapes[1]->script == "let a = 1;");
  e.undo();                                    // the duplicate
  e.undo();                                    // the script
  saved = parse_project(e.save_project());
  CHECK(saved && saved->shapes.size() == 1 && saved->shapes[0]->script.empty());
  e.redo();
  saved = parse_project(e.save_project());
  CHECK(saved && saved->shapes[0]->script == "let a = 1;");
}

static void test_rotate_tool() {
  Editor e(1.f);
  e.reset();
  e.set_tool(Tool::Rect);
  ptr(e, 0, 0, false, false, false);
  drag(e, {500, 300}, {700, 420});             // center (600, 360)
  e.set_tool(Tool::Select);
  click(e, 600, 360);                          // select it
  e.set_tool(Tool::Rotate);                    // the selection survives the tool change
  CHECK(e.tool() == Tool::Rotate);
  const auto p0 = parse_project(e.save_project());
  drag(e, {700, 360}, {600, 460});             // from "3 o'clock" to "6 o'clock": a quarter turn clockwise
  auto p = parse_project(e.save_project());
  CHECK(p && p->shapes.size() == 1);
  if (p && !p->shapes.empty()) {
    const Shape2D& s = *p->shapes[0];
    CHECK(s.kind == Shape2D::Box && std::fabs(s.rot - 1.5707964f) < 1e-3f);
    const Rect& b0 = p0->shapes[0]->bounds;  // a quarter turn swaps width and height and keeps the center
    CHECK(std::fabs(s.bounds.w - b0.h) < 0.5f && std::fabs(s.bounds.h - b0.w) < 0.5f);
    CHECK(std::fabs((s.bounds.x + s.bounds.w * 0.5f) - (b0.x + b0.w * 0.5f)) < 0.5f);
    CHECK(std::fabs((s.bounds.y + s.bounds.h * 0.5f) - (b0.y + b0.h * 0.5f)) < 0.5f);
  }
  e.undo();                                    // one step
  p = parse_project(e.save_project());
  CHECK(p && std::fabs(p->shapes[0]->rot) < 1e-6f);
  e.redo();

  // pressing on the pivot and moving a little does nothing (the angle is meaningless there)
  const auto before = e.save_project();
  click(e, 600, 360);                          // select again (undo / redo clear the selection)
  drag(e, {601, 361}, {606, 361});
  CHECK(e.save_project() == before);

  // a tap on empty space deselects: the code editor then has nothing to open
  click(e, 100, 100);
  e.open_code();
  CHECK(!e.code_open());
  // the tool bar in Select mode is unaffected: switching to Pen drops the selection as before
  click(e, 600, 360);
  e.set_tool(Tool::Pen);
  e.open_code();
  CHECK(!e.code_open());
}


static void test_split_tools() {
  Editor e(1.f);
  e.reset();
  e.set_tool(Tool::Rect);
  ptr(e, 0, 0, false, false, false);
  drag(e, {500, 300}, {700, 420});             // box 200 x 120, center (600, 360)
  e.set_tool(Tool::Select);
  click(e, 600, 360);
  const auto before = e.save_project();
  const auto p0 = parse_project(before);
  CHECK(p0 && p0->shapes.size() == 1);

  // Select only picks: dragging the body, a corner or the old rotate-handle spot changes nothing
  drag(e, {600, 360}, {640, 400});
  CHECK(e.save_project() == before);
  click(e, 600, 360);
  drag(e, {704, 424}, {764, 454});
  CHECK(e.save_project() == before);
  click(e, 600, 360);
  drag(e, {600, 266}, {720, 280});
  CHECK(e.save_project() == before);

  // Move moves, and only that
  click(e, 600, 360);
  e.set_tool(Tool::Move);
  drag(e, {600, 360}, {640, 400});
  auto p1 = parse_project(e.save_project());
  CHECK(p1 && std::fabs(p1->shapes[0]->a.x - (p0->shapes[0]->a.x + 40.f)) < 0.5f);
  CHECK(p1 && std::fabs(p1->shapes[0]->b.x - p1->shapes[0]->a.x - (p0->shapes[0]->b.x - p0->shapes[0]->a.x)) < 0.01f);  // same size
  CHECK(p1 && p1->shapes[0]->rot == p0->shapes[0]->rot);
  e.undo();
  CHECK(e.save_project() == before);
  e.set_tool(Tool::Select);
  click(e, 600, 360);
  e.set_tool(Tool::Move);
  drag(e, {100, 100}, {200, 200});             // an empty spot outside the box: nothing moves, the selection stays
  CHECK(e.save_project() == before);
  e.open_code();
  CHECK(e.code_open());
  e.close_code(false);

  // Scale resizes through its handles, and only that
  e.set_tool(Tool::Scale);
  drag(e, {600, 360}, {640, 400});             // dragging the body does not move it
  CHECK(e.save_project() == before);
  drag(e, {704, 424}, {764, 454});             // the south-east corner handle
  const auto p2 = parse_project(e.save_project());
  CHECK(p2 && p2->shapes[0]->bounds.w > p0->shapes[0]->bounds.w + 20.f && p2->shapes[0]->bounds.h > p0->shapes[0]->bounds.h + 10.f);
  CHECK(p2 && std::fabs(p2->shapes[0]->a.x - p0->shapes[0]->a.x) < 0.5f);  // the opposite corner stays put
  e.undo();
  CHECK(e.save_project() == before);

  // the selection survives the switches between the selection tools
  e.set_tool(Tool::Select);
  click(e, 600, 360);
  e.set_tool(Tool::Move);
  e.set_tool(Tool::Scale);
  e.set_tool(Tool::Rotate);
  e.open_code();
  CHECK(e.code_open());
  e.close_code(false);
}

#include "tests/editor_bench.inl"

int main(int argc, char** argv) {
  test_history();
  test_project();
  test_editor_features();
  test_trail();
  test_draw_paths();
  test_scripts();
  test_rotate_tool();
  test_split_tools();
  if (g_fail) { std::printf("%d check(s) failed\n", g_fail); return 1; }
  std::printf("editor tests passed\n");
  if (argc > 1 && !std::strcmp(argv[1], "--bench")) editor_bench();
  return 0;
}
