// Code editor logic tests: TextBuffer, syntax highlighting, edit events. No SDL, no GL.
#include <cstdio>
#include <string>

#include "sandbox/edit_events.hpp"
#include "sandbox/highlight.hpp"
#include "sandbox/text_buffer.hpp"

using namespace nv;

static int g_fail = 0;
#define CHECK(c)                                               \
  do {                                                         \
    if (!(c)) {                                                \
      std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); \
      ++g_fail;                                                \
    }                                                          \
  } while (0)

static void typed(TextBuffer& b, const char* s) {
  for (const char* p = s; *p; ++p) b.type(*p);
}

static void test_basic_editing() {
  TextBuffer b;
  CHECK(b.str().empty() && b.line_count() == 1);
  typed(b, "let x = 1;");
  CHECK(b.str() == "let x = 1;" && b.cursor() == 10);
  b.backspace();
  CHECK(b.str() == "let x = 1");
  b.left(false, false);
  b.left(false, false);
  b.type('2');
  CHECK(b.str() == "let x =2 1");  // inserted before the two chars we stepped over
  b.home(false, false);
  b.del();
  CHECK(b.str() == "et x =2 1");
  // sanitize: tab -> two spaces, CR and non-ASCII dropped
  TextBuffer s;
  s.set("a\tb\r\n\xC3\xA9z");
  CHECK(s.str() == "a  b\nz");
  CHECK(s.cursor() == s.size());
  // size cap
  TextBuffer big;
  big.set(std::string(TextBuffer::kMaxBytes + 100, 'x'));
  CHECK(big.size() == TextBuffer::kMaxBytes);
  big.type('y');
  CHECK(big.size() == TextBuffer::kMaxBytes);
  big.insert("abc");
  CHECK(big.size() == TextBuffer::kMaxBytes);
}

static void test_lines_and_cursor() {
  TextBuffer b;
  b.set("one\ntwo\n\nfour");
  CHECK(b.line_count() == 4);
  CHECK(b.line(0) == "one" && b.line(1) == "two" && b.line(2).empty() && b.line(3) == "four");
  CHECK(b.line_of(0) == 0 && b.line_of(3) == 0 && b.line_of(4) == 1 && b.line_of(8) == 2 && b.line_of(b.size()) == 3);
  b.move_to(6, false);  // "tw|o"
  CHECK(b.line_of(b.cursor()) == 1 && b.col_of(b.cursor()) == 2);
  b.down(false);        // empty line: clamps to column 0
  CHECK(b.cursor() == 8);
  b.down(false);        // goal column (2) is remembered across the short line
  CHECK(b.cursor() == 11);
  b.up(false);
  b.up(false);
  b.up(false);
  CHECK(b.line_of(b.cursor()) == 0 && b.col_of(b.cursor()) == 2);
  b.up(false);          // first line: jumps to the start
  CHECK(b.cursor() == 0);
  b.end(false, true);
  CHECK(b.cursor() == b.size());
  b.page(-100, false);
  CHECK(b.cursor() == 0);
  // smart home: first word, then column 0
  b.set("    indented");
  b.home(false, false);
  CHECK(b.cursor() == 4);
  b.home(false, false);
  CHECK(b.cursor() == 0);
  b.end(false, false);
  CHECK(b.cursor() == b.size());
}

static void test_selection_and_words() {
  TextBuffer b;
  b.set("foo bar_baz  qux");
  b.move_to(0, false);
  b.right(false, true);
  CHECK(b.cursor() == 3);
  b.right(false, true);
  CHECK(b.cursor() == 11);  // bar_baz is one word
  b.left(false, true);
  CHECK(b.cursor() == 4);
  b.move_to(0, false);
  b.right(true, false);
  b.right(true, false);
  CHECK(b.has_selection() && b.selected() == "fo");
  b.type('X');  // typing replaces the selection
  CHECK(b.str() == "Xo bar_baz  qux" && !b.has_selection());
  b.select_all();
  CHECK(b.selected() == b.str());
  b.backspace();
  CHECK(b.str().empty());
  // collapse: left / right with a selection jump to its edges
  b.set("abcdef");
  b.move_to(2, false);
  b.right(true, false);
  b.right(true, false);
  b.left(false, false);
  CHECK(b.cursor() == 2 && !b.has_selection());
  // word backspace
  b.set("hello world");
  b.backspace(true);
  CHECK(b.str() == "hello ");
}

static void test_newline_indent() {
  TextBuffer b;
  b.set("  foo");
  b.newline();
  CHECK(b.str() == "  foo\n  ");
  b.set("if (x) {");
  b.newline();
  CHECK(b.str() == "if (x) {\n  ");
  // empty pair is split and the caret lands on the indented middle line
  b.set("{}");
  b.move_to(1, false);
  b.newline();
  CHECK(b.str() == "{\n  \n}" && b.cursor() == 4);
  b.set("a");
  b.tab();
  CHECK(b.str() == "a  ");
  b.outdent();
  CHECK(b.str() == "a  ");  // "a" is not indented: nothing to remove
  b.set("    x");
  b.move_to(5, false);
  b.outdent();
  CHECK(b.str() == "  x" && b.cursor() == 3);
}

static void test_undo() {
  TextBuffer b;
  typed(b, "hello");   // one typing run = one step
  b.type(' ');
  typed(b, "world");
  CHECK(b.str() == "hello world");
  CHECK(b.undo());
  CHECK(b.str() == "hello ");
  CHECK(b.undo());
  CHECK(b.str() == "hello");
  CHECK(b.undo());
  CHECK(b.str().empty() && !b.can_undo());
  CHECK(b.redo() && b.str() == "hello");
  CHECK(b.redo() && b.str() == "hello ");
  b.type('x');  // a new edit drops redo
  CHECK(!b.can_redo());
  // moving the cursor ends a typing run
  b.set("");
  typed(b, "ab");
  b.left(false, false);
  typed(b, "cd");
  b.undo();
  CHECK(b.str() == "ab");
  // history is bounded
  b.set("");
  for (int i = 0; i < 300; ++i) { b.type(' '); }
  std::size_t steps = 0;
  while (b.undo()) ++steps;
  CHECK(steps == TextBuffer::kMaxUndo);
  // cut then undo
  b.set("abc");
  b.select_all();
  b.delete_selection();
  CHECK(b.str().empty());
  b.undo();
  CHECK(b.str() == "abc");
}

static void test_highlight() {
  Tok t[64];
  bool block = false;
  const std::string_view l1 = "let n = 42; // hi";
  highlight_line(l1, block, t);
  CHECK(t[0] == Tok::Keyword && t[2] == Tok::Keyword && t[3] == Tok::Plain && t[4] == Tok::Plain);
  CHECK(t[8] == Tok::Number && t[9] == Tok::Number && t[10] == Tok::Punct);
  CHECK(t[12] == Tok::Comment && t[16] == Tok::Comment && !block);
  highlight_line("say(\"a\\\"b\") + 'c'", block, t);
  CHECK(t[0] == Tok::Plain && t[3] == Tok::Punct && t[4] == Tok::String && t[9] == Tok::String && t[10] == Tok::Punct);
  const std::string_view l3 = "x /* a";
  highlight_line(l3, block, t);
  CHECK(block && t[2] == Tok::Comment && t[5] == Tok::Comment);
  highlight_line("still */ ok", block, t);  // the comment ends mid-line
  CHECK(!block && t[0] == Tok::Comment && t[7] == Tok::Comment && t[9] == Tok::Plain);
  highlight_line("letter returns", block, nullptr);  // identifiers that merely start with a keyword
  highlight_line("letter returns", block, t);
  CHECK(t[0] == Tok::Plain && t[7] == Tok::Plain);
  highlight_line("\"open string", block, t);  // unterminated: runs to the end of the line, no overflow
  CHECK(t[11] == Tok::String && !block);
}

static void test_events() {
  TextBuffer b;
  std::string clip;
  const auto ev = [&](EditEvent::Kind k, char ch = 0, bool shift = false, bool ctrl = false, std::string_view paste = {}) {
    EditEvent e;
    e.kind = k; e.ch = ch; e.shift = shift; e.ctrl = ctrl;
    return apply_edit(b, e, clip, paste);
  };
  ev(EditEvent::Char, 'a');
  ev(EditEvent::Char, 'b');
  ev(EditEvent::Enter);
  ev(EditEvent::Char, 'c');
  CHECK(b.str() == "ab\nc");
  ev(EditEvent::SelectAll);
  CHECK(ev(EditEvent::Copy) && clip == "ab\nc");
  ev(EditEvent::Right);  // collapses to the end
  ev(EditEvent::Paste);  // own clipboard
  CHECK(b.str() == "ab\ncab\nc");
  ev(EditEvent::Paste, 0, false, false, "ZZ");  // system clipboard wins
  CHECK(b.str() == "ab\ncab\ncZZ");
  ev(EditEvent::SelectAll);
  CHECK(ev(EditEvent::Cut) && b.str().empty() && clip == "ab\ncab\ncZZ");
  ev(EditEvent::Undo);
  CHECK(b.str() == "ab\ncab\ncZZ");
  ev(EditEvent::Redo);
  CHECK(b.str().empty());
  CHECK(!ev(EditEvent::Copy));  // nothing selected: clipboard untouched
  CHECK(clip == "ab\ncab\ncZZ");
  EditQueue q;
  for (int i = 0; i < EditQueue::kMax + 5; ++i) q.push(EditEvent{});
  CHECK(q.n == EditQueue::kMax);
  q.clear();
  CHECK(q.n == 0);
}

int main() {
  test_basic_editing();
  test_lines_and_cursor();
  test_selection_and_words();
  test_newline_indent();
  test_undo();
  test_highlight();
  test_events();
  if (g_fail) { std::printf("%d check(s) failed\n", g_fail); return 1; }
  std::printf("text tests passed\n");
  return 0;
}
