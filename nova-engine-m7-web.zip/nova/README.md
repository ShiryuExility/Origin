# Nova (working name)

2D engine, C++23, built for phones first and PC second. Runs native (desktop, Android) and in the browser
(WebAssembly + WebGL 2) from the same C++ sources.

## Layout
- `src/core`    types, `LinearArena` (no per-frame malloc), sparse-set ECS
- `src/render`  `SpriteBatch` (backend-agnostic), `IRenderer`, GLES 3.0 backend, `atlas` (MaxRects packer), `font` (stb_truetype -> atlas -> sprites)
- `src/sandbox` lobby + editor app (obsidian + silver, flat colors), one job per file:
                `main.cpp` screens + frame loop, `input.cpp` SDL events and editor shortcuts,
                `menu.cpp` lobby + settings screens and the grain backdrop,
                `editor.cpp` canvas, tools, undo, pan/zoom; `editor_chrome.cpp` floating UI (rail, color dock + picker, zoom);
                `editor_internal.hpp` helpers they share, `shape.hpp` the drawn-object struct, `transform.hpp` move / rotate / scale math and
                `stroke.hpp` pen-stroke simplification (both header-only, tested),
                `history.hpp` delta undo / redo (header-only, tested), `project.cpp` project file format (SDL-free, tested),
                `project_io.cpp` reads / writes it in the pref folder,
                `ui.cpp` immediate-mode widgets, `ui_assets.cpp` atlas + fonts the widgets draw with,
                `settings.cpp` saved prefs, `theme.cpp` palette + procedural textures
- `src/sandbox/text_buffer.hpp`, `highlight.hpp`, `edit_events.hpp` code editor logic (text, undo, syntax colors, key events): header-only, unit-tested
- `src/sandbox/code_editor.*` the code screen: text area, toolbar, on-screen keyboard
- `src/sandbox/platform.*` the only desktop / Android / browser differences: pref folder, IndexedDB flush, canvas-to-page sizing
- `web/shell.html` page that hosts the canvas for the browser build (mounts IndexedDB at `/persist`); no game logic in it
- `.github/workflows/web.yml` builds the browser version and publishes it to GitHub Pages (phone testing without a toolchain)
- `assets/fonts` Inter Display Light / Inter Medium (ASCII subset, SIL OFL, license included)
- `tests`       dependency-free tests + `--bench`

## Build (PC)
    cmake -B build && cmake --build build -j
    ./build/nova_sandbox            # OpenGL ES 3.0 context
    ctest --test-dir build

Editor logic without SDL / GL (history, project files, tools, culling): `./build/nv_editor_tests` (`--bench` prints timings).

Core only (no SDL): `g++ -std=c++23 -O2 -Isrc tests/core_tests.cpp src/render/sprite_batch.cpp src/render/atlas.cpp src/render/font.cpp src/third_party/stb_impl.cpp`

The build copies `assets/` next to `nova_sandbox`; run it from anywhere.
`./nova_sandbox --live` never sleeps when idle (renders every vsync): use it when measuring FPS.

## Lobby and editor
Create opens a blank canvas straight away (no template picker), Settings (stats HUD, UI scale; saved to the user
pref folder), Quit. The lobby has no particles: the backdrop is a flat color, one soft light and a tiled grain texture
(about 60 sprites, same draw call as the buttons). The stats HUD (FPS / draw calls / sprites) shows in the lobby,
settings and editor. Mouse, touch (SDL maps it to mouse) and keyboard.

The editor is canvas-first: the infinite canvas fills the window and the chrome floats on top (tool rail on the left, two lines of five,
color + brush-size dock at the bottom, zoom pill, undo / redo / lobby top right).

| Tool | Key | Notes |
|---|---|---|
| Select | V / 1 | click to select (picks only), Delete removes |
| Move | M / 9 | drag the selected object |
| Scale | S | drag a handle of the selection |
| Rotate | Q / 8 | drag anywhere to turn the selection |
| Hand | H / 2 | drag to pan (middle / right mouse pans with any tool) |
| Pen | P / 3 | freehand strokes, 7 colors, 3 brush sizes |
| Line | L / 4 | drag |
| Rectangle | R / 5 | drag, filled |
| Ellipse | O / 6 | drag, filled |
| Eraser | E / 7 | drag over shapes to remove them |

Scale: corner handles scale proportionally, side handles stretch one axis (the opposite side stays fixed). Rotate snaps every
15 degrees. Boxes and ellipses keep an exact rotation; strokes and lines bake it into their points and keep their brush width.
Each gesture is one undo step. See "Tools: pick, move, scale, rotate" below.
(`transform.hpp` holds the math and is unit-tested.)

Colors: 7 presets plus a custom slot (the ringed swatch at the end of the color row). Tap it to open a panel with flat-color\nHUE / SAT / VAL strips; the last 5 custom colors stay as quick swatches (kept while the app runs, not saved to disk). The panel\nonly exists while open, so it costs nothing otherwise.\n\nTouch: two fingers pan and zoom (pinch) about their midpoint. The second finger cancels whatever the first one started
(an unfinished stroke is dropped, nothing is committed), and while two fingers are down nothing can draw until all lift.

Also: Ctrl+Z / Ctrl+Y undo / redo, wheel or +/- zoom, arrows pan, 0 resets the view, G toggles the grid, Esc goes back.
Touch: the small MORE button (above the zoom pill) opens a 3 x 2 menu: SAVE, OPEN, FIT / COPY, FRONT, BACK. It exists only while open,
closes after one tap or when you touch the canvas, and the result of SAVE / OPEN shows in the status line (where the tool name is)
until the next tool change or canvas touch. Keyboard: Ctrl+D duplicates the selection, `]` / `[` bring it to the front / send it to the back, F frames the whole drawing,
Ctrl+S saves the project and Ctrl+O opens it (`project.nova` in the user pref folder; the result is logged). A damaged or
newer file is refused and the open drawing is left alone. Undo / redo store only what changed per step (100 steps).
Dev: `./nova_sandbox --keys E` injects keys (U D L R arrows, E enter, B back) and logs every screen change.

## Tools: pick, move, scale, rotate
The rail has two lines of five. Top: **Select**, **Move**, **Scale**, **Rotate**, **Hand** (pans the view). Bottom: Pen, Line,
Rect, Ellipse, Eraser. Each tool does exactly one thing, so a slip with one can never change another:
- **Select** (`V`, `1`) only picks. Tap an object to select it, tap empty space to deselect. Dragging never changes anything.
- **Move** (`M`, `9`) drags the picked object (or whatever you press on). A press on empty space outside the selection does nothing.
- **Scale** (`S`) shows the resize handles of the selection; drag one. A tap elsewhere only picks.
- **Rotate** (`Q`, `8`) drags anywhere to turn the selection about its center; it clicks to every 15 degrees (a line from the
  pivot to the pointer shows the angle). Pressing on the pivot waits until the pointer leaves it. A tap on empty space deselects.
The selection survives switching between Select / Move / Scale / Rotate and is dropped when you pick a drawing tool.
Every move, resize and turn is one undo step.

## Code editor
Every object can carry a script (text only for now, there is no interpreter yet). Select an object, then
MORE > CODE (or `Enter` on a keyboard). The screen has line numbers, syntax colors (keywords, strings, numbers, comments),
auto-indent, undo / redo, copy / cut / paste, select, and its own on-screen keyboard (KEYS toggles it), so it works on a
phone browser where a canvas gets no system keyboard. Touch: tap places the cursor, drag scrolls; SEL makes taps and arrows
extend a selection. Mouse: drag selects. APPLY (or Esc / Back) stores the script in the object as one undo step; CANCEL
discards. Scripts are printable ASCII, up to 32 KB each, and are saved in the project file (format version 2; version 1
files still open). Duplicating an object copies its script. MORE also got GRID and HOME (reset view).

## Web (WebGL 2): test on a phone
Same C++, compiled with Emscripten. SDL3 provides the Emscripten backend (window, touch, keyboard); the GLES 3.0 renderer is
WebGL 2 as is. Output is static files: `index.html`, `index.js`, `index.wasm`, `index.data` (the fonts).

Easiest (no toolchain on your side): push the repo to GitHub, set Settings > Pages > Source to "GitHub Actions". Every push to
`main` runs `.github/workflows/web.yml` (native tests, then the wasm build) and publishes to `https://<user>.github.io/<repo>/`.
Open that link on the phone.

Local build (needs [emsdk](https://emscripten.org/docs/getting_started/downloads.html), a recent one for C++23):

    emcmake cmake -B build-web -DCMAKE_BUILD_TYPE=Release
    cmake --build build-web -j
    cd build-web && python3 -m http.server 8080      # open http://<pc-ip>:8080/ on the phone (same Wi-Fi)

Web specifics (all in `main.cpp` / `platform.cpp` / `gles_*`, the rest of the engine is untouched):
- The browser owns the loop: `App::step()` runs once per `requestAnimationFrame`. Idle screens skip drawing (the canvas keeps the last frame).
- The canvas follows the page size every frame (rotation, address bar); `HIGH_PIXEL_DENSITY` gives native resolution.
- Settings and `project.nova` live in `/persist`, mounted on IndexedDB; SAVE / settings changes sync it right away.
- No QUIT button (a tab cannot quit). Touch and pinch work through the same SDL finger events as Android.
- Blending uses separate alpha (`BlendFuncSeparate`) so the fade quad does not make the canvas see-through.
- If the browser drops the WebGL context (phone backgrounded for long), the page asks for a reload.

## Android
Use SDL3's `android-project` template, point its CMake at this repo, link `nova_sandbox`
as `libmain.so`. Needs NDK r27+ (C++23) and minSdk 24.

## Design rules (performance)
- No allocation inside the frame loop; temp data goes in an arena that resets each frame.
- 16-byte vertices, one static index buffer, one draw call per texture run.
- No depth buffer for 2D. Clear at frame start (tile-based GPUs).
- Fixed 60 Hz simulation step, rendering decoupled.
- Flat vertex colors only (no gradients): no dithering in the fragment shader, one texture fetch + one multiply.
- `SpriteBatch::draw_quad` + `quantize`: axis-aligned sprites with pre-converted UVs (about 2x faster than `draw`);
  text and the grain backdrop use it.
- Everything small (white pixel, shapes, UI skins) is packed into one atlas, and UI text is queued and drawn per font,
  so a screen is a handful of draw calls (the editor is typically 4-8).
- Undo is a log of deltas (insert / erase / replace / move), not document snapshots: a stroke commits in O(1) however big
  the drawing is, and 100 steps of history cost memory in proportion to the edits.
- The pointer keeps every sample the device reports in a frame (`Pointer::trail`), so fast strokes stay smooth on touch panels
  that report faster than the frame rate.
- Canvas: objects under 2 physical pixels draw as one quad; long strokes that are partly on screen skip their off-screen segments.
- Every screen sleeps until input arrives (about 0% CPU while idle); nothing animates continuously.

## Status
Done: core, ECS, sprite batcher, GLES backend, WebGL 2 / WebAssembly build, rotate tool, code editor, sandbox, texture atlas packer, bitmap fonts, blank-canvas editor with starter tools.
Also done: delta undo, project save / open (keyboard), duplicate, z-order, zoom-to-fit.
Next: Vulkan backend, audio, more editor tools.

## Texture atlas
    std::vector<nv::AtlasImage> imgs = {{w, h, rgba_ptr}, ...};
    nv::Atlas atlas = nv::build_atlas(imgs, {.max_page_size = 2048, .padding = 1});
    // one texture per page; sprite uv comes from atlas.uv(image_index)
    TextureId tex = renderer->create_texture(page.width, page.height, page.rgba.data(), true);
Edge extrusion (`padding`) prevents bleeding under linear filtering. Images that are empty, null
or larger than a page get an invalid region (`atlas.all_placed()`).
