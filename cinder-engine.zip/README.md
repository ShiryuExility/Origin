# Cinder

Engine game 2D kecil, C++17, dikompilasi ke WebAssembly dengan Emscripten dan SDL2.

Game bawaannya bernama **Ember Run**: lari, lompat, ambil koin, hindari jurang dan slime, sentuh tiang di ujung.

## Cukup upload zip dan build.yml

Repo GitHub boleh kosong. Jangan extract manual.

1. Upload `cinder-engine.zip` ke **root** repository.
2. Upload `build.yml` ke `.github/workflows/build.yml`.
3. Commit dan push.

Workflow mengekstrak zip itu sendiri, memasang Emscripten 3.1.74, lalu mengompilasi. Artifact **cinder-wasm** berisi `cinder.html`, `cinder.js`, dan `cinder.wasm`. Buka file html lewat server statis.

Kalau source sudah ter-extract (ada `CMakeLists.txt`), langkah extract dilewati.

`auto-extract.sh` ada di dalam zip untuk hal yang sama di mesin lokal: taruh zip di samping script, lalu `bash auto-extract.sh`.

## Isi engine

| Modul | File | Tugas |
|---|---|---|
| Loop | `include/cinder/engine.hpp` | Frame, waktu, urutan update |
| Input | `include/cinder/input.hpp` | Tombol dan pointer |
| Renderer | `include/cinder/renderer.hpp` | SDL2, kamera, kotak, teks bitmap |
| World | `include/cinder/world.hpp` | Entity, gravitasi, tabrakan AABB |
| Demo | `src/main.cpp` | Ember Run |

Build native tanpa SDL menjalankan self-test fisika selama 180 frame. Build WASM membuka game.

```bash
cmake -S . -B build -DCINDER_HEADLESS=ON
cmake --build build
./build/cinder
```

Jendela native butuh SDL2:

```bash
cmake -S . -B build -DCINDER_HEADLESS=OFF
cmake --build build
```

## Kontrol

- **A / D** atau panah: gerak
- **Spasi** atau **W**: lompat
- **R**: ulang
- Tombol di bawah canvas untuk layar sentuh

## Pakai ulang engine

Buat kelas turunan `cinder::Game`, spawn entity lewat `engine.world()`, lalu `engine.run(game, "judul", 640, 360)`.
