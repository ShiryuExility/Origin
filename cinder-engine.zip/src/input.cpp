#include "cinder/input.hpp"

namespace cinder {

void Input::beginFrame() {
  for (int i = 0; i < static_cast<int>(Key::Count); ++i) prev_[i] = cur_[i];
  pointerWasDown_ = pointerDown_;
}

void Input::setKey(Key key, bool down) {
  const int i = static_cast<int>(key);
  if (i < 0 || i >= static_cast<int>(Key::Count)) return;
  cur_[i] = down;
}

void Input::movePointer(Vec2 pos) { pointer_ = pos; }

void Input::setPointerDown(Vec2 pos, bool down) {
  pointer_ = pos;
  pointerDown_ = down;
}

bool Input::current(Key key) const {
  const int i = static_cast<int>(key);
  if (i < 0 || i >= static_cast<int>(Key::Count)) return false;
  return cur_[i];
}

bool Input::previous(Key key) const {
  const int i = static_cast<int>(key);
  if (i < 0 || i >= static_cast<int>(Key::Count)) return false;
  return prev_[i];
}

bool Input::down(Key key) const { return current(key); }

bool Input::pressed(Key key) const { return current(key) && !previous(key); }

bool Input::released(Key key) const { return !current(key) && previous(key); }

}  // namespace cinder
