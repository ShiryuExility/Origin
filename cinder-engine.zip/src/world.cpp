#include "cinder/world.hpp"

#include <cmath>

namespace cinder {

void World::clear() {
  count_ = 0;
  for (auto& entity : entities_) entity = Entity{};
}

Entity* World::spawn(Entity entity) {
  if (count_ >= kMax) return nullptr;
  entity.alive = true;
  entities_[count_] = entity;
  return &entities_[count_++];
}

void World::resolve(Entity& entity, bool axisX) {
  for (int i = 0; i < count_; ++i) {
    Entity& solid = entities_[i];
    if (!solid.alive || !solid.solid || &solid == &entity) continue;
    if (!entity.box.overlaps(solid.box)) continue;

    if (axisX) {
      if (entity.vel.x > 0.f) {
        entity.box.x = solid.box.x - entity.box.w;
      } else if (entity.vel.x < 0.f) {
        entity.box.x = solid.box.right();
      } else {
        const float pushLeft = entity.box.right() - solid.box.x;
        const float pushRight = solid.box.right() - entity.box.x;
        if (pushLeft < pushRight) entity.box.x -= pushLeft;
        else entity.box.x += pushRight;
      }
      entity.vel.x = 0.f;
    } else if (entity.vel.y > 0.f) {
      entity.box.y = solid.box.y - entity.box.h;
      entity.vel.y = 0.f;
      entity.onGround = true;
    } else if (entity.vel.y < 0.f) {
      entity.box.y = solid.box.bottom();
      entity.vel.y = 0.f;
    } else {
      const float pushUp = entity.box.bottom() - solid.box.y;
      const float pushDown = solid.box.bottom() - entity.box.y;
      if (pushUp < pushDown) {
        entity.box.y -= pushUp;
        entity.onGround = true;
      } else {
        entity.box.y += pushDown;
      }
    }
  }
}

void World::update(float dt) {
  if (dt < 0.f) return;

  for (int i = 0; i < count_; ++i) {
    Entity& entity = entities_[i];
    if (!entity.alive || !entity.dynamic) continue;

    entity.onGround = false;
    if (entity.gravity) entity.vel.y += 1400.f * dt;
    if (entity.vel.y > 720.f) entity.vel.y = 720.f;

    entity.box.x += entity.vel.x * dt;
    resolve(entity, true);
    entity.box.y += entity.vel.y * dt;
    resolve(entity, false);

    if (entity.patrolMax > entity.patrolMin) {
      const float speed = std::fabs(entity.patrolSpeed);
      if (entity.box.x <= entity.patrolMin) {
        entity.box.x = entity.patrolMin;
        entity.vel.x = speed;
      } else if (entity.box.right() >= entity.patrolMax) {
        entity.box.x = entity.patrolMax - entity.box.w;
        entity.vel.x = -speed;
      }
    }
  }
}

}  // namespace cinder
