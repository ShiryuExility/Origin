#include "cinder/renderer.hpp"

#include "cinder/input.hpp"

#include <cstring>

#if defined(__EMSCRIPTEN__) || defined(CINDER_SDL)
#define CINDER_USE_SDL 1
#include <SDL.h>
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif
#else
#define CINDER_USE_SDL 0
#endif

namespace cinder {
namespace {

const char* glyph(char c) {
  switch (c) {
    case 'A': return "01110100011000111111100011000110001";
    case 'B': return "11110100011000111110100011000111110";
    case 'C': return "01111100001000010000100001000001111";
    case 'D': return "11110100011000110001100011000111110";
    case 'E': return "11111100001000011110100001000011111";
    case 'F': return "11111100001000011110100001000010000";
    case 'G': return "01111100001000010111100011000101111";
    case 'H': return "10001100011000111111100011000110001";
    case 'I': return "11111001000010000100001000010001111";
    case 'J': return "00111000100001000010100101001001100";
    case 'K': return "10001100101010011000101001001010001";
    case 'L': return "10000100001000010000100001000011111";
    case 'M': return "10001110111010110101100011000110001";
    case 'N': return "10001110011010110011100011000110001";
    case 'O': return "01110100011000110001100011000101110";
    case 'P': return "11110100011000111110100001000010000";
    case 'Q': return "01110100011000110001101011001001101";
    case 'R': return "11110100011000111110101001001010001";
    case 'S': return "01111100001000001110000010000111110";
    case 'T': return "11111001000010000100001000010000100";
    case 'U': return "10001100011000110001100011000101110";
    case 'V': return "10001100011000110001010100010000100";
    case 'W': return "10001100011000110101101011010101010";
    case 'X': return "10001100010101000100010101000110001";
    case 'Y': return "10001100010101000100001000010000100";
    case 'Z': return "11111000010001000100010001000011111";
    case '0': return "01110100011001110101110011000101110";
    case '1': return "00100011000010000100001000010001110";
    case '2': return "01110100010000100010001000100011111";
    case '3': return "11110000010000101110000010000111110";
    case '4': return "00010001100101010010111110001000010";
    case '5': return "11111100001000011110000010000111110";
    case '6': return "01110100001000011110100011000101110";
    case '7': return "11111000010001000100010000100001000";
    case '8': return "01110100011000101110100011000101110";
    case '9': return "01110100011000101111000010000101110";
    case '-': return "00000000000000011111000000000000000";
    case '/': return "00001000100001000100010000100010000";
    case ':': return "00000001000000000000001000000000000";
    default: return nullptr;
  }
}

}  // namespace

bool Renderer::init(const char* title, int width, int height) {
  width_ = width;
  height_ = height;
  camera_ = {width * 0.5f, height * 0.5f};
#if CINDER_USE_SDL
  if (SDL_Init(SDL_INIT_VIDEO) != 0) return false;
  window_ = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                             width, height, SDL_WINDOW_SHOWN);
  if (window_ == nullptr) return false;
  sdl_ = SDL_CreateRenderer(window_, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
  if (sdl_ == nullptr) return false;
  SDL_SetRenderDrawBlendMode(sdl_, SDL_BLENDMODE_BLEND);
#ifdef __EMSCRIPTEN__
  emscripten_set_canvas_element_size("#canvas", width, height);
#endif
#else
  (void)title;
#endif
  return true;
}

void Renderer::shutdown() {
#if CINDER_USE_SDL
  if (sdl_ != nullptr) SDL_DestroyRenderer(sdl_);
  if (window_ != nullptr) SDL_DestroyWindow(window_);
  sdl_ = nullptr;
  window_ = nullptr;
  SDL_Quit();
#endif
}

void Renderer::begin(Color clear) {
#if CINDER_USE_SDL
  if (sdl_ == nullptr) return;
  SDL_SetRenderDrawColor(sdl_, clear.r, clear.g, clear.b, 255);
  SDL_RenderClear(sdl_);
#else
  (void)clear;
#endif
}

void Renderer::present() {
#if CINDER_USE_SDL
  if (sdl_ != nullptr) SDL_RenderPresent(sdl_);
#endif
}

bool Renderer::pump(Input& input, bool& quit) {
  quit = false;
#if CINDER_USE_SDL
  SDL_Event event;
  while (SDL_PollEvent(&event)) {
    if (event.type == SDL_QUIT) quit = true;
    else if (event.type == SDL_KEYDOWN || event.type == SDL_KEYUP) {
      if (event.key.repeat) continue;
      const bool down = event.type == SDL_KEYDOWN;
      Key key = Key::Count;
      switch (event.key.keysym.sym) {
        case SDLK_LEFT: key = Key::Left; break;
        case SDLK_RIGHT: key = Key::Right; break;
        case SDLK_UP: key = Key::Up; break;
        case SDLK_DOWN: key = Key::Down; break;
        case SDLK_a: key = Key::A; break;
        case SDLK_d: key = Key::D; break;
        case SDLK_w: key = Key::W; break;
        case SDLK_s: key = Key::S; break;
        case SDLK_SPACE: key = Key::Space; break;
        case SDLK_RETURN: key = Key::Enter; break;
        case SDLK_ESCAPE: key = Key::Escape; break;
        case SDLK_r: key = Key::R; break;
        default: break;
      }
      if (key != Key::Count) input.setKey(key, down);
      if (down && key == Key::Escape) quit = true;
    } else if (event.type == SDL_MOUSEMOTION) {
      input.movePointer({static_cast<float>(event.motion.x), static_cast<float>(event.motion.y)});
    } else if (event.type == SDL_MOUSEBUTTONDOWN || event.type == SDL_MOUSEBUTTONUP) {
      input.setPointerDown(
          {static_cast<float>(event.button.x), static_cast<float>(event.button.y)},
          event.type == SDL_MOUSEBUTTONDOWN);
    } else if (event.type == SDL_FINGERDOWN || event.type == SDL_FINGERUP ||
               event.type == SDL_FINGERMOTION) {
      const Vec2 pos{event.tfinger.x * static_cast<float>(width_),
                     event.tfinger.y * static_cast<float>(height_)};
      if (event.type == SDL_FINGERMOTION) input.movePointer(pos);
      else input.setPointerDown(pos, event.type == SDL_FINGERDOWN);
    }
  }
#else
  (void)input;
#endif
  return true;
}

void Renderer::setCamera(Vec2 worldCenter) { camera_ = worldCenter; }

void Renderer::fill(float x, float y, float w, float h, Color color) {
#if CINDER_USE_SDL
  if (sdl_ == nullptr) return;
  SDL_Rect dst;
  dst.x = static_cast<int>(x);
  dst.y = static_cast<int>(y);
  dst.w = static_cast<int>(w);
  dst.h = static_cast<int>(h);
  if (dst.w < 1) dst.w = 1;
  if (dst.h < 1) dst.h = 1;
  SDL_SetRenderDrawColor(sdl_, color.r, color.g, color.b, color.a);
  SDL_RenderFillRect(sdl_, &dst);
#else
  (void)x;
  (void)y;
  (void)w;
  (void)h;
  (void)color;
#endif
}

void Renderer::drawRect(Rect world, Color color) {
  const float sx = world.x - camera_.x + static_cast<float>(width_) * 0.5f;
  const float sy = world.y - camera_.y + static_cast<float>(height_) * 0.5f;
  fill(sx, sy, world.w, world.h, color);
}

void Renderer::drawRectScreen(Rect screen, Color color) {
  fill(screen.x, screen.y, screen.w, screen.h, color);
}

void Renderer::blitText(float x, float y, const char* text, Color color, int scale) {
  if (text == nullptr || scale < 1) return;
  const float originX = x;
  for (const char* cursor = text; *cursor != '\0'; ++cursor) {
    char c = *cursor;
    if (c == '\n') {
      x = originX;
      y += static_cast<float>(8 * scale);
      continue;
    }
    if (c >= 'a' && c <= 'z') c = static_cast<char>(c - 'a' + 'A');
    const char* rows = glyph(c);
    if (rows != nullptr && std::strlen(rows) >= 35) {
      for (int row = 0; row < 7; ++row) {
        for (int col = 0; col < 5; ++col) {
          if (rows[row * 5 + col] == '1') {
            fill(x + static_cast<float>(col * scale), y + static_cast<float>(row * scale),
                 static_cast<float>(scale), static_cast<float>(scale), color);
          }
        }
      }
    }
    x += static_cast<float>(6 * scale);
  }
}

void Renderer::drawText(float x, float y, const char* text, Color color, int scale) {
  const float sx = x - camera_.x + static_cast<float>(width_) * 0.5f;
  const float sy = y - camera_.y + static_cast<float>(height_) * 0.5f;
  blitText(sx, sy, text, color, scale);
}

void Renderer::drawTextScreen(float x, float y, const char* text, Color color, int scale) {
  blitText(x, y, text, color, scale);
}

int Renderer::textWidth(const char* text, int scale) const {
  if (text == nullptr || scale < 1) return 0;
  int columns = 0;
  int longest = 0;
  for (const char* cursor = text; *cursor != '\0'; ++cursor) {
    if (*cursor == '\n') {
      if (columns > longest) longest = columns;
      columns = 0;
    } else {
      ++columns;
    }
  }
  if (columns > longest) longest = columns;
  return longest * 6 * scale;
}

}  // namespace cinder
