#include "cinder/engine.hpp"

#include <cstdio>

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

namespace {

constexpr cinder::Color kCream = cinder::Color::rgb(244, 239, 232);
constexpr cinder::Color kMuted = cinder::Color::rgb(181, 168, 156);
constexpr cinder::Color kEmber = cinder::Color::rgb(228, 87, 46);
constexpr cinder::Color kGround = cinder::Color::rgb(58, 42, 34);
constexpr cinder::Color kBrick = cinder::Color::rgb(107, 67, 52);
constexpr cinder::Color kPlayer = cinder::Color::rgb(244, 162, 97);
constexpr cinder::Color kHazard = cinder::Color::rgb(140, 58, 47);
constexpr cinder::Color kShade = cinder::Color::rgb(0, 0, 0, 70);

void beep(float freq, int ms) {
#ifdef __EMSCRIPTEN__
  EM_ASM(
      {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        if (!Ctx) return;
        const ctx = Module._cinderAudio || (Module._cinderAudio = new Ctx());
        if (ctx.state === "suspended") ctx.resume();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.value = $0;
        osc.type = "square";
        gain.gain.value = 0.035;
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + $1 / 1000);
      },
      freq, ms);
#else
  (void)freq;
  (void)ms;
#endif
}

class EmberRun : public cinder::Game {
 public:
  void onStart(cinder::Engine& engine) override {
    engine.setClear(cinder::Color::rgb(20, 17, 15));
    load(engine);
  }

  void onUpdate(cinder::Engine& engine, float) override {
    if (player_ == nullptr) return;
    auto& input = engine.input();
    if (input.pressed(cinder::Key::R) || input.pressed(cinder::Key::Enter)) {
      if (input.pressed(cinder::Key::R) || dead_ || win_) {
        load(engine);
        return;
      }
    }
    if (dead_ || win_) {
      player_->vel.x = 0.f;
      return;
    }

    float move = 0.f;
    if (engine.headless()) {
      move = 1.f;
    } else {
      if (input.down(cinder::Key::Left) || input.down(cinder::Key::A)) move -= 1.f;
      if (input.down(cinder::Key::Right) || input.down(cinder::Key::D)) move += 1.f;
      const bool jump = input.pressed(cinder::Key::Space) || input.pressed(cinder::Key::W) ||
                        input.pressed(cinder::Key::Up);
      if (jump && player_->onGround) {
        player_->vel.y = -460.f;
        beep(220.f, 70);
      }
      readTouch(engine, move);
    }
    player_->vel.x = move * 180.f;
  }

  void onAfterPhysics(cinder::Engine& engine) override {
    if (player_ == nullptr || !player_->alive) return;

    auto& world = engine.world();
    for (int i = 0; i < world.count(); ++i) {
      cinder::Entity& entity = world.at(i);
      if (!entity.alive || &entity == player_) continue;
      if (!player_->box.overlaps(entity.box)) continue;
      if (entity.kind == cinder::Kind::Pickup) {
        entity.alive = false;
        ++coins_;
        beep(660.f, 80);
      } else if (entity.kind == cinder::Kind::Hazard) {
        dead_ = true;
        player_->vel = {};
        beep(90.f, 180);
      } else if (entity.kind == cinder::Kind::Goal) {
        win_ = true;
        player_->vel.x = 0.f;
        beep(520.f, 160);
      }
    }
    if (player_->box.y > 560.f) {
      dead_ = true;
      player_->vel = {};
    }

    cinder::Vec2 focus = player_->box.center();
    const float halfW = static_cast<float>(engine.renderer().width()) * 0.5f;
    const float halfH = static_cast<float>(engine.renderer().height()) * 0.5f;
    if (focus.x < halfW) focus.x = halfW;
    if (focus.x > levelWidth_ - halfW) focus.x = levelWidth_ - halfW;
    if (focus.y < halfH) focus.y = halfH;
    if (focus.y > 420.f) focus.y = 420.f;
    engine.renderer().setCamera(focus);
  }

  void onDraw(cinder::Engine& engine, cinder::Renderer& renderer) override {
    auto& world = engine.world();
    for (int i = 0; i < world.count(); ++i) {
      const cinder::Entity& entity = world.at(i);
      if (!entity.alive) continue;
      cinder::Rect shade = entity.box;
      shade.x += 3.f;
      shade.y += 4.f;
      renderer.drawRect(shade, kShade);
    }
    for (int i = 0; i < world.count(); ++i) {
      const cinder::Entity& entity = world.at(i);
      if (!entity.alive) continue;
      renderer.drawRect(entity.box, entity.color);
    }

    char line[64];
    std::snprintf(line, sizeof(line), "KOIN %d/%d", coins_, totalCoins_);
    renderer.drawTextScreen(16.f, 14.f, line, kCream, 2);
    renderer.drawTextScreen(16.f, 34.f, "A D GERAK   SPASI LOMPAT", kMuted, 1);

    const char* banner = nullptr;
    if (win_) banner = "MENANG\nTEKAN R";
    else if (dead_) banner = "JATUH\nTEKAN R";
    if (banner != nullptr) {
      const int scale = 3;
      const float x = (static_cast<float>(renderer.width()) - renderer.textWidth(banner, scale)) * 0.5f;
      renderer.drawTextScreen(x, 120.f, banner, kCream, scale);
    }

    if (!engine.headless()) drawTouch(renderer);
  }

  cinder::Rect playerBox() const { return player_ != nullptr ? player_->box : cinder::Rect{}; }
  int coins() const { return coins_; }

 private:
  void load(cinder::Engine& engine) {
    auto& world = engine.world();
    world.clear();
    coins_ = 0;
    totalCoins_ = 0;
    win_ = false;
    dead_ = false;
    player_ = nullptr;
    levelWidth_ = 1800.f;

    auto solid = [&](float x, float y, float w, float h, cinder::Color color) {
      cinder::Entity entity;
      entity.kind = cinder::Kind::Solid;
      entity.box = {x, y, w, h};
      entity.color = color;
      entity.solid = true;
      world.spawn(entity);
    };
    auto coin = [&](float x, float y) {
      cinder::Entity entity;
      entity.kind = cinder::Kind::Pickup;
      entity.box = {x, y, 12.f, 12.f};
      entity.color = kEmber;
      world.spawn(entity);
      ++totalCoins_;
    };

    solid(0.f, 300.f, 520.f, 48.f, kGround);
    solid(640.f, 300.f, 460.f, 48.f, kGround);
    solid(1160.f, 300.f, 640.f, 48.f, kGround);
    solid(760.f, 220.f, 120.f, 16.f, kBrick);
    solid(980.f, 170.f, 90.f, 16.f, kBrick);
    solid(1360.f, 230.f, 140.f, 16.f, kBrick);

    coin(150.f, 276.f);
    coin(280.f, 276.f);
    coin(410.f, 276.f);
    coin(800.f, 196.f);
    coin(1008.f, 146.f);
    coin(1420.f, 206.f);

    cinder::Entity slime;
    slime.kind = cinder::Kind::Hazard;
    slime.box = {700.f, 276.f, 26.f, 24.f};
    slime.color = kHazard;
    slime.dynamic = true;
    slime.gravity = true;
    slime.vel.x = 70.f;
    slime.patrolMin = 660.f;
    slime.patrolMax = 1060.f;
    slime.patrolSpeed = 70.f;
    world.spawn(slime);

    cinder::Entity goal;
    goal.kind = cinder::Kind::Goal;
    goal.box = {1660.f, 244.f, 22.f, 56.f};
    goal.color = kCream;
    world.spawn(goal);

    cinder::Entity actor;
    actor.kind = cinder::Kind::Actor;
    actor.box = {48.f, 260.f, 22.f, 28.f};
    actor.color = kPlayer;
    actor.dynamic = true;
    actor.gravity = true;
    player_ = world.spawn(actor);
  }

  void readTouch(cinder::Engine& engine, float& move) {
    auto& input = engine.input();
    if (!input.pointerDown() && !input.pointerPressed()) return;
    const cinder::Vec2 pos = input.pointer();
    const float height = static_cast<float>(engine.renderer().height());
    const float width = static_cast<float>(engine.renderer().width());
    if (pos.y < height - 72.f) return;
    if (pos.x < 88.f) move -= 1.f;
    else if (pos.x < 176.f) move += 1.f;
    else if (pos.x > width - 96.f && input.pointerPressed() && player_->onGround) {
      player_->vel.y = -460.f;
      beep(220.f, 70);
    }
  }

  void drawTouch(cinder::Renderer& renderer) const {
    const float y = static_cast<float>(renderer.height()) - 64.f;
    const float width = static_cast<float>(renderer.width());
    renderer.drawRectScreen({12.f, y, 64.f, 48.f}, kGround);
    renderer.drawRectScreen({88.f, y, 64.f, 48.f}, kGround);
    renderer.drawRectScreen({width - 84.f, y, 72.f, 48.f}, kEmber);
    renderer.drawTextScreen(28.f, y + 16.f, "A", kCream, 2);
    renderer.drawTextScreen(104.f, y + 16.f, "D", kCream, 2);
    renderer.drawTextScreen(width - 72.f, y + 16.f, "LOMPAT", kCream, 1);
  }

  cinder::Entity* player_ = nullptr;
  int coins_ = 0;
  int totalCoins_ = 0;
  bool win_ = false;
  bool dead_ = false;
  float levelWidth_ = 1800.f;
};

}  // namespace

int main() {
  EmberRun game;
  cinder::Engine engine;
#if defined(__EMSCRIPTEN__) || defined(CINDER_SDL)
  return engine.run(game, "Cinder", 640, 360);
#else
  engine.runHeadless(game, 180);
  const cinder::Rect box = game.playerBox();
  std::printf("player x=%.2f y=%.2f coins=%d\n", static_cast<double>(box.x),
              static_cast<double>(box.y), game.coins());
  if (box.x < 200.f) return 1;
  if (game.coins() < 1) return 2;
  std::puts("Cinder headless OK");
  return 0;
#endif
}
