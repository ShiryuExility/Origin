#include "cinder/engine.hpp"

#include <chrono>

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

namespace cinder {

#ifdef __EMSCRIPTEN__
void Engine::emFrame(void* self) {
  auto* engine = static_cast<Engine*>(self);
  if (!engine->frame()) emscripten_cancel_main_loop();
}
#endif

int Engine::run(Game& game, const char* title, int width, int height) {
  headless_ = false;
  if (!renderer_.init(title, width, height)) return 1;
  game_ = &game;
  lastTime_ = 0.0;
  game.onStart(*this);
#ifdef __EMSCRIPTEN__
  emscripten_set_main_loop_arg(&Engine::emFrame, this, 0, 1);
#else
  while (frame()) {
  }
  renderer_.shutdown();
#endif
  return 0;
}

int Engine::runHeadless(Game& game, int frames) {
  headless_ = true;
  if (!renderer_.init("cinder", 640, 360)) return 1;
  game_ = &game;
  lastTime_ = 0.0;
  game.onStart(*this);
  for (int i = 0; i < frames; ++i) {
    if (!frame()) break;
  }
  renderer_.shutdown();
  return 0;
}

bool Engine::frame() {
  input_.beginFrame();
  bool quit = false;
  if (!renderer_.pump(input_, quit) || quit) return false;

  const double now = std::chrono::duration<double>(
                         std::chrono::steady_clock::now().time_since_epoch())
                         .count();
  float dt = 1.f / 60.f;
  if (!headless_ && lastTime_ > 0.0) dt = static_cast<float>(now - lastTime_);
  lastTime_ = now;
  if (dt < 0.f) dt = 0.f;
  if (dt > 0.05f) dt = 0.05f;

  elapsed_ += dt;
  ++frameIndex_;
  if (game_ == nullptr) return false;

  game_->onUpdate(*this, dt);
  world_.update(dt);
  game_->onAfterPhysics(*this);
  renderer_.begin(clear_);
  game_->onDraw(*this, renderer_);
  renderer_.present();
  return true;
}

}  // namespace cinder
