#pragma once

namespace cinder {

class Engine;
class Renderer;

class Game {
 public:
  virtual ~Game() = default;
  virtual void onStart(Engine&) {}
  virtual void onUpdate(Engine&, float dt) { (void)dt; }
  virtual void onAfterPhysics(Engine&) {}
  virtual void onDraw(Engine&, Renderer&) {}
};

}  // namespace cinder
