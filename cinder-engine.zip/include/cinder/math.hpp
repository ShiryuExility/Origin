#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>

namespace cinder {

struct Vec2 {
  float x = 0.f;
  float y = 0.f;

  constexpr Vec2() = default;
  constexpr Vec2(float x_, float y_) : x(x_), y(y_) {}

  constexpr Vec2 operator+(Vec2 o) const { return {x + o.x, y + o.y}; }
  constexpr Vec2 operator-(Vec2 o) const { return {x - o.x, y - o.y}; }
  constexpr Vec2 operator*(float s) const { return {x * s, y * s}; }
  Vec2& operator+=(Vec2 o) {
    x += o.x;
    y += o.y;
    return *this;
  }
  float length() const { return std::sqrt(x * x + y * y); }
};

struct Rect {
  float x = 0.f;
  float y = 0.f;
  float w = 0.f;
  float h = 0.f;

  constexpr float left() const { return x; }
  constexpr float right() const { return x + w; }
  constexpr float top() const { return y; }
  constexpr float bottom() const { return y + h; }
  constexpr Vec2 center() const { return {x + w * 0.5f, y + h * 0.5f}; }

  constexpr bool overlaps(Rect o) const {
    return x < o.right() && right() > o.x && y < o.bottom() && bottom() > o.y;
  }
};

struct Color {
  uint8_t r = 0;
  uint8_t g = 0;
  uint8_t b = 0;
  uint8_t a = 255;

  static constexpr Color rgb(uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255) {
    return {r, g, b, a};
  }
};

}  // namespace cinder
