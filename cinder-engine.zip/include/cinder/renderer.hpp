#pragma once

#include "cinder/math.hpp"

namespace cinder {

class Input;

class Renderer {
 public:
  bool init(const char* title, int width, int height);
  void shutdown();
  void begin(Color clear);
  void present();
  bool pump(Input& input, bool& quit);

  void setCamera(Vec2 worldCenter);
  void drawRect(Rect world, Color color);
  void drawRectScreen(Rect screen, Color color);
  void drawText(float x, float y, const char* text, Color color, int scale = 2);
  void drawTextScreen(float x, float y, const char* text, Color color, int scale = 2);
  int textWidth(const char* text, int scale) const;

  int width() const { return width_; }
  int height() const { return height_; }

 private:
  void fill(float x, float y, float w, float h, Color color);
  void blitText(float x, float y, const char* text, Color color, int scale);

  int width_ = 640;
  int height_ = 360;
  Vec2 camera_{320.f, 180.f};

#if defined(__EMSCRIPTEN__) || defined(CINDER_SDL)
  struct SDL_Window* window_ = nullptr;
  struct SDL_Renderer* sdl_ = nullptr;
#endif
};

}  // namespace cinder
