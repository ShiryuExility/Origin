#pragma once

#include "cinder/game.hpp"
#include "cinder/input.hpp"
#include "cinder/renderer.hpp"
#include "cinder/world.hpp"

namespace cinder {

class Engine {
 public:
  int run(Game& game, const char* title, int width, int height);
  int runHeadless(Game& game, int frames);

  Input& input() { return input_; }
  Renderer& renderer() { return renderer_; }
  World& world() { return world_; }

  float elapsed() const { return elapsed_; }
  int frameIndex() const { return frameIndex_; }
  bool headless() const { return headless_; }
  void setClear(Color color) { clear_ = color; }

  bool frame();

 private:
#ifdef __EMSCRIPTEN__
  static void emFrame(void* self);
#endif

  Game* game_ = nullptr;
  Input input_;
  Renderer renderer_;
  World world_;
  Color clear_ = Color::rgb(20, 17, 15);
  float elapsed_ = 0.f;
  int frameIndex_ = 0;
  bool headless_ = false;
  double lastTime_ = 0.0;
};

}  // namespace cinder
