#pragma once

#include "cinder/math.hpp"

namespace cinder {

enum class Kind { Solid, Actor, Pickup, Hazard, Goal, Decor };

struct Entity {
  bool alive = false;
  Kind kind = Kind::Decor;
  Rect box{};
  Vec2 vel{};
  Color color = Color::rgb(244, 239, 232);
  bool solid = false;
  bool dynamic = false;
  bool gravity = false;
  bool onGround = false;
  float patrolMin = 0.f;
  float patrolMax = 0.f;
  float patrolSpeed = 0.f;
};

class World {
 public:
  static constexpr int kMax = 256;

  void clear();
  Entity* spawn(Entity entity);
  int count() const { return count_; }
  Entity& at(int index) { return entities_[index]; }
  const Entity& at(int index) const { return entities_[index]; }
  void update(float dt);

 private:
  void resolve(Entity& entity, bool axisX);

  Entity entities_[kMax]{};
  int count_ = 0;
};

}  // namespace cinder
