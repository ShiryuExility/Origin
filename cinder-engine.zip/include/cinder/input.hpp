#pragma once

#include "cinder/math.hpp"

namespace cinder {

enum class Key {
  Left,
  Right,
  Up,
  Down,
  A,
  D,
  W,
  S,
  Space,
  Enter,
  Escape,
  R,
  Count
};

class Input {
 public:
  void beginFrame();
  void setKey(Key key, bool down);
  void movePointer(Vec2 pos);
  void setPointerDown(Vec2 pos, bool down);

  bool down(Key key) const;
  bool pressed(Key key) const;
  bool released(Key key) const;

  Vec2 pointer() const { return pointer_; }
  bool pointerDown() const { return pointerDown_; }
  bool pointerPressed() const { return pointerDown_ && !pointerWasDown_; }

 private:
  bool current(Key key) const;
  bool previous(Key key) const;

  bool cur_[static_cast<int>(Key::Count)]{};
  bool prev_[static_cast<int>(Key::Count)]{};
  Vec2 pointer_{};
  bool pointerDown_ = false;
  bool pointerWasDown_ = false;
};

}  // namespace cinder
