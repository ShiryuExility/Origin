#!/usr/bin/env bash
# Unpack the engine zip into this directory when the sources are not here yet.
set -euo pipefail
cd "$(dirname "$0")"

if [[ -f CMakeLists.txt ]]; then
  echo "Source sudah ada, extract dilewati."
  exit 0
fi

zip=""
if [[ -f cinder-engine.zip ]]; then
  zip="cinder-engine.zip"
else
  zip="$(find . -maxdepth 3 -type f -name '*.zip' ! -path '*/.git/*' | head -n 1 || true)"
fi
if [[ -z "${zip}" ]]; then
  echo "Tidak ada zip. Taruh cinder-engine.zip di samping script ini."
  exit 1
fi

echo "Extract: ${zip}"
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
unzip -o "${zip}" -d "${work}"
src="${work}"
if [[ ! -f "${src}/CMakeLists.txt" ]]; then
  list="$(find "${src}" -name CMakeLists.txt | head -n 1)"
  if [[ -z "${list}" ]]; then
    echo "CMakeLists.txt tidak ketemu di dalam zip."
    exit 1
  fi
  src="$(dirname "${list}")"
fi
cp -a "${src}/." .
test -f CMakeLists.txt
echo "Extract selesai."
